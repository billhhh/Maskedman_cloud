 #pragma once

#include "opencv2/imgproc/imgproc.hpp"
#include "../segm/msImageProcessor.h"
#include "LabInfo.h"
#include "HistList.h"


extern IplImage *cbgImage_;//ԭʼͼƬ
extern IplImage *cbgImage2_;//�ָ���ͼƬ
extern IplImage *cbImgGray;

extern int g_width;
extern int g_height;


class CMatLogic
{
public:
	static CMatLogic * Instance();
	~CMatLogic();
	void DoReadImg(char * pathName);
	void DoReadImg(unsigned char * bufData,int width,int height);

	bool Chang2_4(IplImage * src1);
	void rotateImage2(IplImage* img, int degree);
private:
	void DoColorSeg();

	void FindCountor();

	void DoRGBGray();
	uchar ReComputeTheValue(uchar inValue);



	CMatLogic();
	static CMatLogic * m_instance;

	bool m_bFilterFont;

};
