#include "./opencv2/highgui/highgui_c.h"
#include "./opencv2/imgproc/imgproc_c.h"
#include "../edge/CannyEdgeDetect.h"
#include "../edge/BgDefaults.h"

#include "matlogic.h"


IplImage *cbgImage_ = NULL;
IplImage *cbgImage2_ = NULL;
IplImage * cbImgGray = NULL;
unsigned char *g_ResultData = NULL;
unsigned char *g_ResultHead = NULL;
bool g_bDetectedFace = false;
int g_width;
int g_height;


CMatLogic * CMatLogic::m_instance = NULL;
CMatLogic * CMatLogic::Instance()
{
	if (m_instance == NULL)
	{
		m_instance = new CMatLogic();
	}
	return m_instance;
}

CMatLogic::CMatLogic()
{
}

CMatLogic::~CMatLogic()
{

};




void CMatLogic::DoReadImg(unsigned char * bufData,int width,int height)
{
	
	IplImage * img4 = cvCreateImage(cvSize(width,height),IPL_DEPTH_8U,4);
	memcpy(img4->imageData,bufData,width*height*4);
	IplImage * src1  = cvCreateImage(cvSize(width,height),8,3);
	cvCvtColor(img4,src1,CV_BGRA2RGB);
	cvReleaseImage(&img4);

	if (src1 == NULL)
	{
		return;
	}

	Chang2_4(src1);

	cvReleaseImage(&src1);

}










bool CMatLogic::Chang2_4(IplImage * src1)
{
	
	IplImage * src;
	
	int width4 = src1->width/4*4;
	if(width4 != 4 )
	{
		src = cvCreateImage(cvSize(width4,src1->height),src1->depth,src1->nChannels);
		cvResize(src1,src);
	}
	else
	{
		src = cvCloneImage(src1);
	}


	if (cbgImage_ != NULL)
	{
		cvReleaseImage(&cbgImage_);
		cbgImage_ = NULL;
		cvReleaseImage(&cbgImage2_);
		cbgImage2_ = NULL;
	}
	//rotateImage2(src,5);
	//cvShowImage("rotate",src);

	cbgImage_ = cvCloneImage(src);
	cbgImage2_ = cvCloneImage(src);
	cvReleaseImage(&src);
	
	
	
	g_width =  cbgImage_->width;
	g_height = cbgImage_->height;

	return true;

}

uchar CMatLogic::ReComputeTheValue(uchar inValue)
{
	double ratio = inValue*2.0/255.0;
	if (ratio <= 1.0)
	{
		//ratio = pow(ratio,4);
	
	}
	else
	{
		ratio = pow(ratio-1,0.7)+1;
	}
	ratio = ratio/2;

	if (ratio > 1)
	{
		ratio = 1;
	}
	return inValue = 255*ratio;
}
void CMatLogic::DoRGBGray()
{
	if (cbImgGray)
	{
		cvReleaseImage(&cbImgGray);
		cbImgGray = NULL;
	}
	cbImgGray = cvCreateImage(cvGetSize(cbgImage_),8,1);

	int w = cbImgGray->width;
	int h = cbImgGray->height;

	cvCvtColor(cbgImage_,cbImgGray,CV_RGB2GRAY);

	
	
}

//��תͼ�����ݲ��䣬�ߴ���Ӧ���
void CMatLogic::rotateImage2(IplImage* img, int degree)  
{  
	double angle = degree  * CV_PI / 180.; 
	double a = sin(angle), b = cos(angle); 
	int width=img->width, height=img->height;
	//��ת�����ͼ�ߴ�
	int width_rotate= int(height * fabs(a) + width * fabs(b));  
	int height_rotate=int(width * fabs(a) + height * fabs(b));  
	//IplImage* img_rotate = cvCreateImage(cvSize(width_rotate, height_rotate), img->depth, img->nChannels);  
	//cvZero(img_rotate);  
	//��֤ԭͼ��������Ƕ���ת����С�ߴ�
	int tempLength = sqrt((double)width * width + (double)height *height) + 10;  
	int tempX = (tempLength + 1) / 2 - width / 2;  
	int tempY = (tempLength + 1) / 2 - height / 2;  
	IplImage* temp = cvCreateImage(cvSize(tempLength, tempLength), img->depth, img->nChannels);  
	cvZero(temp);  
	//��ԭͼ���Ƶ���ʱͼ��tmp����
	cvSetImageROI(temp, cvRect(tempX, tempY, width, height));  
	cvCopy(img, temp, NULL);  
	cvResetImageROI(temp);  
	//��ת����map
	// [ m0  m1  m2 ] ===>  [ A11  A12   b1 ]
	// [ m3  m4  m5 ] ===>  [ A21  A22   b2 ]
	float m[6];  
	int w = temp->width;  
	int h = temp->height;  
	m[0] = b;  
	m[1] = a;  
	m[3] = -m[1];  
	m[4] = m[0];  
	// ����ת��������ͼ���м�  
	m[2] = w * 0.5f;  
	m[5] = h * 0.5f;  
	CvMat M = cvMat(2, 3, CV_32F, m);  
	cvGetQuadrangleSubPix(temp, img, &M);  
	cvReleaseImage(&temp);  
}  
void CMatLogic::FindCountor()
{

	IplImage * imgGray = cvCreateImage(cvGetSize(cbgImage2_),8,1);
	cvCvtColor(cbgImage2_,imgGray, CV_RGB2GRAY);

	//if(m_bFilterFont)
	{
		IplConvKernel * myModel;
		myModel=cvCreateStructuringElementEx( //�Զ���5*5,�ο��㣨3,3���ľ���ģ��
			1,1,0,0,CV_SHAPE_RECT
			);
		//cvErode(imgGray,imgGray,myModel,1);
		myModel=cvCreateStructuringElementEx( //�Զ���5*5,�ο��㣨3,3���ľ���ģ��
			7,1,0,0,CV_SHAPE_RECT
			);
		cvDilate(imgGray,imgGray,myModel,1);
	}
	

	cvShowImage("gray",imgGray);

	
	CvSeq *seq = NULL;
	CvMemStorage * stroage = cvCreateMemStorage();
	IplImage* contourimage = cvCreateImage(cvGetSize(imgGray),8,3);
	int numcontours = cvFindContours( imgGray, stroage, &seq, sizeof(CvContour),
		CV_RETR_CCOMP, CV_CHAIN_APPROX_NONE );

	double fSmall = 2000;
	if (-1 != numcontours)
	{
		CvSeq *c = 0;
		int zz = 0;

		int totl = 0;
		cvSet(contourimage,cvScalar(255,255,255));
		cvSet(contourimage,cvScalar(125,125,125));

		CvPoint2D32f rectpoint[4];

		int iLabNum = 0;
		CvContour *testcontour = 0;
		for (c = seq;c !=NULL;c = c->h_next)
		{
			double testdbArea = fabs(cvContourArea(c,CV_WHOLE_SEQ));
			double testdbLength = cvArcLength(c);

			c->block_max;
			cvDrawContours(contourimage,c,cvScalar(0,0,255),cvScalar(0,0,255),0,2);
			CvRect testrect = cvBoundingRect(c);
			//if (testdbArea>=1000 && testdbLength<=1000)
			int area = testrect.height*testrect.width;
			if(area > 250)
			{

				

			
				CvBox2D testbox = cvMinAreaRect2(c);
				cvBoxPoints(testbox,rectpoint);


				if (testrect.width*1.0/testrect.height < 1.5)
				{//���߱Ȳ���������
					continue;
				}

				int Du = 0;
				if(abs(rectpoint[0].x-rectpoint[1].x) < abs(rectpoint[1].x-rectpoint[2].x))
				{
					Du = abs(rectpoint[1].y-rectpoint[2].y)*1.0/abs(rectpoint[1].x-rectpoint[2].x)*180/3.1415;
					//��ת�ǶȲ���������0�����µ�
					if ( Du >=15)
					{
						continue;
					}
				}
				else
				{
					Du = abs(rectpoint[0].y-rectpoint[1].y)*1.0/abs(rectpoint[0].x-rectpoint[1].x)*180/3.1415;
					//��ת�ǶȲ���������0�����µ�
					if (Du >=15)
					{
						continue;
					}

				}
				if (testrect.height < 17)
				{
					continue;
				}
				
				LabInfo * labItem = new LabInfo;
			/*	if(labItem->AddHis(Point(testrect.x,testrect.y),testrect.width,testrect.height,iLabNum,Du))
				{
					iLabNum++;
				}*/
				
				delete labItem;

				cvRectangle(contourimage,cvPoint(testrect.x,testrect.y+testrect.height),
					cvPoint(testrect.x+testrect.width,testrect.y),cvScalar(255,255,0),5);


			
			
				
				for(int i = 0;i<4;i++)
				{
					cvLine(contourimage,cvPointFrom32f(rectpoint[i]),cvPointFrom32f(rectpoint[(i+1)%4]),CV_RGB(0,0,255),2);
				} 

				cvShowImage("grotto" ,contourimage);

			}	

		}
		
	}

	cvReleaseMemStorage(&stroage);
	cvReleaseImage(&contourimage);
	cvReleaseImage(&imgGray);
		

}

void CMatLogic::DoColorSeg()
{
	DoRGBGray();


	IplImage * imgRD = cvCreateImage(cvGetSize(cbgImage2_),8,1);
	IplImage * imgGD = cvCreateImage(cvGetSize(cbgImage2_),8,1);
	IplImage * imgBD = cvCreateImage(cvGetSize(cbgImage2_),8,1);

	

	cvSmooth(cbgImage2_,cbgImage2_);
	cvCvtColor(cbgImage2_,cbgImage2_,CV_RGB2HSV);
	cvSplit(cbgImage2_,imgRD,imgGD,imgBD,0);

	int w = cbgImage_->width;
	int h = cbgImage_->height;

	int sum = 0;
	for (int i=0;i<h;i++)
	{
		for (int j = 0;j<w;j++)
		{
			sum+=(unsigned char)CV_IMAGE_ELEM(cbImgGray,unsigned char,i,j);
		}
	}
	int limit = sum/(w*h);

	for (int i=0;i<h;i++)
	{
		for (int j = 0;j<w;j++)
		{
			int iValueR = CV_IMAGE_ELEM(imgRD,unsigned char,i,j);
			int iValue = CV_IMAGE_ELEM(imgGD,unsigned char,i,j);
			float fG = iValue/255.0;

			iValue = CV_IMAGE_ELEM(imgBD,unsigned char,i,j); 
			float fB = iValue/255.0;


			//if(limit > 140 || limit < 90)
			{
				m_bFilterFont = false;
				if(iValueR > 95 && iValueR < 122
					&& fG > 0.35 && fG < 1.0 && fB > 0.3 && fB < 1)
				{
					CV_IMAGE_ELEM(imgRD,unsigned char,i,j) =  0;
					CV_IMAGE_ELEM(imgGD,unsigned char,i,j) =  0;
					CV_IMAGE_ELEM(imgBD,unsigned char,i,j) =  255;
				}
				else
				{
					CV_IMAGE_ELEM(imgRD,unsigned char,i,j) =  0;
					CV_IMAGE_ELEM(imgGD,unsigned char,i,j) =  0;
					CV_IMAGE_ELEM(imgBD,unsigned char,i,j) =  0;
				}


			}
			/*else
			{
				m_bFilterFont = true;
				if((unsigned char)CV_IMAGE_ELEM(cbImgGray,unsigned char,i,j) > (limit+35))
				{
					CV_IMAGE_ELEM(imgRD,unsigned char,i,j) =  0;
					CV_IMAGE_ELEM(imgGD,unsigned char,i,j) =  0;
					CV_IMAGE_ELEM(imgBD,unsigned char,i,j) =  255;
				}
				else
				{
					CV_IMAGE_ELEM(imgRD,unsigned char,i,j) =  0;
					CV_IMAGE_ELEM(imgGD,unsigned char,i,j) =  0;
					CV_IMAGE_ELEM(imgBD,unsigned char,i,j) =  0;
				}
			}
		*/
			

		}
	}

	cvMerge(imgRD,imgGD,imgBD,0,cbgImage2_);

	

	cvCvtColor(cbgImage2_,cbgImage2_,CV_HSV2BGR);
	cvCvtColor(cbgImage2_,cbgImage2_,CV_BGR2RGB);

	cvCopy(cbgImage2_,cbgImage_);
	

	cvReleaseImage(&imgBD);
	cvReleaseImage(&imgGD);
	cvReleaseImage(&imgRD);



}
void CMatLogic::DoReadImg(char * pathName)
{
	IplImage * src1  = cvLoadImage(pathName);
	if (src1 == NULL)
	{
		return;
	}	

	cvCvtColor(src1,src1,CV_BGR2RGB);
	Chang2_4(src1);

	cvReleaseImage(&src1);

}
