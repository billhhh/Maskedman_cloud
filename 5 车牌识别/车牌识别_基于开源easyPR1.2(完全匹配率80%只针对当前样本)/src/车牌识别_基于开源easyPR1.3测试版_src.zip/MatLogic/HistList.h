#pragma once
#include <vector>
#include <highgui.h>
#include "LabInfo.h"
using namespace std;
struct Compare_Result
{
	int labID;//���ĸ�lab���бȽ�
	double score;//�Ƚϵķ���
	int distance;//����֮��ľ���
};

class CHistList
{
public:
	CHistList(void);
	~CHistList(void);


	int GetSize(){return m_listHis.size();}
private:
	vector<LabInfo*> m_listHis;
	std::map<int,LabInfo*> m_mapHisNum;
	double m_limitScore;
};
