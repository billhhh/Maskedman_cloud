#include "FindEdge.h"

CFindEdge::CFindEdge(void)
{
	m_paintVer = NULL;
	m_paintHorizon = NULL;
}


CFindEdge::~CFindEdge(void)
{

}
/*
���� ��λ���Ƶĸ߶ȣ�����λ�ã�
*/
bool CFindEdge::ProcHorizon(Mat src,int& start,int& end)
{
	CalHorTouying(src);

	int xPos = src.rows*1.0;
	if (src.rows*2 > src.cols)
	{
		return false;
	}

	listPosInfo.clear();
	int countWhite = 0;
	for (int i=0;i<m_matHorizon.rows;i++)
	{
		int iValue =  m_matHorizon.data[m_matHorizon.step*i+xPos];
		if ((unsigned char)m_matHorizon.data[m_matHorizon.step*i+xPos] == 255)
		{
			if (countWhite == 0)
			{
				PosInfo posItem;
				posItem.posStart = i;
				listPosInfo.push_back(posItem);
			}
			countWhite++;
		}
		else
		{
			if(countWhite > 0)
			{
				//PosInfo���м�¼
				//
				listPosInfo[listPosInfo.size()-1].posEnd = i;
				listPosInfo[listPosInfo.size()-1].whiteCount = countWhite;

				countWhite = 0;
			}

		}
	}

	if ((unsigned char)m_matHorizon.data[m_matHorizon.step*(m_matHorizon.rows-1)+xPos] == 255)
	{
		if(listPosInfo.size() > 0)
		{
			listPosInfo[listPosInfo.size()-1].posEnd = m_matHorizon.rows-1;
		}
	
	}

	int maxCount = 0;
	int maxPos = 0;
	//��һЩ��խ�Ĺ��˵�
	for (int i=listPosInfo.size()-1;i>=0;i--)
	{
		if(listPosInfo[i].whiteCount > maxCount)
		{
			maxCount = listPosInfo[i].whiteCount;
			maxPos = i;
		}
	}
	if (listPosInfo.size() > 0)
	{
		start = listPosInfo[maxPos].posStart;
		end = listPosInfo[maxPos].posEnd;
		return true;
	}




	return false;
}
//ˮƽͶӰ
bool CFindEdge::ProcHorizon(IplImage * src,int& start,int& end)
{
	CalHorTouying(src);

	
	listPosInfo.clear();
	int countWhite = 0;
	for (int i=0;i<m_paintHorizon->height;i++)
	{
		if ((unsigned char)CV_IMAGE_ELEM(m_paintHorizon,unsigned char,i,45) == 255)
		{
			if (countWhite == 0)
			{
				PosInfo posItem;
				posItem.posStart = i;
				listPosInfo.push_back(posItem);
			}
			countWhite++;
		}
		else
		{
			if(countWhite > 0)
			{
				//PosInfo���м�¼
				//
				listPosInfo[listPosInfo.size()-1].posEnd = i;
				listPosInfo[listPosInfo.size()-1].whiteCount = countWhite;

				countWhite = 0;
			}

		}
	}

	//��һЩ��խ�Ĺ��˵�
	for (int i=listPosInfo.size()-1;i>=0;i--)
	{
		if(listPosInfo[i].whiteCount > 40)
		{
			//listPosInfo.erase(listPosInfo.begin()+i);
			start = listPosInfo[i].posStart;
			end = listPosInfo[i].posEnd;
			return true;
		}
	}

	

	return false;

}

bool CFindEdge::ProcVertical(Mat src,int& left,int& right)
{
	CalVerTouying(src);

	//����������ɨ��
	left = 0;
	right = 0;

	int posY = m_matVertical.rows*0.18;
	for (int j=0;j<m_matVertical.cols;j++)
	{
		if (m_matVertical.ptr<uchar>(m_matVertical.rows-posY-1)[j] == 255)
		{
			left = j;
			left-=m_matVertical.rows*0.05;
			if (left < 0)
			{
				left = 0;
			}
			break;
		}
	}

	for (int j=m_matVertical.cols-1;j>=0;j--)
	{
		if (m_matVertical.ptr<uchar>(m_matVertical.rows-posY-1)[j] == 255)
		{
			right = j;
			right+=m_matVertical.rows*0.06;
			if (right >= m_matVertical.cols)
			{
				right = m_matVertical.cols-1;
			}
			break;
		}
	}

	if (left < right)
	{
		return true;
	}

	return false;
}
/*
���� �ҵ��߽��Ƿ�ɹ����ɹ��򷵻�true
*/
bool CFindEdge::ProcVertical(IplImage * src,int& start,int& end)
{
	CalVerTouying(src);

	listPosInfo.clear();
	int countWhite = 0;
	for (int i=0;i<m_paintVer->width;i++)
	{
		if ((unsigned char)CV_IMAGE_ELEM(m_paintVer,unsigned char,m_paintVer->height-4,i) == 255)
		{
			if (countWhite == 0)
			{
				PosInfo posItem;
				posItem.posStart = i;
				listPosInfo.push_back(posItem);
			}
			countWhite++;
		}
		else
		{
			if(countWhite > 0)
			{
				//PosInfo���м�¼
				//
				listPosInfo[listPosInfo.size()-1].posEnd = i;
				listPosInfo[listPosInfo.size()-1].whiteCount = countWhite;

				countWhite = 0;
			}
			
		}
	}

	//��һЩ��խ�Ĺ��˵�
	for (int i=listPosInfo.size()-1;i>=0;i--)
	{
		if(listPosInfo[i].whiteCount <4)
		{
			listPosInfo.erase(listPosInfo.begin()+i);
		}
	}

	

	if(listPosInfo.size() >= 5)
	{
		//����һ���ı�ֵ
		for (int i=0;i<listPosInfo.size()-3;i++)
		{
			double ratio1 = (listPosInfo[i+1].posStart-listPosInfo[i].posEnd)*1.0/(listPosInfo[i+2].posStart-listPosInfo[i+1].posEnd);
			double ratio2 = (listPosInfo[i+1].posStart-listPosInfo[i].posEnd)*1.0/(listPosInfo[i+3].posStart-listPosInfo[i+2].posEnd);
			//double ratio3 = (listPosInfo[i+1].posStart-listPosInfo[i].posEnd)*1.0/(listPosInfo[i+4].posStart-listPosInfo[i+3].posEnd);

			double kuanBi1 = (listPosInfo[i].posEnd-listPosInfo[i].posStart)*1.0/(listPosInfo[i+1].posEnd-listPosInfo[i+1].posStart);
			double kuanBi2 = (listPosInfo[i].posEnd-listPosInfo[i].posStart)*1.0/(listPosInfo[i+2].posEnd-listPosInfo[i+2].posStart);
			
		
			//
			if((ratio1 >2.0 && ratio1 < 5.0 
				&& ratio2 >1.0 && ratio2 < 4.4
				&& kuanBi1 < 1.3 && kuanBi1 > 0.8
				&& kuanBi2 < 1.3 && kuanBi2 > 0.8)
				||(ratio1 >1.2 && ratio1 < 3 
				&& ratio2 >1.0 && ratio2 < 4.4
				&& kuanBi1 < 4.2 && kuanBi1 > 3
				&& kuanBi2 < 1.3 && kuanBi2 > 0.8))
			{
				int zifuKuang = listPosInfo[i].posEnd-listPosInfo[i].posStart;
				int yiKuan = listPosInfo[i+2].posStart-listPosInfo[i+1].posStart;
				//�ҵ��ĵ�һ����ĸ
				start = listPosInfo[i].posStart-yiKuan*1.1 ;
				end = listPosInfo[i+1].posEnd+yiKuan*4+zifuKuang*0.2;

				//�ҵ�֮�������
				for (int j=0;j<m_paintVer->height;j++)
				{
					CV_IMAGE_ELEM(m_paintVer,unsigned char,j,start-1) = 128;
					CV_IMAGE_ELEM(m_paintVer,unsigned char,j,start) = 128;
					CV_IMAGE_ELEM(m_paintVer,unsigned char,j,start+1) = 128;

					CV_IMAGE_ELEM(m_paintVer,unsigned char,j,end-1) = 128;
					CV_IMAGE_ELEM(m_paintVer,unsigned char,j,end) = 128;
					CV_IMAGE_ELEM(m_paintVer,unsigned char,j,end+1) = 128;
				}

				return true;
			}
		}
	}

	return false;
	
}

void CFindEdge::CalVerTouying(Mat src)
{
	m_matVertical = src.clone();
	m_matVertical.setTo(0);

	int* horizon=new int[src.cols];
	memset(horizon,0,src.cols*4);
	int x,y;

	int s,t;
	for(x=0;x<src.cols;x++)
	{
		for(y=src.rows*0.2;y<src.rows*0.7;y++)
		{
			s= src.data[y*src.step+x];		
			if(s == 255)
				horizon[x]++;					
		}		
	}

	for(x=0;x<src.cols;x++)
	{
		if (horizon[x] < 6)
		{
			continue;
		}
		for(y=0;y<horizon[x];y++)
		{		
			m_matVertical.data[(src.rows-y-1)*src.cols+x] = 255;
		}		
	}
	delete[] horizon;
}

void CFindEdge::CalHorTouying(Mat src)
{
	m_matHorizon = src.clone();
	m_matHorizon.setTo(0);
	
	int* horizon=new int[src.rows];
	memset(horizon,0,src.rows*4);
	int x,y;

	int s,t;
	for(x=0;x<src.rows;x++)
	{
		for(y=0;y<src.cols;y++)
		{
			s= src.data[x*src.step+y];		
			if(s ==255)
				horizon[x]++;					
		}		
	}

	for(x=0;x<src.rows;x++)
	{
		if (horizon[x] < 6)
		{
			continue;
		}
		for(y=0;y<horizon[x];y++)
		{		
			m_matHorizon.data[x*src.cols+y] = 255;
		}		
	}
	delete[] horizon;
	//erode(m_paintHorizon,m_paintHorizon,0,1);
}
void CFindEdge::CalHorTouying(IplImage*src)
{
	m_paintHorizon=cvCloneImage(src);
	cvZero(m_paintHorizon);
	int* horizon=new int[src->height];
	memset(horizon,0,src->height*4);
	int x,y;
	CvScalar s,t;
	for(x=0;x<src->height;x++)
	{
		for(y=0;y<src->width;y++)
		{
			s=cvGet2D(src,x,y);			
			if(s.val[0]==255)
				horizon[x]++;					
		}		
	}

	for(x=0;x<src->height;x++)
	{
		if (horizon[x] < 6)
		{
			continue;
		}
		for(y=0;y<horizon[x];y++)
		{		
			t.val[0]=255;
			cvSet2D(m_paintHorizon,x,y,t);		
		}		
	}
	cvErode(m_paintHorizon,m_paintHorizon,0,1);
}

void CFindEdge::CalVerTouying(IplImage * src)
{
	if (m_paintVer != NULL)
	{
		cvReleaseImage(&m_paintVer);
		m_paintVer = NULL;
	}
	m_paintVer=cvCreateImage( cvGetSize(src),IPL_DEPTH_8U, 1 );
	cvZero(m_paintVer);
	int* v=new int[src->width];
	memset(v,0,src->width*4);
	int x,y;
	CvScalar s,t;
	for(x=0;x<src->width;x++)
	{
		for(y=0;y<src->height;y++)
		{
			s=cvGet2D(src,y,x);			
			if(s.val[0]==255)
				v[x]++;					
		}		
	}

	for(x=0;x<src->width;x++)
	{
		if (v[x] < 6)
		{
			continue;
		}
		for(y=0;y<v[x];y++)
		{		
			t.val[0]=255;
			cvSet2D(m_paintVer,src->height-y-1,x,t);		
		}		
	}
	cvErode(m_paintVer,m_paintVer,0,1);
}

void CFindEdge::EraseLonePoint(IplImage * img)
{
	CvMemStorage* storage = cvCreateMemStorage(0);
	IplImage * tmpImg = cvCloneImage(img);
	CvSeq* contours = 0;
	cvClearMemStorage(storage);
	cvFindContours( tmpImg, storage, &contours, sizeof(CvContour),
		CV_RETR_CCOMP, CV_CHAIN_APPROX_NONE );

	int comp_count = 0;
	for( ; contours != 0; contours = contours->h_next, comp_count++ )
	{
		vector<Point> tmpPoints;
		for (int k=0;k<contours->total;k++)
		{
			CvPoint * pt = (CvPoint*)cvGetSeqElem(contours,k);
			tmpPoints.push_back(*pt);
		}
		CvPoint * pts = new CvPoint[tmpPoints.size()];
		for (int m=0;m<tmpPoints.size();m++)
		{
			pts[m] = tmpPoints[m];
		}
		if (tmpPoints.size() < 80)
		{
			cvFillConvexPoly(img,pts,tmpPoints.size(),cvScalar(0,0,0));
		}

	}

	cvReleaseImage(&tmpImg);
	cvReleaseMemStorage(&storage);
}

void CFindEdge::EraseToBottomEdge(IplImage * img)
{
	int iCountWhite = 0;
	//��
	for (int i=0;i<img->width;i++)
	{
		if (i == 252)
		{
			int test = 0;
		}
		bool bFind = false;
		for (int j=0;j<10;j++)
		{
			unsigned char cvalue = CV_IMAGE_ELEM(img,unsigned char,j,i) ;
			if (cvalue== 255)
			{
				bFind = true;
				break;
			}
		}
		if (bFind)
		{
			iCountWhite++;
		}
		else
		{
			if(iCountWhite > 80)
			{
				break;
			}
			else
			{
				iCountWhite = 0;
			}
			
		}
	}
	if (iCountWhite > 80)
	{
		for (int i=0;i<img->width;i++)
		{
			bool bFind = false;
			for (int j=0;j<10;j++)
			{
				CV_IMAGE_ELEM(img,unsigned char,j,i) = 0;
			}
		}
	}

	//��
	iCountWhite = 0;
	for (int i=0;i<img->width;i++)
	{
		if (i == 252)
		{
			int test = 0;
		}
		bool bFind = false;
		for (int j=0;j<10;j++)
		{
			unsigned char cvalue = CV_IMAGE_ELEM(img,unsigned char,img->height-j-1,i) ;
			if (cvalue== 255)
			{
				bFind = true;
				break;
			}
		}
		if (bFind)
		{
			iCountWhite++;
		}
		else
		{
			if(iCountWhite > 80)
			{
				break;
			}
			else
			{
				iCountWhite = 0;
			}

		}
	}
	if (iCountWhite > 80)
	{
		for (int i=0;i<img->width;i++)
		{
			bool bFind = false;
			for (int j=0;j<10;j++)
			{
				CV_IMAGE_ELEM(img,unsigned char,img->height-j-1,i) = 0;
			}
		}
	}

	
}
