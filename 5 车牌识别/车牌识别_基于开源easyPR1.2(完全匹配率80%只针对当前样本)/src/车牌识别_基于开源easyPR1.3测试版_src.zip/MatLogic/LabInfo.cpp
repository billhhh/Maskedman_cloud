#include "LabInfo.h"

LabInfo::LabInfo(void)
{

}

LabInfo::~LabInfo(void)
{
	
}

int LabInfo::GetAvgGray(IplImage * img,Point ptTopLeft,int w,int h)
{
	int sum = 0;
	for (int i=ptTopLeft.y;i<ptTopLeft.y+h;i++)
	{
		for (int j = ptTopLeft.x;j<ptTopLeft.x+w;j++)
		{
			sum+=(unsigned char)CV_IMAGE_ELEM(img,unsigned char,i,j);
		}
	}

	int limit = sum*1.0/(w*h);
	return limit;
}

void LabInfo::BinaryImg(Mat& img,int avgColor)
{
	int span = 40;
	for (int i=0;i<img.rows;i++)
	{
		for (int j=0;j<img.cols;j++)
		{
			int iValue = img.data[i*img.step+j];
			if (iValue < (avgColor+span) && iValue > (avgColor-span))
			{
				img.data[i*img.step+j] = 0;
			}
			else
			{
				img.data[i*img.step+j] = 255;
			}
		}
	}
}

int LabInfo::GetAvgGray(Mat img)
{
	int sum = 0;
	for (int i=0;i<img.rows;i++)
	{
		for (int j = 0;j<img.cols;j++)
		{
			sum+= img.data[i*img.step+j];
		}
	}

	int limit = sum*1.0/(img.rows*img.cols);
	return limit;
}


void LabInfo::OppositImag(IplImage * src)
{
	for (int i=0;i<src->height;i++)
	{
		for (int j=0;j<src->width;j++)
		{
			if ((unsigned char)CV_IMAGE_ELEM(src,unsigned char,i,j) == 0)
			{
				CV_IMAGE_ELEM(src,unsigned char,i,j) = 255;
			}
			else
			{
				CV_IMAGE_ELEM(src,unsigned char,i,j) = 0;
			}
		}
	}
}

//����ͶӰ������λ��
bool LabInfo::GetWidthByShadow(Mat mat,int& posLeft,int& posRight)
{
	bool bResult = false;

	if(m_findEdge.ProcVertical(mat,posLeft,posRight))
	{
		bResult = true;
	}

	
	imwrite("image/tmp/tmpsrc.jpg",mat);
	imwrite("image/tmp/verticalimg.jpg",m_findEdge.m_matVertical);
	return bResult;
}
//����ͶӰ ���Ƶ�����λ��
bool LabInfo::GetHeightByShadow(Mat mat,int& posTop,int& posBottom)
{
	bool bResult = false;
	int start;
	int end;
	if(m_findEdge.ProcHorizon(mat,posTop,posBottom))
	{
		bResult = true;
	}

	char szBuf[512];
	sprintf(szBuf,"image/tmp/horizongimg.jpg");
	imwrite(szBuf,m_findEdge.m_matHorizon);
	return bResult;
}

bool LabInfo::GetHorizonshadowAuto(IplImage * img,Point ptTopLeft,int w,int h,int du)
{
	ptTopLeft.x = m_ptLeftTopNow.x;	
	w = m_wNow;



	IplImage * cutImg = cvCreateImage(cvSize(w,h),8,1);
	IplImage * tmpImg = cvCloneImage(img);
	if (du > 3)
	{
		//CMatLogic::Instance()->rotateImage2(tmpImg,du);
	}

	cvSetImageROI(tmpImg,cvRect(ptTopLeft.x,ptTopLeft.y,w,h));
	cvCopy(tmpImg,cutImg);
	cvResetImageROI(img);
	cvReleaseImage(&tmpImg);


	double ratio = 100.0/cutImg->height;
	int width = cutImg->width*ratio;
	IplImage * src = cvCreateImage(cvSize(width,100),8,1);
	cvResize(cutImg,src);	
	cvReleaseImage(&cutImg);

	int sum = 0;
	for (int i=ptTopLeft.y+h*0.1;i<ptTopLeft.y+h*0.8;i++)
	{
		for (int j = ptTopLeft.x;j<ptTopLeft.x+w;j++)
		{
			sum+=(unsigned char)CV_IMAGE_ELEM(img,unsigned char,i,j);
		}
	}
	int limit = sum/(w*h*0.8);

	cvThreshold(src,src,limit+38,255,CV_THRESH_BINARY_INV);
	//����ı���ɫ
	OppositImag(src);

	cvShowImage("horrizon",src);

	
	int start;
	int end;
	if(m_findEdge.ProcHorizon(src,start,end))
	{
		ptTopLeft.y = ptTopLeft.y+start*1.0/ratio;
		h = (end-start)/ratio;


		cutImg = cvCreateImage(cvSize(w,h),8,1);
		tmpImg = cvCloneImage(img);
		if (du > 3)
		{
			//CMatLogic::Instance()->rotateImage2(tmpImg,du);
		}

		cvSetImageROI(tmpImg,cvRect(ptTopLeft.x,ptTopLeft.y,w,h));
		cvCopy(tmpImg,cutImg);
		cvResetImageROI(img);
		cvReleaseImage(&tmpImg);


		ratio = 100.0/cutImg->height;
		width = cutImg->width*ratio;
		src = cvCreateImage(cvSize(width,100),8,1);
		cvResize(cutImg,src);	
		cvReleaseImage(&cutImg);
		cvShowImage("cut",src);

		return true;
	}
	return false;
}


bool LabInfo::GetVershadowAuto(IplImage * img,Point ptTopLeft,int w,int h,int du)
{

	int sum = 0;

	//��ѡ������ľ�ֵ
	int limit = GetAvgGray(img,ptTopLeft,w,h);


	//ѡ���������������죨ѡ�еĳ��������С����
	//�߶ȼ�СΪ��(���ٷǳ��������Ӱ��)
	ptTopLeft.y = ptTopLeft.y + h*0.10;//�߶���С
	h = h*0.85;
	ptTopLeft.x = ptTopLeft.x -2*h;//������չ
	if (ptTopLeft.x < 0)
	{
		ptTopLeft.x = 0;
	}
	w = w+4*h;
	if (ptTopLeft.x+w > img->width)
	{
		w = img->width - ptTopLeft.x; 
	}

	//��ȡ����
	IplImage * cutImg = cvCreateImage(cvSize(w,h),8,1);
	IplImage * tmpImg = cvCloneImage(img);
	if (du > 3)
	{
		//CMatLogic::Instance()->rotateImage2(tmpImg,du);
	}
	cvSetImageROI(tmpImg,cvRect(ptTopLeft.x,ptTopLeft.y,w,h));
	cvCopy(tmpImg,cutImg);
	cvResetImageROI(img);
	cvReleaseImage(&tmpImg);

	

	//ͳһ�Ŵ������С�߶�Ϊ100
    double ratio = 100.0/cutImg->height;
	int width = cutImg->width*ratio;
	IplImage * src = cvCreateImage(cvSize(width,100),8,1);
	cvResize(cutImg,src);	
	cvReleaseImage(&cutImg);

	//��ֵ��
	cvThreshold(src,src,limit+38,255,CV_THRESH_BINARY_INV);

	//����ı���ɫ
	OppositImag(src);

	m_findEdge.EraseLonePoint(src);
	m_findEdge.EraseToBottomEdge(src);


	
	//m_findEdge.Proc(paintx);
	int posStart;
	int posEnd;
	if(m_findEdge.ProcVertical(src,posStart,posEnd))
	{
		char szBuf[256];
		sprintf(szBuf,"Ͷ%d",labNum);
		cvShowImage(szBuf,m_findEdge.m_paintVer);
		
		sprintf(szBuf,"��%d",labNum);
		cvShowImage(szBuf,src);
		m_ptLeftTopNow.x = ptTopLeft.x + posStart*1.0/ratio;
		m_wNow = (posEnd-posStart)*1.0/ratio;

		return true;
	}
	

	return false;
}
