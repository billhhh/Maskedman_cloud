
#include "LowBilateral.h"
#include "matlogic.h"

IplImage * Bilateral::m_dstR = NULL;
IplImage * Bilateral::m_dstG = NULL;
IplImage * Bilateral::m_dstB = NULL;
int Bilateral::m_index = 0;


Bilateral::Bilateral()
{
	size_d = 6;
	BilateralTemplate = new double *[10];
	for(int i = 0; i< 10; ++i)
	{
		BilateralTemplate[i] = new double[10];
	}
	for (int x = 0;x < 10; ++x)
	{
		for (int y = 0;y < 10; ++y)
		{
			BilateralTemplate[x][y] = calGaussianTemplate(x,y,size_d);
		}
	}
	
	ExpValue = new double[256];
	for (int i=0;i<256;++i)
	{
		ExpValue[i] = exp((-i*i)*1.0/(2*10*10));
	}

	m_src = NULL;
}

Bilateral::~Bilateral()
{
	for (int c = 0; c < 10; c++)
	{
		delete []BilateralTemplate[c];
		BilateralTemplate[c] = NULL;
	}

	delete[] ExpValue;
	ExpValue = NULL;

	
}

inline double Bilateral::calGaussianTemplate(double x, double y,double size_d)
{
	return exp(-((x-5)*(x-5)+(y-5)*(y-5))/(2*size_d*size_d)); 
}

Mat Bilateral::FixImage(Mat origin, int r)
{
	int H = origin.rows + 2 * r;
	int W = origin.cols + 2 * r;
	int h1,w1,h2,w2,h3,w3,h4,w4;

	Mat Img_Fix = Mat(Size(cvSize(W, H)),8,1);
	//blur(Img_Fix,Size(3,3));
	for (int i = r; i < r + origin.rows; ++i)
	{
		for (int j = r; j < r + origin.cols; ++j)
		{
			//CV_IMAGE_ELEM(Img_Fix ,uchar, i, j) = CV_IMAGE_ELEM(origin, uchar, i - r, j - r);
			Img_Fix.ptr<uchar>(i)[j] = origin.ptr<uchar>(i-r)[j-r];
		}
	}

	for (h1 = 0; h1 < r; ++h1)
	{
		for (w1 = r; w1 < r + origin.cols; ++w1 )
		{
			//CV_IMAGE_ELEM(Img_Fix ,uchar, h1, w1) = CV_IMAGE_ELEM(origin, uchar, h1, w1 - r);

			Img_Fix.ptr<uchar>(h1)[w1] = origin.ptr<uchar>(h1)[w1-r];

		}

	}

	for (h2 = origin.rows + r; h2 < H; ++h2)
	{
		for (w2 = r; w2 < r + origin.cols; ++w2)
		{
			//CV_IMAGE_ELEM(Img_Fix ,uchar, h2, w2) = CV_IMAGE_ELEM(origin, uchar, h2 - 2 * r, w2 - r);
			Img_Fix.ptr<uchar>(h2)[w2] = origin.ptr<uchar>(h2 - 2 * r)[w2 - r];


		}

	}
    
	for (h3 = 0; h3 < H; ++h3)
	{
		for (w3 = 0; w3 < r; ++w3 )
		{
			//CV_IMAGE_ELEM(Img_Fix ,uchar, h3, w3) = CV_IMAGE_ELEM(Img_Fix, uchar, h3 , w3 + r);
			Img_Fix.ptr<uchar>(h3)[w3] = Img_Fix.ptr<uchar>(h3)[w3 + r];

		}

	}

	for (h4 = 0; h4 < H; ++h4)
	{
		for (w4 = origin.cols + r; w4 < W; ++w4 )
		{
			//CV_IMAGE_ELEM(Img_Fix ,uchar, h4, w4) = CV_IMAGE_ELEM(Img_Fix, uchar, h4, w4 - 2 * r);
			Img_Fix.ptr<uchar>(h4)[w4] = Img_Fix.ptr<uchar>(h4)[w4 - 2 * r];

		}

	}
	return Img_Fix;

}



Mat Bilateral::BilateralFilter(Mat img_ori, int size_d)
{

	double tmp;
	int Height = img_ori.rows;
	int Width  = img_ori.cols;
	double sigma_r = 10;
	int r = 5;
	double GaBil;
	Mat dst;
	Mat Img_Fix ;
	int Image_point;
	int Image_center;

	Img_Fix = FixImage(img_ori,r);

	
	dst = img_ori.clone();

	for(int i = 0; i < Height; ++i)
	{
		for (int j = 0; j < Width; ++j)
		{
					tmp = 0;
					sum = 0;	
					
					Image_center = Img_Fix.ptr<uchar>(i+r)[j+r] ;//CV_IMAGE_ELEM(Img_Fix, uchar , i + r, j + r);

					for (int x = 0; x < 10; ++x)
					{
						for (int y = 0; y < 10; ++y)
						{
							int dx = i + x;
							int dy = j + y;
							Image_point =Img_Fix.ptr<uchar>(dx)[dy] ;// CV_IMAGE_ELEM(Img_Fix,uchar,dx,dy);

							GaBil = 	ExpValue[abs(Image_point - Image_center)];

							tmp = tmp + Image_point * BilateralTemplate[x][y] * GaBil ;//��ʱ�������̻ᳬ����Χ
							sum += BilateralTemplate[x][y] * GaBil;

						}

					}
					//CV_IMAGE_ELEM(dst, uchar, i, j) = uchar(tmp/sum);

					dst.ptr<uchar>(i)[j] = uchar(tmp/sum);
				

		}
	}

	return dst;


}
