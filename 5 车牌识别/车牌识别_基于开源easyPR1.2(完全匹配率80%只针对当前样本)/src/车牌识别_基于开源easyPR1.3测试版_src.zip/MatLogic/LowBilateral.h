#pragma once

#include "iostream"
#include "fstream"
#include "cv.h"
#include "highgui.h"
#include "string.h"
#include "math.h"
#include "matlogic.h"
using namespace std;



enum Bilateral_filter
{
	Bilateral_filter_R,
	Bilateral_filter_B,
	Bilateral_filter_G
};

class Bilateral
{
public:
	double sum;
	double **BilateralTemplate;
	double * ExpValue;
	double size_d;
	Bilateral();
	~Bilateral();
	static int m_index;

	Mat BilateralFilter(Mat img_ori, int size_d);
private:	
	Mat FixImage(Mat origin, int r);
	inline double calGaussianTemplate(double x, double y, double size_d);
private:
	IplImage * m_src;
	static IplImage * m_dstR;
	static IplImage * m_dstG;
	static IplImage * m_dstB;


	Bilateral_filter m_filterType;
};
