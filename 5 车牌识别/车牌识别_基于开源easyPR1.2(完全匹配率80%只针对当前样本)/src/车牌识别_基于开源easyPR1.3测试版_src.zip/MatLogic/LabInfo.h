#pragma once
#include<cv.h>
#include<highgui.h>
#include "opencv2/imgproc/imgproc.hpp"
#include "cxcore.h"
#include "LabInfo.h"
#include <vector>
#include "FindEdge.h"
using namespace cv;


enum SEL_TYPE
{
	SEL_TYPE_NONE,
	SEL_TYPE_SelSEG,
	SEL_TYPE_AddSegBYSimilar,
	SEL_TYPE_DELSEG
};

class LabInfo
{
public:
	~LabInfo(void);
	CFindEdge m_findEdge;
	int labNum;//lab�����
	bool GetVershadowAuto(IplImage * img,Point ptTopLeft,int w,int h,int du);
	bool GetHorizonshadowAuto(IplImage * img,Point ptTopLeft,int w,int h,int du);
	bool GetHeightByShadow(Mat mat,int& posTop,int& posBottom);//����ͶӰ���
	bool GetWidthByShadow(Mat mat,int& posLeft,int& posRight);//����ͶӰ������λ��


	void AddPoint(int&x,int& y);

	LabInfo();
private:
	int GetAvgGray(IplImage * img,Point ptTopLeft,int w,int h);
	int GetAvgGray(Mat img);
	void BinaryImg(Mat& img,int avgColor);

	void OppositImag(IplImage * src);


	Point m_ptLeftTopNow;
	int m_wNow;
};
