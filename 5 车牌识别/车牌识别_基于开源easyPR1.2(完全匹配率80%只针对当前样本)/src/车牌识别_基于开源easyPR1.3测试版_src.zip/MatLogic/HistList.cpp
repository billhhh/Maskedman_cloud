#include "HistList.h"
#include<cv.h>
#include<highgui.h>
#include "opencv2/imgproc/imgproc.hpp"
#include "cxcore.h"
#include <cmath>
#include <vector>
#include "matlogic.h"
#include "../edge/BgDefaults.h"
CHistList::CHistList(void)
{
	m_listHis.clear();
	m_limitScore = 0.59;
}

CHistList::~CHistList(void)
{

}

