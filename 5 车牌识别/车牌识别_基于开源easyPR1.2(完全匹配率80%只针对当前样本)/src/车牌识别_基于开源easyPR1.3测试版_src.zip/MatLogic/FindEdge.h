#pragma once
#include<cv.h>
#include<highgui.h>
#include "opencv2/imgproc/imgproc.hpp"
#include "cxcore.h"
#include <vector>
using namespace cv;
class CFindEdge
{
	struct PosInfo
	{
		int posStart;
		int posEnd;
		int whiteCount;
		PosInfo()
		{
			posEnd = 0;
			posStart = 0;
			whiteCount = 0;
		}
	};
public:
	CFindEdge(void);
	~CFindEdge(void);
	bool ProcVertical(IplImage * src,int& start,int& end);
	bool ProcVertical(Mat src,int& left,int& right);


	bool ProcHorizon(IplImage * src,int& start,int& end);
	bool ProcHorizon(Mat src,int& start,int& end);

	//ȥ�����±߽�
	void EraseToBottomEdge(IplImage * img);

	void EraseLonePoint(IplImage * img);//ɾ��������


	void CalVerTouying(IplImage * src);
	void CalHorTouying(IplImage * src);
	void CalHorTouying(Mat src);
	void CalVerTouying(Mat src);
private:
	vector<PosInfo> listPosInfo;

public:
	IplImage * m_paintVer;
	IplImage * m_paintHorizon;

	Mat m_matHorizon;
	Mat m_matVertical;
};
