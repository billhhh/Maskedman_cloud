#include "CannyEdgeDetect.h"
#include "./opencv2/core/core_c.h"
#include "./opencv2/imgproc/types_c.h"
#include "./opencv2/imgproc/imgproc_c.h"

CCannyEdgeDetect::CCannyEdgeDetect(void)
{
	m_weightMap = NULL;
	m_weightMapSmall = NULL;
}

CCannyEdgeDetect::~CCannyEdgeDetect(void)
{
	if (m_weightMap != NULL)
	{
		delete[] m_weightMap;
		m_weightMap = NULL;
	}

	if (m_weightMapSmall != NULL)
	{
		delete[] m_weightMapSmall;
		m_weightMapSmall = NULL;
	}
}

double CCannyEdgeDetect::GetMainEdge(int index)
{
	return m_weightMap[index];
}

double CCannyEdgeDetect::GetMeanShiftWeight(int index)
{
	return (1-m_weightMap[index]-m_weightMapSmall[index])*0.8+0.1;
}

double CCannyEdgeDetect::GetEnergyWeightMap(int index)
{
	return m_weightMap[index]+m_weightMapSmall[index];
}

void CCannyEdgeDetect::ComputeEdgeInfo(IplImage * src)
{
	IplImage * pGrayImg =  cvCreateImage(cvGetSize(src), IPL_DEPTH_8U, 1);

	cvCvtColor(src,pGrayImg,CV_RGB2GRAY);
	if (m_weightMap != NULL)
	{
		delete[] m_weightMap;
		m_weightMap = NULL;
	}
	if (m_weightMapSmall != NULL)
	{
		delete[] m_weightMapSmall;
		m_weightMapSmall = NULL;
	}


	IplImage * pCannyImg =  cvCreateImage(cvGetSize(src), IPL_DEPTH_8U, 1);
	cvZero(pCannyImg);
	cvCanny(pGrayImg, pCannyImg, 7, 84, 3);
	
	m_weightMap = new float[src->width*src->height];
	m_weightMapSmall =  new float[src->width*src->height];

	m_width = src->width;
	m_height = src->height;

	for (int i=0;i<src->width*src->height;i++)
	{
		int iValue = CV_IMAGE_ELEM(pCannyImg,unsigned char,i/src->width,i%src->width);
		if (iValue > 0)
		{
			m_weightMap[i] = 1.0;
		}
		else
		{
			m_weightMap[i] = 0.0;
		}
	}

	cvZero(pCannyImg);
	cvCanny(pGrayImg, pCannyImg, 23, 12, 3);
	for (int i=0;i<src->width*src->height;i++)
	{
		int iValue = CV_IMAGE_ELEM(pCannyImg,unsigned char,i/src->width,i%src->width);
		if (iValue > 0)
		{
			m_weightMapSmall[i] = 1.0;
		}
		else
		{
			m_weightMapSmall[i] = 0.0;
		}
	}


	cvReleaseImage(&pGrayImg);
	cvReleaseImage(&pCannyImg);
}

float *CCannyEdgeDetect::GetWeightMap()
{
	for (int i=0;i<m_width*m_height;i++)
	{
		m_weightMap[i] =m_weightMap[i]*0.6+ m_weightMapSmall[i]*0.4;
	}
	return m_weightMap;
}