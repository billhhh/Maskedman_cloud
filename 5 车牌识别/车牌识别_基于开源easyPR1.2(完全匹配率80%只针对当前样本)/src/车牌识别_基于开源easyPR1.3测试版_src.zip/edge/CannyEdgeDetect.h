#pragma once
#include "./opencv2/core/types_c.h"
class CCannyEdgeDetect
{
public:

	~CCannyEdgeDetect(void);
	void ComputeEdgeInfo(IplImage * src);
	float* GetWeightMap();
	double GetEnergyWeightMap(int index);
	double GetMeanShiftWeight(int index);
	double GetMainEdge(int index);
	CCannyEdgeDetect(void);
private:	

	float * m_weightMap;
	float * m_weightMapSmall;

	int m_width;
	int m_height;
};
