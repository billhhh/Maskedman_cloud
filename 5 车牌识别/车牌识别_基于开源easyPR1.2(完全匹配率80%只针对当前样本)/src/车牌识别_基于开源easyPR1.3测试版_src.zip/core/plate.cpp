#include "../include/plate.h"

/*! \namespace easypr
Namespace where all the C++ EasyPR functionality resides
*/
namespace easypr{

	CPlate::CPlate()
	{
		//cout << "CPlate" << endl;
		bColored = true;
	}

}	/*! \namespace easypr*/