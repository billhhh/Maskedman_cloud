#include "BgPointSet.h"
#include "../segm/msImageProcessor.h"
CBgPointSet * CBgPointSet::m_instance = 0;
CBgPointSet::CBgPointSet()
{
	x_ = y_ = 0;
	n_ = 0;
	type_ = 0;
	

	point_map = NULL;
}

CBgPointSet::~CBgPointSet()
{
	CleanData();
}

void CBgPointSet::CleanData()
{
	if (n_ > 0 && x_)
	{
		delete [] x_;
		delete [] y_;
		x_ = y_ = 0;
		n_ = 0;
	}
	if (point_map)
	{
		delete[] point_map;
		point_map = NULL;
	}
}

void CBgPointSet::SetPoints(int* x, int* y, int n)
{
	CleanData();
	n_ = n;
	x_ = new int[n_];
	y_ = new int[n_];
	for (int i=0; i<n; i++)
	{
		x_[i] = x[i];
		y_[i] = y[i];
	}
}
CBgPointSet * CBgPointSet::Instance()
{
	if (m_instance == 0)
	{
		m_instance = new CBgPointSet;
	}
	return m_instance;
}

bool CBgPointSet::BEdgepoint(int x,int y)
{
	int width = 0;//msImageProcessor::Instance()->width;
	int height = 0;//msImageProcessor::Instance()->height;

	if(x>=0 && x<width && y>=0 && y<height)
	{
		int  dp;
		dp	= y*width+x;
		return point_map[dp];
	}
	else{
			return false;
	}

}
//void CBgPointSet::CalTheBoundery()
//{
//	int width = CImageProc::Instance()->GetWidth();
//	int height = CImageProc::Instance()->GetHeight();
//
//	//clean boundary data if any exists
//	CleanData();
//	//get boundary indeces from region list object
//	//of the image processor object...
//	RegionList	*regionList			= NULL;//msImageProcessor::Instance()->GetBoundaries();
//	int			*regionIndeces		= regionList->GetRegionIndeces(0);
//	int			numRegions			= regionList->GetNumRegions();
//	int			boundaryPointCount	= 0;
//
//	//calculate the number of boundary points stored by region list
//	//class
//	int i;
//	for(i = 0; i < numRegions; i++)
//		boundaryPointCount += regionList->GetRegionCount(i);
//
//
//	//create a point set using calculated boundary point count...
//	x_	= new int [boundaryPointCount];
//	y_	= new int [boundaryPointCount];
//	n_	= boundaryPointCount;
//	for(i = 0; i < boundaryPointCount; i++)
//	{
//		x_[i]	= regionIndeces[i]%width;
//		y_[i]	= regionIndeces[i]/width;
//	}
//
//
//	//set point type to point (= 1)
//	type_	= 1;
//
//	//initialze point map
//	if(point_map)	
//	{
//		delete [] point_map;
//		point_map = NULL;
//	}
//	point_map	= new bool [width*height];
//	memset(point_map, 0, width*height*sizeof(bool));
//	if((type_	== 1))
//	{
//		int nt, *tx, *ty;
//		nt = n_;
//		tx = x_;
//		ty = y_;
//		int i, dp;
//		for(i=0; i<nt; i++)
//		{
//			dp				= ty[i]*width+tx[i];
//			point_map[dp]	= true;
//		}
//	}
//}