/*******************************************************

                 Mean Shift Analysis Library
	=============================================


	The mean shift library is a collection of routines
	that use the mean shift algorithm. Using this algorithm,
	the necessary output will be generated needed
	to analyze a given input set of data.

  Mean Shift Image Processor Class:
  ================================

	The following class inherits from the mean shift library
	in order to perform the specialized tasks of image
	segmentation and filtering.
	
	The prototype of the Mean Shift	Image Processor Class
	is provided below. Its definition is provided in
	'msImageProcessor.cc'.

The theory is described in the papers:

  D. Comaniciu, P. Meer: Mean Shift: A robust approach toward feature
									 space analysis.

  C. Christoudias, B. Georgescu, P. Meer: Synergism in low level vision.

and they are is available at:
  http://www.caip.rutgers.edu/riul/research/papers/

Implemented by Chris M. Christoudias, Bogdan Georgescu
********************************************************/

#ifndef msImageProcessor_H
#define msImageProcessor_H

//include mean shift library
#include	"ms.h"
//include prototypes of additional strucuters
//used for image segmentation...

//include region list used to store boundary pixel
//indeces for each region
#include	"rlist.h"

//include region adjacency list class used for
//region pruning and transitive closure
#include	"RAList.h"

//define constants

	//image pruning
#define	TOTAL_ITERATIONS	14
#define BIG_NUM				0xffffffff	//BIG_NUM = 2^32-1
#define NODE_MULTIPLE		10

	//data space conversion...
const double Xn			= 0.95050;
const double Yn			= 1.00000;
const double Zn			= 1.08870;
//const double Un_prime	= 0.19780;
//const double Vn_prime	= 0.46830;
const double Un_prime	= 0.19784977571475;
const double Vn_prime	= 0.46834507665248;
const double Lt			= 0.008856;

	//RGB to LUV conversion
const double XYZ[3][3] = {	{  0.4125,  0.3576,  0.1804 },
							{  0.2125,  0.7154,  0.0721 },
							{  0.0193,  0.1192,  0.9502 }	};

	//LUV to RGB conversion
const double RGB[3][3] = {	{  3.2405, -1.5371, -0.4985 },
							{ -0.9693,  1.8760,  0.0416 },
							{  0.0556, -0.2040,  1.0573 }	};

//define data types
typedef unsigned char byte;

//define enumerations
enum imageType {GRAYSCALE, COLOR};
#include "opencv2/imgproc/imgproc.hpp"
#include "../edge/CannyEdgeDetect.h"
//define prototype
class msImageProcessor: public MeanShift {



public:	 
	msImageProcessor( void );        //Default Constructor
  /*/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\*/
  /* Class Constructor and Destructor */
  /*\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/*/

 
 ~msImageProcessor( void );        //Class Destructor

 /*/\/\/\/\/\/\/\/\/\/\/\/\/\*/
 /* Input Image Declaration  */
 /*\/\/\/\/\/\/\/\/\/\/\/\/\/*/

  //--\\||//--\\||//--\\||//--\\||//--\\||//--\\||//--\\||//
  //<--------------------------------------------------->|//
  //|                                                    |//
  //|	Method Name:								     |//
  //|   ============								     |//
  //|				  * Define Image *                   |//
  //|                                                    |//
  //<--------------------------------------------------->|//
  //|                                                    |//
  //|	Description:								     |//
  //|	============								     |//
  //|                                                    |//
  //|   Uploads an image to be segmented by the image    |//
  //|   segmenter class.                                 |//
  //|                                                    |//
  //|   An image is defined by specifying the folloing:  |//
  //|                                                    |//
  //|   <* data *>                                       |//
  //|   A one dimensional unsigned char array of RGB     |//
  //|   vectors.                                         |//
  //|                                                    |//
  //|   <* type *>                                       |//
  //|   Specifies the image type: COLOR or GREYSCALE.    |//
  //|                                                    |//
  //|   <* height *>                                     |//
  //|   The image height.                                |//
  //|                                                    |//
  //|   <* width *>                                      |//
  //|   The image width.                                 |//
  //|                                                    |//
  //|   This method uploads the image and converts its   |//
  //|   data into the LUV space. If another conversion   |//
  //|   is desired data may be uploaded into this class  |//
  //|   via the procedure MeanShift::UploadInput().      |//
  //|                                                    |//
  //<--------------------------------------------------->|//
  //|                                                    |//
  //|	Usage:      								     |//
  //|   ======      								     |//
  //|		DefineImage(data, type, height, width)       |//
  //|                                                    |//
  //<--------------------------------------------------->|//
  //--\\||//--\\||//--\\||//--\\||//--\\||//--\\||//--\\||//
	int* Getlab();
	void DefineImage(IplImage * img);
	inline double GetEnergyYidong();


	void NewCalTheMeanshift(double*& Mh,double*&yk,
		float*& sdata,  int*& buckets,int*& slist,
		int& nBuck1,int& nBuck2,int& nBuck3,int bucNeigh[],
		float& sMins,double&	mvAbs);

  void SetWeightMap(float);
  void RemoveWeightMap(void);
  void Filter(int, float);
  void FuseRegions(float, int);

  void RGBtoLUV(byte*, float*);

  void LUVtoRGB(float*, byte*);

  void GetRawData(float*);
  void GetResults(byte*);
  bool Getvariance(int x,int y,bool right,int span,double& variance);
public:
 void ReleaseTheInfo();
  void timeEnd(char *sz);
  void timeStart();

  //--\\||//--\\||//--\\||//--\\||//--\\||//--\\||//--\\||//
  //<--------------------------------------------------->|//
  //|                                                    |//
  //|	Method Name:								     |//
  //|   ============								     |//
  //|				 *  Get Boundaries  *                |//
  //|                                                    |//
  //<--------------------------------------------------->|//
  //|                                                    |//
  //|	Description:								     |//
  //|	============								     |//
  //|                                                    |//
  //|   Returns the boundaries of each region of the     |//
  //|   segmented image using a region list object,      |//
  //|   available after filtering or segmenting the      |//
  //|   defined image.                                   |//
  //|                                                    |//
  //<--------------------------------------------------->|//
  //|                                                    |//
  //|	Usage:      								     |//
  //|   ======      								     |//
  //|		regionList = GetBoundaries()                 |//
  //|                                                    |//
  //<--------------------------------------------------->|//
  //--\\||//--\\||//--\\||//--\\||//--\\||//--\\||//--\\||//

  RegionList *GetBoundaries( void );
  int GetRegions(int**, float**, int**);
private:

   void NewOptimizedFilter2(float, float);

	
	/*/\/\/\/\/\/\/\/\/\/\/\*/
	/* Image Classification */
	/*\/\/\/\/\/\/\/\/\/\/\/*/

	void Connect( void );					// classifies mean shift filtered image regions using
											// private classification structure of this class

	void Fill(int, int);					// used by Connect to perform label each region in the
											// mean shift filtered image using an eight-connected
											// fill

	/*/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\*/
	/* Transitive Closure and Image Pruning */
	/*\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/*/

	void BuildRAM( void );					// build a region adjacency matrix using the region list
											// object

	void DestroyRAM( void );				// destroy the region adjacency matrix: de-allocate its memory
											// initialize it for re-use

	void TransitiveClosure(void );			// use the RAM to apply transitive closure to the image modes

	void ComputeEdgeStrengths( void );		// computes the weights of the weighted graph using the weight
											// map

	//Usage: Prune(minRegion)
	void Prune(int);						// use the RAM to prune the image of spurious regions (regions
											// whose area is less than minRegion pixels, where minRegion is
											// an argument of this method)

	/*/\/\/\/\/\/\/\/\/\/\/\/\/\/\*/
	/*  Region Boundary Detection */
	/*\/\/\/\/\/\/\/\/\/\/\/\/\/\/*/

	void DefineBoundaries( void );			// defines the boundaries of each region using the classified segmented
											// image storing the resulting boundary locations for each region using
											// a region list object

	/*/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\*/
	/*  Image Data Searching/Distance Calculation */
	/*\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/*/

	//Usage: InWindow(modeIndex1, modeIndex2)
	bool InWindow(int, int);				//returns true if the range data of the specified data points
											//are within the defined search window (defined by kernel
											//bandwidth h[1])
	bool InMyWinodw(int,int);

	float SqDistance(int, int);				// computes the normalized square distance between two modes 

	int CountOfLab(int lab);
	/*/\/\/\/\/\/\/\/\/\/\*/
	/* Memory Management  */
	/*\/\/\/\/\/\/\/\/\/\/*/

	void InitializeOutput( void );			//Allocates memory needed by this class to perform image
											//filtering and segmentation

	void DestroyOutput( void );				//De-allocates memory needed by this class to perform image
											//filtering and segmentation
	
  //=============================
  // *** Private Data Members ***
  //=============================

   //##########################################
   //#######    IMAGE CLASSIFICATION   ########
   //##########################################

	/////////Image Boundaries/////////
	RegionList		*regionList;			// stores the boundary locations for each region
public:
	/////////Image Regions////////
	int				regionCount;			// stores the number of connected regions contained by the
											// image

	/////////8 Connected Neighbors/////////
	int				neigh[8];

	/////////Index Table/////////////////
	int				*indexTable;			//used during fill algorithm

	/////////LUV_data/////////////////
   //int            *LUV_data;           //stores modes in integer format on lattice
	float				*LUV_data;				//stores modes in float format on lattice
   float          LUV_treshold;        //in float mode this determines what "close" means between modes


   //##########################################
   //#######   OUTPUT DATA STORAGE     ########
   //##########################################

	////////Raw Data (1 to 1 correlation with input)////////
	float			*msRawData;				// Raw data output of mean shift algorithm
											// to the location of the data point on the lattice

	////////Data Modes////////
	int				*labels;				// assigns a label to each data point associating it to
											// a mode in modes (e.g. a data point having label l has
											// mode modes[l])

	float			*modes;					// stores the mode data of the input data set, indexed by labels

	int				*modePointCounts;		// stores for each mode the number of point mapped to that mode,
											// indexed by labels

   //##########################################
   //#######  REGION ADJACENCY MATRIX  ########
   //##########################################

	//////////Region Adjacency List/////////
	RAList			*raList;				// an array of RAList objects containing an entry for each
											// region of the image

	//////////RAMatrix Free List///////////
	RAList			*freeRAList;			// a pointer to the head of a region adjacency list object
											// free list

	RAList			*raPool;				// a pool of RAList objects used in the construction of the
											// RAM

   //##############################################
   //#######  COMPUTATION OF EDGE STRENGTHS #######
   //##############################################

	//////////Epsilon///////////
	float			epsilon;				//Epsilon used for transitive closure

	//////Visit Table//////
	unsigned char	*visitTable;			//Table used to keep track of which pixels have been
											//already visited upon computing the boundary edge strengths

   //##########################################
   //#######       IMAGE PRUNING       ########
   //##########################################

	////////Transitive Closure/////////
	float			rR2;					//defines square range radius used when clustering pixels
											//together, thus defining image region
	CCannyEdgeDetect m_cannyEgeDetect;

	float m_sigmaS;
	float m_sigmaR;
};

#endif