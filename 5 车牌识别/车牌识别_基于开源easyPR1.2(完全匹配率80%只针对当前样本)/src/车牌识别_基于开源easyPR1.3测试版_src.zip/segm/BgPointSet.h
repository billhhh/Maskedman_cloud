#pragma once

class CBgPointSet
{
public:
	int* x_;
	int* y_;
	int n_;
	int type_; // 0 circle
	// 1 point
	void CleanData();
	void SetPoints(int*, int* ,int);

	bool BEdgepoint(int x,int y);
public:
	bool	*point_map;
	static CBgPointSet * Instance();
	~CBgPointSet(void);
private:
	CBgPointSet(void);
	static CBgPointSet * m_instance;
};
