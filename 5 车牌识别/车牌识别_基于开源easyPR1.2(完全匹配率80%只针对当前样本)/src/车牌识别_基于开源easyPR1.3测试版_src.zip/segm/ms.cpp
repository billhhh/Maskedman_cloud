/*******************************************************

  Mean Shift Analysis Library
  =============================================
  
	The mean shift library is a collection of routines
	that use the mean shift algorithm. Using this algorithm,
	the necessary output will be generated needed
	to analyze a given input set of data.
	
  MeanShift Base Class:
  ====================
	  
	The mean shift library of routines is realized
	via the creation of a MeanShift base class. This class
	provides a mechanism for calculating the mean shift vector
	at a specified data point, using an arbitrary N-dimensional
	data set, and a user-defined kernel.
		
	For image processing the mean shift base class also allows
	for the definition of a data set that is on a two-dimensional
	lattice. The amount of time needed to compute the mean shift
	vector using such a data set is much less than that of an
	arbitrary one. Because images usually contain many data points,
	defining the image input data points as being on a lattice
	greatly improves computation time and makes algorithms such
	as image filtering practical.
		  
	The definition of the MeanShift class is provided below. Its
	prototype is provided in 'ms.h'.
			
The theory is described in the papers:

  D. Comaniciu, P. Meer: Mean Shift: A robust approach toward feature
									 space analysis.

  C. Christoudias, B. Georgescu, P. Meer: Synergism in low level vision.

and they are is available at:
  http://www.caip.rutgers.edu/riul/research/papers/

Implemented by Chris M. Christoudias, Bogdan Georgescu
********************************************************/


//Include Needed Libraries

#include	"ms.h"
#include	<string.h>
#include	<stdlib.h>
#include	<stdio.h>
#include	<math.h>

/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@      PUBLIC METHODS     @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/

  /*/\/\/\/\/\/\/\/\/\/\/\/\/\/\*/
  /*** Constructor/Destructor ***/
  /*\/\/\/\/\/\/\/\/\/\/\/\/\/\/*/

/*******************************************************/
/*Class Constructor                                    */
/*******************************************************/
/*Post:                                                */
/*      The MeanShift class has been properly          */
/*      initialized.                                   */
/*******************************************************/

MeanShift::MeanShift( void )
{
	Construct();
}

void MeanShift::Construct()
{
	//intialize input data set parameters...
	P							= NULL;
	L							= 0;
	N							= 0;
	kp							= 0;

	//initialize input data set storage structures...
	data						= NULL;

	//initialize input data set kd-tree
	root						= NULL;
	forest						= NULL;

	//intialize lattice structure...
	height						= 0;
	width						= 0;

	//intialize kernel strucuture...
	h							= NULL;
	kernel						= NULL;

	offset						= NULL;

	uniformKernel				= false;

	//initialize weight function linked list...
	head						= cur	= NULL;


	//set lattice weight map to null
	weightMap					= NULL;

	//indicate that the lattice weight map is undefined
	weightMapDefined			= false;

	//allocate memory for error message buffer...
	ErrorMessage				= new char [256];

	//initialize error status to OKAY
	ErrorStatus					= EL_OKAY;

	//Initialize class state...
	class_state.INPUT_DEFINED	= false;
	class_state.KERNEL_DEFINED	= false;
	class_state.LATTICE_DEFINED	= false;
	class_state.OUTPUT_DEFINED	= false;
}
/*******************************************************/
/*Class Destructor                                     */
/*******************************************************/
/*Post:                                                */
/*      The MeanShift class has been properly          */
/*      destroyed.                                     */
/*******************************************************/

MeanShift::~MeanShift( void )
{
	ReleaseRes();
	
}
void MeanShift::ReleaseRes()
{
	if(ErrorMessage)
	{
		delete [] ErrorMessage;
		ErrorMessage = NULL;
	}

	if (weightMap)
	{
		delete [] weightMap;
		weightMap = NULL;
	}

	//de-allocate memory used to store
	//user defined weight functions
	ClearWeightFunctions();

	//de-allocate memory used for kernel
	DestroyKernel();

	//de-allocate memory used for input
	ResetInput();
}

  /*/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\*/
  /*** Creation/Initialization of Mean Shift Kernel ***/
  /*\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/*/

/*******************************************************/
/*Define Kernel                                        */
/*******************************************************/
/*Creats custom user defined Kernel to be used by the  */
/*mean shift procedure.                                */
/*******************************************************/
/*Pre:                                                 */
/*      - kernel is an array of kernelTypes specifying */
/*        the type of kernel to be used on each sub-   */
/*        space of the input data set x                */
/*      - h is the set of bandwidths used to define the*/
/*        the search window                            */
/*      - P is a one dimensional array of integers of  */
/*        size kp, that specifies the dimension of each*/
/*        subspace of the input data set x             */
/*      - kp is the total number of subspaces used to  */
/*        the input data set x                         */
/*Post:                                                */
/*      - the custom kernel has been created for use   */
/*        by the mean shift procedure.                 */
/*******************************************************/

void MeanShift::DefineKernel(kernelType *kernel_, float *h_, int *P_, int kp_)
{
	
	// Declare variables
	int i, kN;
	

	
	//Obtain kp...
	if((kp = kp_) <= 0)
	{
		ErrorHandler("MeanShift", "CreateKernel", "Subspace count (kp) is zero or negative.");
		return;
	}
	
	//Allocate memory for h, P, kernel, offset, and increment
	if((!(P = new int [kp]))||(!(h = new float [kp]))||(!(kernel = new kernelType [kp]))||
		(!(offset = new float [kp])))
	{
		ErrorHandler("MeanShift", "CreateKernel", "Not enough memory available to create kernel.");
		return;
	}
	
	//Populate h, P and kernel, also use P to calculate
	//the dimension (N_) of the potential input data set x
	kN = 0;
	for(i = 0; i < kp; i++)
	{
		if((h[i] = h_[i]) <= 0)
		{
			ErrorHandler("MeanShift", "CreateKernel", "Negative or zero valued bandwidths are prohibited.");
			return;
		}
		if((P[i] = P_[i]) <= 0)
		{
			ErrorHandler("MeanShift", "CreateKernel", "Negative or zero valued subspace dimensions are prohibited.");
			return;
		}
		kernel[i] = kernel_[i];
		kN	   += P[i];
	}
	
	
	
	// Generate weight function lookup table
	// using above information and user
	// defined weight function list
	generateLookupTable();
	
	//check for errors
	if(ErrorStatus == EL_ERROR)
		return;
	
	//indicate that the kernel has been defined
	class_state.KERNEL_DEFINED	= true;
	
	//done.
	return;
	
}

/*******************************************************/
/*Add Weight Function                                  */
/*******************************************************/
/*Adds a weight function to the Mean Shift class to be */
/*used by the mean shift procedure                     */
/*******************************************************/
/*Pre:                                                 */
/*      - g(u) is the normalized weight function with  */
/*        respect to u = (norm(x-xi))^2/h^2            */
/*      - sampleNumber is the number of samples to be  */
/*        taken of g(u) over halfWindow interval       */
/*      - halfWindow is the radius of g(u) such that   */
/*        g(u) is defined for 0 <= u <= halfWindow     */
/*      - subspace is the subspace number for which    */
/*        g(u) is to be applied during the mean shift  */
/*        procedure.                                   */
/*Post:                                                */
/*      - g(u) has been added to the Mean Shift class  */
/*        private data structure to be used by the     */
/*        mean shift procedure.                        */
/*      - if a weight function has already been spec-  */
/*        ified for the specified subspace, the weight */
/*        function for this subspace has been replaced.*/
/*******************************************************/

void MeanShift::AddWeightFunction(double g(double), float halfWindow, int sampleNumber, int subspace)
{
	
	// Declare Variables
	int   i;
	double increment;
	
	// Search to see if a weight function has already been
	// defined for specified subspace, if not then insert
	// into the head of the weight function list, otherwise
	// replace entry
	
	// Perform Search
	cur = head;
	while((cur)&&(cur->subspace != subspace))
		cur = cur->next;
	
	// Entry Exists - Replace It! 
	// Otherwise insert at the head of the the weight functon list
	if(cur)
		delete cur->w;
	else
    {
		cur       = new userWeightFunct;
		cur->next = head;
		head      = cur;
    }
	
	// Generate lookup table
	increment = halfWindow/(double)(sampleNumber);
	
	cur->w = new double [sampleNumber+1];
	for(i = 0; i <= sampleNumber; i++)
		cur->w[i] = g((double)(i*increment));
	
	// Set weight function parameters
	cur->halfWindow   = halfWindow;
	cur->sampleNumber = sampleNumber;
	cur->subspace     = subspace;
	
	//done.
	return;
	
}

/*******************************************************/
/*Clear Weight Functions                               */
/*******************************************************/
/*Clears user defined weight from the Mean Shift class */
/*private data structure.                              */
/*******************************************************/
/*Post:                                                */
/*      - all user defined weight functions ahve been  */
/*        cleared from the private data structure of   */
/*        the mean shift class.                        */
/*******************************************************/

void MeanShift::ClearWeightFunctions( void )
{
	
	while(head)
    {
		delete head->w;
		cur  = head;
		head = head->next;
		delete cur;
    }
	
}

  /*/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\*/
  /*** Input Data Set Declaration ***/
  /*\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/*/

/*******************************************************/
/*Define Input                                         */
/*******************************************************/
/*Uploads input data set x into the mean shift class.  */
/*******************************************************/
/*Pre:                                                 */
/*      - x is a one dimensional array of L N-dimen-   */
/*        ional data points.                           */
/*Post:                                                */
/*      - x has been uploaded into the mean shift      */
/*        class.                                       */
/*      - the height and width of a previous data set  */
/*        has been undefined.                          */
/*******************************************************/

void MeanShift::DefineInput(float *x, int L_, int N_)
{
	
	
	//if input data is defined de-allocate memory, and
	//re-initialize the input data structure
	if((class_state.INPUT_DEFINED)||(class_state.LATTICE_DEFINED))
		ResetInput();
	
	//make sure x is not NULL...
	if(!x)
	{
		ErrorHandler("MeanShift", "UploadInput", "Input data set is NULL.");
		return;
	}
	
	//Obtain L and N
	if(((L = L_) <= 0)||((N = N_) <= 0))
	{
		ErrorHandler("MeanShift", "UploadInput", "Input data set has negative or zero length or dimension.");
		return;
	}
	
	//Allocate memory for data
	if(!(data = new float [L*N]))
	{
		ErrorHandler("MeanShift", "UploadInput", "Not enough memory.");
		return;
	}
	
	//Allocate memory for input data set, and copy
	//x into the private data members of the mean
	//shift class
	InitializeInput(x);
	
	//check for errors
	if(ErrorStatus == EL_ERROR)
		return;
	
	// Load x into the MeanShift object using
	// using a kd-tree, resulting in better
	// range searching of the input data points
	// x - also upload window centers into
	// msRawData
	CreateBST();
	
	//indicate that the input has been recently defined
	class_state.INPUT_DEFINED	= true;
	class_state.LATTICE_DEFINED	= false;
	class_state.OUTPUT_DEFINED	= false;
	
	//done.
	return;
	
}

/*******************************************************/
/*Define Lattice                                       */
/*******************************************************/
/*Defines the height and width of the input lattice.   */
/*******************************************************/
/*Pre:                                                 */
/*      - ht is the height of the lattice              */
/*      - wt is the width of the lattice               */
/*Post:                                                */
/*      - the height and width of the lattice has been */
/*        specified.                                   */
/*      - if a data set is presently loaded into the   */
/*        mean shift class, an error is flagged if the */
/*        number of elements in that data set does not */
/*        equal the product ht*wt.                     */
/*******************************************************/

void MeanShift::DefineLInput(float *x, int ht, int wt, int N_)
{
	
	//if input data is defined de-allocate memory, and
	//re-initialize the input data structure
	if((class_state.INPUT_DEFINED)||(class_state.LATTICE_DEFINED))
		ResetInput();
	
	//Obtain lattice height and width
	if(((height	= ht) <= 0)||((width = wt) <= 0))
	{
		ErrorHandler("MeanShift", "DefineLInput", "Lattice defined using zero or negative height and/or width.");
		return;
	}
	
	//Obtain input data dimension
	if((N = N_) <= 0)
	{
		ErrorHandler("MeanShift", "DefineInput", "Input defined using zero or negative dimension.");
		return;
	}
	
	//compute the data length, L, of input data set
	//using height and width
	L		= height*width;
	
	//Allocate memory for input data set, and copy
	//x into the private data members of the mean
	//shift class
	InitializeInput(x);
	
	weightMap = new float[L];
	memset(weightMap, 0, L*(sizeof(float)));
	
	//Indicate that a lattice input has recently been
	//defined
	class_state.LATTICE_DEFINED	= true;
	class_state.INPUT_DEFINED	= false;
	class_state.OUTPUT_DEFINED	= false;
	
	//done.
	return;
	
}

/*******************************************************/
/*Set Lattice Weight Map                               */
/*******************************************************/
/*Populates the lattice weight map with specified      */
/*weight values.                                       */
/*******************************************************/
/*Pre:                                                 */
/*      - wm is a floating point array of size L       */
/*        specifying for each data point a weight      */
/*        value                                        */
/*Post:                                                */
/*      - wm has been used to populate the lattice     */
/*        weight map.                                  */
/*******************************************************/

void MeanShift::SetLatticeWeightMap(float *wm)
{
	//make sure wm is not NULL
	if(!wm)
	{
		ErrorHandler("MeanShift", "SetWeightMap", "Specified weight map is NULL.");
		return;
	}

	int i;
	for(i = 0; i < L; i++)
		weightMap[i] = wm[i];
	//indicate that a lattice weight map has been specified
	weightMapDefined	= true;

	//done.
	return;

}


/*******************************************************/
/*Remove Lattice Weight Map                            */
/*******************************************************/
/*Removes the lattice weight map.                      */
/*******************************************************/
/*Post:                                                */
/*      - the lattice weight map has been removed.     */
/*      - if a weight map did not exist NO error is    */
/*        flagged.                                     */
/*******************************************************/

void MeanShift::RemoveLatticeWeightMap(void)
{

	//only remove weight map if it exists, otherwise
	//do nothing...
	if(weightMapDefined)
	{
		//set values of lattice weight map to zero
		memset(weightMap, 0, L*sizeof(float));
		//indicate that a lattice weight map is no longer
		//defined
		weightMapDefined	= false;
	}

	//done.
	return;

}



/*******************************************************/
/*Lattice Mean Shift Vector                            */
/*******************************************************/
/*Calculates the mean shift vector at a specified data */
/*point yk, assuming that the data set exhists on a    */
/*height x width two dimensional lattice.              */
/*******************************************************/
/*Pre:                                                 */
/*      - a kernel has been created                    */
/*      - a data set has been uploaded                 */
/*      - the height and width of the lattice has been */
/*        specified using method DefineLattice()       */
/*      - Mh is an N dimensional mean shift vector     */
/*      - yk is an N dimensional data point            */
/*Post:                                                */
/*      - the mean shift vector at yk has been         */
/*        calculated and stored in and returned by Mh. */
/*      - Mh was calculated using the defined input    */
/*        lattice.                                     */
/*******************************************************/

/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@    PROTECTED METHODS    @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/


  /*/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\*/
  /*** Kernel-Input Data Consistency  ***/
  /*\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/*/

/*******************************************************/
/*Class Consistency Check                              */
/*******************************************************/
/*Checks the state of the class prior to the applicat- */
/*ion of mean shift.                                   */
/*******************************************************/
/*Pre:                                                 */
/*      - iN is the specified dimension of the input,  */
/*        iN = N for a general input data set, iN = N  */
/*        + 2 for a input set defined using a lattice  */
/*Post:                                                */
/*      - if the kernel has not been created, an input */
/*        has not been defined and/or the specified    */
/*        input dimension (iN) does not match that of  */
/*        the kernel a fatal error is flagged.         */
/*******************************************************/

void MeanShift::classConsistencyCheck(int iN, bool usingLattice)
{
	
	//make sure that kernel has been created...
	if(class_state.KERNEL_DEFINED == false)
	{
		ErrorHandler("MeanShift", "classConsistencyCheck", "Kernel not created.");
		return;
	}
	
	//make sure input data set has been loaded into mean shift object...
	if((class_state.INPUT_DEFINED == false)&&(!usingLattice))
	{
		ErrorHandler("MeanShift", "classConsistencyCheck", "No input data specified.");
		return;
	}
	
	//make sure that the lattice is defined if it is being used
	if((class_state.LATTICE_DEFINED == false)&&(usingLattice))
	{
		ErrorHandler("MeanShift", "classConsistencyCheck", "Latice not created.");
		return;
	}
	
	//make sure that dimension of the kernel and the input data set
	//agree
	
	//calculate dimension of kernel (kN)
	int i, kN	= 0;
	for(i = 0; i < kp; i++)
		kN	+= P[i];
	
	//perform comparison...
	if(iN != kN)
	{
		ErrorHandler("MeanShift", "classConsitencyCheck", "Kernel dimension does not match defined input data dimension.");
		return;
	}
	
	//done.
	return;
	
}

  /*/\/\/\/\/\/\/\/\/\/\/\/\/\*/
  /*** Class Error Handler  ***/
  /*\/\/\/\/\/\/\/\/\/\/\/\/\/*/

/*******************************************************/
/*Error Handler                                        */
/*******************************************************/
/*Class error handler.                                 */
/*******************************************************/
/*Pre:                                                 */
/*      - className is the name of the class that fl-  */
/*        agged an error                               */
/*      - methodName is the name of the method that    */
/*        flagged an error                             */
/*      - errmsg is the error message given by the     */
/*        calling function                             */
/*Post:                                                */
/*      - the error message errmsg is flagged on beh-  */
/*        ave of method methodName belonging to class  */
/*        className:                                   */
/*                                                     */
/*        (1) ErrorMessage has been updated with the   */
/*            appropriate error message using the arg- */
/*            ments passed to this method.             */
/*        (2) ErrorStatus is set to ERROR              */
/*            (ErrorStatus = 1)                        */
/*******************************************************/

void MeanShift::ErrorHandler(char *className, char *methodName, char* errmsg)
{
	
	//store trace into error message
	strcpy(ErrorMessage, className);
	strcat(ErrorMessage, "::");
	strcat(ErrorMessage, methodName);
	strcat(ErrorMessage, " Error: ");
	
	//store message into error message
	strcat(ErrorMessage, errmsg);
	
	//set error status to ERROR
	ErrorStatus = EL_ERROR;
	
	
}

/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@     PRIVATE METHODS     @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/

  /*/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\*/
  /*** Kernel Creation/Manipulation ***/
  /*\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/*/

/*******************************************************/
/*Generate Lookup Table                                */
/*******************************************************/
/*A weight function look up table is generated.        */
/*******************************************************/
/*Pre:                                                 */
/*      - kernel is an array of kernelTypes specifying */
/*        the type of kernel to be used on each sub-   */
/*        space of the input data set x                */
/*      - kp is the total number of subspaces used to  */
/*        the input data set x                         */
/*      - the above information has been pre-loaded    */
/*        into the MeanShift class private members     */
/*Post:                                                */
/*      - a lookup table is generated for the weight   */
/*        function of the resulting kernel             */
/*      - uniformKernel is set to true if the kernel   */
/*        to be used is uniform, false is returned     */
/*        otherwise                                    */
/*      - if a user defined weight function is requred */
/*        for a given subspace but not defined in the  */
/*        user defined weight function list, an error  */
/*        is flagged and the program is halted         */
/*******************************************************/

void MeanShift::generateLookupTable( void )
{
	
	// Declare Variables
	int i;
	
	
	// Traverse through kernel generating weight function
	// lookup table w
	
	// Assume kernel is uniform
	uniformKernel = true;
	
	for(i = 0; i < kp; i++)
    {
		switch(kernel[i])
		{
			// *Uniform Kernel* has weight funciton w(u) = 1
			// therefore, a weight funciton lookup table is
			// not needed for this kernel --> w[i] = NULL indicates
			// this
		case Uniform:
			
			
			offset   [i] =    1;  //uniform kernel has u < 1.0
			break;
			
			// *Gaussian Kernel* has weight function w(u) = constant*exp(-u^2/[2h[i]^2])
		case Gaussian:
			
			// Set uniformKernel to false
			uniformKernel = false;
			
			// generate weight function using expression,
			// exp(-u/2), where u = norm(xi - x)^2/h^
			
			// Set offset = offset^2, and set increment
			offset[i] = (float)(GAUSS_LIMIT*GAUSS_LIMIT);
		
			// done
			break;
			
			// *User Define Kernel* uses the weight function wf(u)
		case UserDefined:
			
			// Set uniformKernel to false
			uniformKernel = false;
			
			// Search for user defined weight function
			// defined for subspace (i+1)
			cur = head;
			while((cur)&&(cur->subspace != (i+1)))
				cur = cur->next;
			
			// If a user defined subspace has not been found
			// for this subspace, flag an error
			if(cur == NULL)
			{
				fprintf(stderr, "\ngenerateLookupTable Fatal Error: User defined kernel for subspace %d undefined.\n\nAborting Program.\n\n", i+1);
				exit(1);
			}
			
			
			// Set offset and increment accordingly
			offset   [i] = (float)(cur->halfWindow);
			// done
			break;
			
		default:
			
			ErrorHandler("MeanShift", "generateLookupTable", "Unknown kernel type.");
			
		}
		
    }
}

/*******************************************************/
/*Destroy Kernel                                       */
/*******************************************************/
/*Destroys and initializes kernel.                     */
/*******************************************************/
/*Post:                                                */
/*      - memory for the kernel private data members   */
/*        have been destroyed and the kernel has been  */
/*        initialized for re-use.                      */
/*******************************************************/

void MeanShift::DestroyKernel( void )
{
	
	//de-allocate memory...
	if(kernel)	delete	[] kernel;
	if     (h)	delete	[] h;
	if     (P)	delete	[] P;

 

   if (offset) delete [] offset;
   
	//intialize kernel for re-use...
	kp		= 0;
	kernel	= NULL;
	h		= NULL;
	P		= NULL;



 
   offset = NULL;
	
	//done.
	return;
	
}

  /*/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\*/
  /*** Input Data Initialization/Destruction  ***/
  /*\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/*/

/*******************************************************/
/*Create Binary Search Tree                            */
/*******************************************************/
/*Uploads input data set x into a kd-BST.              */
/*******************************************************/
/*Pre:                                                 */
/*      - x is a one dimensional array of L N-dimensi- */
/*        onal data points                             */
/*Post:                                                */
/*      - x has been uploaded into a balanced kd-BST   */
/*        data structure for use by the mean shift     */
/*        procedure                                    */
/*******************************************************/

void MeanShift::CreateBST( void )
{
	
	// Create BST using data....
	
	// Allocate memory for tree
	forest = new tree[L];
	
	// Populate 'forest' of tree's with
	// the values stored in x
	int i;
	for(i = 0; i < L; i++)
    {
		forest[i].x      = &data[i*N];
		forest[i].right  = NULL;
		forest[i].left   = NULL;
		forest[i].parent = NULL;
    }
	
	// Build balanced Nd-tree from the
	// forest of trees generated above
	// retaining the root of this tree
	
	root = BuildKDTree(forest, L, 0, NULL);
	
	//done.
	return;
	
}

/*******************************************************/
/*Initialize Input                                     */
/*******************************************************/
/*Allocates memory for and initializes the input data  */
/*structure.                                           */
/*******************************************************/
/*Pre:                                                 */
/*      - x is a floating point array of L, N dimens-  */
/*        ional input data points                      */
/*Post:                                                */
/*      - memory has been allocated for the input data */
/*        structure and x has been stored using into   */
/*        the mean shift class using the resulting     */
/*        structure.                                   */
/*******************************************************/

void MeanShift::InitializeInput(float *x)
{
	
	//allocate memory for input data set
	if(!(data = new float [L*N]))
	{
		ErrorHandler("MeanShift", "InitializeInput", "Not enough memory.");
		return;
	}
	
	//copy x into data
	int i;
	for(i = 0; i < L*N; i++)
		data[i]	= x[i];
	
	//done.
	return;
	
}

/*******************************************************/
/*Reset Input                                          */
/*******************************************************/
/*De-allocates memory for and re-intializes input data */
/*structure.                                           */
/*******************************************************/
/*Post:                                                */
/*      - the memory of the input data structure has   */
/*        been de-allocated and this strucuture has    */
/*        been initialized for re-use.                 */
/*******************************************************/

void MeanShift::ResetInput( void )
{
	
	//de-allocate memory of input data structure (BST)
	if(data)	delete [] data;
	if(forest)	delete [] forest;
	
	//initialize input data structure for re-use
	data	= NULL;
	forest	= NULL;
	root	= NULL;
	L		= 0;
	N		= 0;
	width	= 0;
	height	= 0;
	
	//re-set class input to indicate that
	//an input is not longer stored by
	//the private data members of this class
	class_state.INPUT_DEFINED	= class_state.LATTICE_DEFINED = false;
	
}

  /*/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\*/
  /*** k-dimensional Binary Search Tree ***/
  /*\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/*/

/*******************************************************/
/*Build KD Tree (for Tree Structure)                   */
/*******************************************************/
/*Builds a KD Tree given a forest of tree's.           */
/*******************************************************/
/*Pre:                                                 */
/*      - subset is a subset of L un-ordered tree nodes*/
/*        each containing an N-dimensional data point  */
/*      - d is the depth of the subset, used to specify*/
/*        the dimension used to construct the tree at  */
/*        the given depth                              */
/*      - parent is the parent tree of subset          */
/*Post:                                                */
/*      - a balanced KD tree has been constructed using*/
/*        the forest subset, the root of this tree has */
/*        been returned                                */
/*******************************************************/

tree *MeanShift::BuildKDTree(tree *subset, int length, int d, tree* parent)
{
	
	// If the subset is a single tree
	// then return this tree otherwise
	// partition the subset and place
	// these subsets recursively into
	// the left and right sub-trees having
	// their root specified by the median
	// of this subset in dimension d
	if(length == 1)
	{
		subset->parent = parent;
		return subset;
	}
	else if(length > 1)
    {
		
		// Sort Subset
		QuickMedian(subset, 0, length-1, d);
		
		// Get Median of Subset and Partition
		// it into two sub-trees - create
		// a tree with its root being the median
		// of the subset and its left and right
		// children being the medians of the subsets
		int median            = length/2;
		subset[median].parent = parent;
		subset[median].left   = BuildKDTree(subset           , median         , (d+1)%N, &subset[median]);
		subset[median].right  = BuildKDTree(&subset[median+1], length-median-1, (d+1)%N, &subset[median]);
		
		// Output tree structure
		return &subset[median];
		
    }
	else
		return NULL;
	
	//done.
	
}

/*******************************************************/
/*Quick Median (for Tree Structure)                    */
/*******************************************************/
/*Finds the median element in an un-ordered set, re-   */
/*structuring the set such that points less than the   */
/*median point are located to the left of the median   */
/*and points greater than the median point are located */
/*to the right.                                        */
/*******************************************************/
/*Pre:                                                 */
/*      - arr is a subset of tree nodes whose leftmost */
/*        element is specified by left and rightmost   */
/*        element is specified by left                 */
/*      - d is the dimension of the data set stored by */
/*        the tree structure that is used to find      */
/*        the median                                   */
/*Post:                                                */
/*      - the median point is found and the subset     */
/*        of trees is re-ordered such that all trees   */
/*        whose data points with d dimensional value   */
/*        less than that of the median tree node are   */
/*        located to the left of the median tree node, */
/*        otherwise they are located to the right      */
/*******************************************************/

void MeanShift::QuickMedian(tree *arr, int left, int right, int d)
{
	unsigned long k;
	unsigned long n;
	float* a;
	float* temp;
	n = right-left+1;
	k = n/2 + 1;
	unsigned long i, ir, j, l, mid;
	
	l = 1;
	ir = n;
	for (;;)
	{
		if (ir <= l+1)
		{
			if (ir == l+1 && arr[ir-1].x[d] < arr[l-1].x[d])
			{
				SWAP(arr[l-1].x, arr[ir-1].x)
			}
			return;
		} else
		{
			mid = (l+ir) >> 1;
			SWAP(arr[mid-1].x, arr[l+1-1].x)
				if (arr[l-1].x[d] > arr[ir-1].x[d])
				{
					SWAP(arr[l-1].x, arr[ir-1].x)
				}
				if (arr[l+1-1].x[d] > arr[ir-1].x[d])
				{
					SWAP(arr[l+1-1].x, arr[ir-1].x)
				}
				if (arr[l-1].x[d] > arr[l+1-1].x[d])
				{
					SWAP(arr[l-1].x, arr[l+1-1].x)
				}
				i = l+1;
				j = ir;
				a = arr[l+1-1].x;
				for (;;) {
					do i++; while (arr[i-1].x[d] < a[d]);
					do j--; while (arr[j-1].x[d] > a[d]);
					if (j<i) break;
					SWAP(arr[i-1].x, arr[j-1].x)
				}
				arr[l+1-1].x = arr[j-1].x;
				arr[j-1].x = a;
				if (j>=k) ir = j-1;
				if (j<=k) l = i;
		}
	}
}

/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ END OF CLASS DEFINITION @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/


