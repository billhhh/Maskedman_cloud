////////////////////////////////////////////////////////
// Name     : imfilt.h
// Purpose  : Image Filter Prototypes
// Author   : Chris M. Christoudias
// Modified by
// Created  : 03/20/2002
// Copyright: (c) Chris M. Christoudias
// Version  : v0.1
////////////////////////////////////////////////////////

#include "libppm.h" //read/write pgm and ppm images
