/////////////////////////////////////////////////////////////////////////////
// Name:        bgimsystem.cpp
// Purpose:     Image processing system
// Author:      Bogdan Georgescu, Chris M. Christoudias
// Modified by:
// Created:     06/22/2000
// Copyright:   (c) Bogdan Georgescu, Chris M. Christoudias
// Version:     v0.1
/////////////////////////////////////////////////////////////////////////////
#include <wx/app.h>
#include <wx/dialog.h>
#include <wx/button.h>
#include <wx/stattext.h>
#include <wx/checkbox.h>
#include <wx/bmpbuttn.h>
#include <wx/choice.h>
#include <wx/combobox.h>
#include <wx/statbox.h>
#include "BgImage.h"
#include "../segm/tdef.h"
#include "BgImCanvas.h"
// Define a new application
class BgApp : public wxApp
{
public:
   bool OnInit();
};

class BgThread : public wxThread {
public:
	BgThread(wxThreadKind, void foo(void*), void*);
	~BgThread( void );

private:

	//determines the entry point of the thread (foo)
	void *Entry( void );

	//pointer to the function foo and its corresponding object
	void *Object_;
	void (*function_)(void*);
	
};

// Define a new frame
class BgMdiFrame : public wxMDIParentFrame
{
public:
	//   wxTextCtrl *textWindow;
	//   wxLogWindow* logwind_;
	wxTextCtrl    *logtext_;
	wxLog *logTargetOld_;
	int logsize_;
	bgLogTextCtrl* bglogctrl_;
	char programDir_[1000];
	char helpDir_[1000];

	BgMdiFrame(wxWindow *parent, const wxWindowID id, const wxString& title,
		const wxPoint& pos, const wxSize& size, const long style);

	void InitToolBar(wxToolBar* toolBar);

	void	GetImageFileInfo(char**, char**);
	void ZoomControl(wxCommandEvent& );
	void OnSize(wxSizeEvent&);
	void OnNewSegmWindow(wxCommandEvent&);
	void OnLoadImage(wxCommandEvent&);
	void OnLoadImageSegm(wxCommandEvent&);
	void OnSaveResult(wxCommandEvent& WXUNUSED(event));
	void OnQuit(wxCommandEvent&);
	void OnClose(wxCloseEvent&);
	void SetChildTitle(wxMDIChildFrame*, int, int, int);
	void UpdateZoomControl(wxMDIChildFrame*, int, int);

	DECLARE_EVENT_TABLE()
};


//Custom dialog box that allows for the addition of bitmaps
//and bold text (etc)
class BgDialog : public wxDialog {
public:
	BgDialog(wxWindow*, wxWindowID, const wxString&, const wxPoint&, const wxSize&, long, const wxString&);
	~BgDialog(void);

	//add/remove objects....
	void AddText(BgText *);
	void RemoveText(int);
	void AddBitmap(BgBitmap *);
	void RemoveBitmap(BgBitmap *);

	//paint/close dialog
	virtual void OnPaint(wxPaintEvent& );
	void OnExit(wxCommandEvent& );
	wxButton* okButton_;

	//declare an event table for this class
	DECLARE_EVENT_TABLE();

private:

	//text/bitmap lists...
	BgTextList		tlist_;
	BgBitmapList	blist_;

};

class BgHoverBar : public wxWindow
{
public:
	BgHoverBar(wxWindow*, wxWindowID, int, int, int, int, int, int, int);
	~BgHoverBar( void );

	wxBitmapButton* menuButton1_;
	wxBitmapButton* menuButton2_;
	wxStaticText* menuText1_;
	wxStaticText* menuText2_;
	wxMenu* view_menu;
	wxMenu* save_menu;

	void ShowMenu(wxCommandEvent& );
	void CheckViewItem(long);
	void Update( void );

	int	gradViewId_, confViewId_, weitViewId_, custViewId_;
	int	gradSaveId_, confSaveId_, weitSaveId_;

	//declare an event table for this class
	DECLARE_EVENT_TABLE();
};

class BgMenuPanel : public wxPanel
{
public:
	BgMenuPanel(wxWindow*, wxWindowID, int, int, int, int, int, int, int);
	~BgMenuPanel( void );

	wxBitmapButton* menuButton1_;
	wxBitmapButton* menuButton2_;
	wxStaticText* menuText1_;
	wxStaticText* menuText2_;
	wxMenu* view_menu;
	wxMenu* save_menu;
	wxWindow* scrollWindow_;

	void ShowMenu(wxCommandEvent& );
	void CheckViewItem(long);
	void Update( void );
	void EnableMenu(bool);
	void OnSize(wxSizeEvent& );
	void SetScrollWindow(wxWindow*);

	int	gradViewId_, confViewId_, weitViewId_, custViewId_;
	int	gradSaveId_, confSaveId_, weitSaveId_;

	//declare an event table for this class
	DECLARE_EVENT_TABLE();
};


class BgParameterHistory {
public:
	BgParameterHistory( void );
	BgParameterHistory(void*, int);
	~BgParameterHistory();

	void				*params_;
	int					listSize_;
	BgParameterHistory	*next_;
};


//parameter history box tool
//IMPORTANT: WHEN ADDING A PARAMETER LIST, THIS OBJECT OBTAINS OWNERSHIP
//			 OF THAT LIST (I.E. IT WILL DELETE THE MEMORY FOR YOU!!!!).
class BgParameterHistoryBox : public wxComboBox {
public:
	BgParameterHistoryBox(wxWindow*, wxWindowID, const wxString&, const wxPoint&, const wxSize&, int, long, const wxValidator&, const wxString&);
	~BgParameterHistoryBox( void );

	//add/get parameter lists
	void AddParameterList(void*, int);
	void *GetParameterListData(int);
	int GetParameterListCount(int);

	//keep track of parameter history
	void SetCurrentList(void*, int);
	void* GetCurrentListData( void );
	int GetCurrentListCount( void );
	void UseParameterList(int);

private:

	//paramter list array...
	BgParameterHistory	*historyList_, currentList_;
	int					listCount_, maxCount_;

};


// Define the parameter dialog box

class BgParamDialog : public wxDialog
{
public:
   BgParamDialog(wxWindow* parent, wxWindowID id, const wxString& title,
      const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxDefaultSize,
      long style = wxDEFAULT_DIALOG_STYLE, const wxString& name = "dialogBox");
   ~BgParamDialog();
   void OnOk(wxCommandEvent& );
   void OnCancel(wxCommandEvent& );
   void SetValues(double, double, double, double, double, double, int, int, int, int, int);
   void GetValues(double&, double&, double&, double&, double&, double&, int&, int&, int&, int&, int&);

   // dialog parameters
   wxButton* okButton_;
   wxButton* cancelButton_;

   wxStaticText* txtNmxR_;
   wxStaticText* txtNmxC_;
   wxStaticText* txtHHR_;
   wxStaticText* txtHHC_;
   wxStaticText* txtHLR_;
   wxStaticText* txtHLC_;
   wxStaticText* txtMinPt_;
   wxStaticText* txtNmxType_;
   wxStaticText* txtHHType_;
   wxStaticText* txtHLType_;
   wxStaticText* txtKernelSize_;

   wxTextCtrl* valNmxR_;
   wxTextCtrl* valNmxC_;
   wxTextCtrl* valHHR_;
   wxTextCtrl* valHHC_;
   wxTextCtrl* valHLR_;
   wxTextCtrl* valHLC_;
   wxTextCtrl* valMinPt_;
   wxChoice* valNmxType_;
   wxChoice* valHHType_;
   wxChoice* valHLType_;
   wxTextCtrl* valKernelSize_;


DECLARE_EVENT_TABLE()
};

class BgSpeedSelect : public wxDialog
{
public:
   BgSpeedSelect(wxWindow* parent, wxWindowID id, const wxString& title,
      const wxPoint& pos = wxDefaultPosition, const wxSize& size = wxDefaultSize,
      long style = wxDEFAULT_DIALOG_STYLE, const wxString& name = "dialogBox");
   ~BgSpeedSelect();
   void OnOk(wxCommandEvent& );
   void OnCancel(wxCommandEvent& );
   void SetSliderValue(float);
   void GetSliderValue(float&);

   // dialog parameters
   wxButton* okButton_;
   wxButton* cancelButton_;

   wxStaticText* txtQuality_;
   wxStaticText* txtSpeed_;

   wxSlider *sldSpeed_;
DECLARE_EVENT_TABLE()
};

extern IplImage *cbgImage_;

class BgMdiSegmentChild: public wxMDIChildFrame
{
public:
 
	wxArrayString arrayListFullPath;
	wxArrayString arrayListFileName;


	BgImage* segmImage_;


   //segmemtation parameters
   int		sigmaS, minRegion, kernelSize;
   float	sigmaR, aij, epsilon;
   bool		edgeParamsHaveChanged_;
   SpeedUpLevel	speedUpLevel_;
   float speedUpThreshold_;

   //window stuff
   BgImCanvas* displayImage_;
   // left panel stuff
   wxPanel*	optionsPanel_;
   wxPanel* subPanel1_;
   wxPanel* subPanel2_;
   wxPanel* subPanel3_;

   wxStaticBox* subPanelBox1_;
   wxStaticBox* subPanelBox2_;
   wxStaticBox* subPanelBox3_;
   wxStaticBox* subPanelBox4_;

   wxButton* runButton_;
   wxButton* loadButton_;
   wxButton* resultButton_;

   wxRadioBox* viewImSegRadio_;
   wxRadioBox* operationRadio_;
   wxCheckBox* viewBoundariesCheck_;
   wxRadioBox* segProcRadio_;

   wxStaticText* textKernelSize_;
   wxTextCtrl* txtKernelSize_;

   wxStaticText* textSigmaR_;
   wxTextCtrl* txtSigmaR_;

   wxStaticText* textSigmaS_;
   wxTextCtrl* txtSigmaS_;

   wxStaticText* textA_;
   wxTextCtrl* txtA_;

   wxStaticText* textEpsilon_;
   wxTextCtrl* txtEpsilon_;

   wxStaticText* textMinRegion_;
   wxTextCtrl* txtMinRegion_;

   wxListBox * listBoxPic_;
  
   bool	isCurrentHistory_;
   bool checkTextBoxes_;
   wxStaticText* textParamBox_;
   BgParameterHistoryBox*	paramComboBox_;

   bool m_bRunning;
   //store pointer to parent frame toolbar
   wxToolBar *toolbar;

   //keep track of current number of frames open
   bool window_open;

   //keep track of filename and window number
   char *filename_;
   int	window_number_;

   //keep track of display image width, height, and zoom level
   int	width_, height_;

   //keep track if max/min zoom occurred
   int	maxZoom_, minZoom_;

   BgMdiSegmentChild(wxMDIParentFrame *parent, const wxString& title, const wxPoint& pos, const wxSize& size, const long style);
   ~BgMdiSegmentChild();

   void GetAllFilePath( wxString rootPath );
   void OnQuit(wxCommandEvent& );
   void OnClose(wxCloseEvent& );
   void OnFocus(wxFocusEvent& );
   void ZoomWindow(void);
   void ZoomIn(void);
   void ZoomOut(void);
   void NoZoom(void);
   void UpdateZoomControl(void);

   void SaveEnable(void);
   void UpdateToolBar(void);
   void ResetToolBar(void);
   void ReadImage(char*, char*);

   void ReadFileDir(char * dir);
   void ShowDisplay();
   void OnLoadImage(wxCommandEvent& );
   void OnSaveSegmentedImage(wxCommandEvent& );
   void OnSaveBoundaries(char*, int);
   void OnSegment(wxCommandEvent& );
 
   void Segment(void);
   void SetphDiagram(int, float*, float*);
   void OnViewImSeg(wxCommandEvent& );
   void OnSegSelOper(wxCommandEvent&  WXUNUSED(event));
   void OnChangeParameters(wxCommandEvent& );
   void	OnUpdateTextBoxes(wxCommandEvent& );
   void OnListBox1Select(wxCommandEvent&);
   void OnUpdateSpeedUpLevel(wxCommandEvent& );
   void OnViewBoundaries(wxCommandEvent& );
   void OnUseWeightMap(wxCommandEvent& );
   void OnSaveEdgeInformation(wxCommandEvent& );
   //void OnChangeView
   void OnSize(wxSizeEvent& );

   int  GetParameters(int&, float&, float&, float&, int&, int&, int);
   DECLARE_EVENT_TABLE()
};

