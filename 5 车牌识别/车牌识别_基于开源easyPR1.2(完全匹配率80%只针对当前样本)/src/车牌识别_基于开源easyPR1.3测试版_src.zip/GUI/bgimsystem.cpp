/////////////////////////////////////////////////////////////////////////////
// Name:        bgimsystem.cpp
// Purpose:     Image processing system
// Author:      Bogdan Georgescu, Chris M. Christoudias
// Modified by:
// Created:     06/22/2000
// Copyright:   (c) Bogdan Georgescu, Chris M. Christoudias
// Version:     v0.1
/////////////////////////////////////////////////////////////////////////////

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"
#ifdef __BORLANDC__
   #pragma hdrstop
#endif

#ifndef WX_PRECOMP
   #include "wx/wx.h"
#endif

#include <wx/toolbar.h>
#include <wx/progdlg.h>
#include <highgui.h>
#if defined(__WXGTK__) || defined(__WXMOTIF__)
   #include "icons/mondrian.xpm"
   #include "icons/new.xpm"
   #include "icons/open.xpm"
   #include "icons/save.xpm"
   #include "icons/copy.xpm"
   #include "icons/cut.xpm"
   #include "icons/paste.xpm"
   #include "icons/print.xpm"
   #include "icons/help.xpm"
#endif

#include <wx/html/htmlwin.h>

#include "BgImagPGM.h"
#include "BgImagPNM.h"
#include "BgImCanvas.h"
// Edge detection include stuff
#include <math.h>
#include "BgImage.h"
#include "BgEdgeList.h"
#include "BgEdgeDetect.h"
#include "BgDefaults.h"

using namespace std;

extern const string GENERAL_TEST_PATH = "image/general_test";
extern const string NATIVE_TEST_PATH = "image/native_test";

#include "../MatLogic/matlogic.h"
#include <stdio.h>
#include <string.h>
#include "bgimsystem.h"
#include "../include/util.h"
IMPLEMENT_APP(BgApp)
// ---------------------------------------------------------------------------
// global variables
// ---------------------------------------------------------------------------

BgMdiFrame *g_frame = (BgMdiFrame *) NULL;
wxList g_children;

// For drawing lines in a canvas
static long g_xpos = -1;
static long g_ypos = -1;

static int	gs_nFrames	= 0;
static bool	on_exit		= false;


// ---------------------------------------------------------------------------
// event tables
// ---------------------------------------------------------------------------



// Note that BG_NEW_WINDOW and BG_ABOUT commands get passed
// to the parent window for processing, so no need to
// duplicate event handlers here.



BEGIN_EVENT_TABLE(BgMdiSegmentChild, wxMDIChildFrame)
EVT_MENU(BG_SEGM_LOAD_IMAGE, BgMdiSegmentChild::OnLoadImage)
EVT_MENU(BG_SEGM_SAVE_SEGMENTED, BgMdiSegmentChild::OnSaveSegmentedImage)
//EVT_MENU(BG_SEGM_SAVE_EDGEMAP, BgMdiSegmentChild::OnSaveBoundaries)
EVT_MENU(BG_CHILD_SEGM_QUIT, BgMdiSegmentChild::OnQuit)
EVT_MENU(BG_SEGM_SEGMENT, BgMdiSegmentChild::OnSegment)

EVT_MENU(BG_SEGM_SPEEDUP_NONE, BgMdiSegmentChild::OnUpdateSpeedUpLevel)
EVT_MENU(BG_SEGM_SPEEDUP_MEDM, BgMdiSegmentChild::OnUpdateSpeedUpLevel)
EVT_MENU(BG_SEGM_SPEEDUP_HIGH, BgMdiSegmentChild::OnUpdateSpeedUpLevel)

EVT_MENU(BG_CANVAS_SAVE_GRADMAP, BgMdiSegmentChild::OnSaveEdgeInformation)
EVT_MENU(BG_CANVAS_SAVE_CONFMAP, BgMdiSegmentChild::OnSaveEdgeInformation)
EVT_MENU(BG_CANVAS_SAVE_WEITMAP, BgMdiSegmentChild::OnSaveEdgeInformation)

EVT_SET_FOCUS(BgMdiSegmentChild::OnFocus)
EVT_CLOSE(BgMdiSegmentChild::OnClose)
EVT_SIZE(BgMdiSegmentChild::OnSize)

EVT_BUTTON(BG_SEGM_LOAD_IMAGE, BgMdiSegmentChild::OnLoadImage)
EVT_BUTTON(BG_SEGM_SEGMENT, BgMdiSegmentChild::OnSegment)

EVT_RADIOBOX(BG_SEGM_VIEW_IMSEG, BgMdiSegmentChild::OnViewImSeg)
EVT_RADIOBOX(BG_SEGM_SELOPER, BgMdiSegmentChild::OnSegSelOper)
EVT_CHECKBOX(BG_SEGM_VIEW_EDGES, BgMdiSegmentChild::OnViewBoundaries)
EVT_CHECKBOX(BG_SEGM_USE_EDGE_MAP, BgMdiSegmentChild::OnUseWeightMap)
EVT_COMBOBOX(BG_SEGM_CHANGE_PARAMS, BgMdiSegmentChild::OnChangeParameters)

EVT_TEXT(BG_SEGM_TEXT_SIGMAS, BgMdiSegmentChild::OnUpdateTextBoxes)
EVT_TEXT(BG_SEGM_TEXT_SIGMAR, BgMdiSegmentChild::OnUpdateTextBoxes)
EVT_TEXT(BG_SEGM_TEXT_MINREG, BgMdiSegmentChild::OnUpdateTextBoxes)
EVT_TEXT(BG_SEGM_TEXT_GRADWIN, BgMdiSegmentChild::OnUpdateTextBoxes)
EVT_TEXT(BG_SEGM_TEXT_AIJ, BgMdiSegmentChild::OnUpdateTextBoxes)
EVT_TEXT(BG_SEGM_TEXT_EPSILON, BgMdiSegmentChild::OnUpdateTextBoxes)

EVT_LISTBOX(BG_LISTBOX_PIC,BgMdiSegmentChild::OnListBox1Select)

END_EVENT_TABLE()



BEGIN_EVENT_TABLE(BgParamDialog, wxDialog)
EVT_BUTTON(BG_PARAMD_OK, BgParamDialog::OnOk)
EVT_BUTTON(BG_PARAMD_CANCEL, BgParamDialog::OnCancel)
END_EVENT_TABLE()

BEGIN_EVENT_TABLE(BgSpeedSelect, wxDialog)
EVT_BUTTON(BG_SPEEDSEL_OK, BgSpeedSelect::OnOk)
EVT_BUTTON(BG_SPEEDSEL_CANCEL, BgSpeedSelect::OnCancel)
END_EVENT_TABLE()

BEGIN_EVENT_TABLE(BgDialog, wxDialog)
EVT_BUTTON(BG_DIALOG_OK, BgDialog::OnExit)
EVT_PAINT(BgDialog::OnPaint)
END_EVENT_TABLE()

BEGIN_EVENT_TABLE(BgHoverBar, wxWindow)
EVT_BUTTON(BG_CANVAS_VIEW_BUTTON, BgHoverBar::ShowMenu)
EVT_BUTTON(BG_CANVAS_SAVE_BUTTON, BgHoverBar::ShowMenu)
END_EVENT_TABLE()

BEGIN_EVENT_TABLE(BgMenuPanel, wxPanel)
EVT_BUTTON(BG_CANVAS_VIEW_BUTTON, BgMenuPanel::ShowMenu)
EVT_BUTTON(BG_CANVAS_SAVE_BUTTON, BgMenuPanel::ShowMenu)
EVT_SIZE(BgMenuPanel::OnSize)
END_EVENT_TABLE()

// ===========================================================================
// implementation
// ===========================================================================

// ---------------------------------------------------------------------------
// Global Data used for Multi-Threaded Enviornment
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Log function
// ---------------------------------------------------------------------------


#define VAR_LOG_BUFFER_SIZE   (4096)

static wxChar varszBuf[VAR_LOG_BUFFER_SIZE];

FILE* glogfile;

void bgLog(const char* szFormat, ...)
{
   va_list argptr;
   va_start(argptr, szFormat);
   wxVsnprintf(varszBuf, WXSIZEOF(varszBuf), szFormat, argptr);
   va_end(argptr);
   ::wxLogMessage(varszBuf);
   bgLogFile(varszBuf);
}

void bgLogVar(const char* first, va_list alist)
{
//   va_start(alist, first);
   wxVsnprintf(varszBuf, WXSIZEOF(varszBuf), first, alist);
//   va_end(alist);
   ::wxLogMessage(varszBuf);
   bgLogFile(varszBuf);
}

void bgLogFile(const char* szFormat, ...)
{
   if (glogfile == 0)
      glogfile = fopen("filelog.txt", "w");
   va_list argptr;
   va_start(argptr, szFormat);
   vfprintf(glogfile, szFormat, argptr);
   va_end(argptr);
   fflush(glogfile);
}

inline int bgRound(double inline_x)
{
    return ((int) (inline_x+0.5));
}



// ---------------------------------------------------------------------------
// BgApp
// ---------------------------------------------------------------------------

// Initialise this in OnInit, not statically
bool BgApp::OnInit()
{
   // Create the main frame window
   
	g_frame = new BgMdiFrame((wxFrame *)NULL, -1, "���ڿ�ԴEasyPR",
      wxPoint(10, 10), wxSize(1024, 768),
      wxDEFAULT_FRAME_STYLE | wxHSCROLL | wxVSCROLL);
#ifdef __WXMSW__
#if 0
   // Experimental: change the window menu
   wxMenu* windowMenu = new wxMenu;
   windowMenu->Append(5000, "My menu item!");
   frame->SetWindowMenu(windowMenu);
#endif
#endif
   
   // Give it an icon
#ifdef __WXMSW__
   g_frame->SetIcon(wxIcon("bg_icn"));
#else
   g_frame->SetIcon(wxIcon( mondrian_xpm ));
#endif

   g_frame->CreateStatusBar();
   
   g_frame->Show(true);
   
   SetTopWindow(g_frame);

#if wxUSE_LIBPNG
  wxImage::AddHandler( new wxPNGHandler );
#endif

#if wxUSE_LIBJPEG
  wxImage::AddHandler( new wxJPEGHandler );
#endif

#if wxUSE_LIBTIFF
  wxImage::AddHandler( new wxTIFFHandler );
#endif

#if wxUSE_GIF
  wxImage::AddHandler( new wxGIFHandler );
#endif

#if wxUSE_PCX
  wxImage::AddHandler( new wxPCXHandler );
#endif

  wxImage::AddHandler( new bgPNMHandler );
  wxImage::AddHandler( new bgPGMHandler );
  wxMkdir("E:/result/");
   return true;
}
BEGIN_EVENT_TABLE(BgMdiFrame, wxMDIParentFrame)
EVT_MENU(BG_QUIT, BgMdiFrame::OnQuit)

EVT_MENU(BG_NEW_SEGM_WINDOW, BgMdiFrame::OnNewSegmWindow)
EVT_MENU(BG_LOAD_IMAGE, BgMdiFrame::OnLoadImage)
EVT_MENU(BG_SEGM_LOAD_IMAGE, BgMdiFrame::OnLoadImageSegm)
EVT_MENU(BG_SAVE_RESULT, BgMdiFrame::OnSaveResult)
EVT_MENU(BG_CROSS, BgMdiFrame::ZoomControl)
EVT_MENU(BG_ZOOM_IN, BgMdiFrame::ZoomControl)
EVT_MENU(BG_ZOOM_OUT, BgMdiFrame::ZoomControl)
EVT_MENU(BG_POINTER, BgMdiFrame::ZoomControl)
EVT_CLOSE(BgMdiFrame::OnClose)

EVT_SIZE(BgMdiFrame::OnSize)
END_EVENT_TABLE()


// ---------------------------------------------------------------------------
// BgMdiFrame
// ---------------------------------------------------------------------------

// Define my frame constructor
BgMdiFrame::BgMdiFrame(wxWindow *parent,
					   const wxWindowID id,
					   const wxString& title,
					   const wxPoint& pos,
					   const wxSize& size,
					   const long style)
					   : wxMDIParentFrame(parent, id, title, pos, size, style)
{
	logtext_ = new wxTextCtrl(this, -1, "Log window.\n",
		wxDefaultPosition, wxDefaultSize, wxTE_MULTILINE | wxSUNKEN_BORDER | wxTE_READONLY);
	logtext_->SetBackgroundColour("wheat");
	bglogctrl_ = new bgLogTextCtrl(logtext_);
	logTargetOld_ = wxLog::SetActiveTarget(bglogctrl_);
	logsize_ = DEFAULT_LOG_SIZE;

	CreateToolBar(wxNO_BORDER | wxTB_FLAT | wxTB_HORIZONTAL);
	InitToolBar(GetToolBar());

	//get program location directory
	strcpy(programDir_, wxGetCwd());

	//get help directory location
	//(NOTE: This code must be altered to function properly in UNIX.)
	strcpy(helpDir_, programDir_);
	strcat(helpDir_, "\\doc\\help.html");

	// Accelerators
	wxAcceleratorEntry entries[13];
	entries[0].Set(wxACCEL_ALT, (int) 'E', BG_NEW_EDGE_WINDOW);
	entries[1].Set(wxACCEL_ALT, (int) 'S', BG_NEW_SEGM_WINDOW);
	entries[2].Set(wxACCEL_ALT, (int) 'X', BG_QUIT);
	entries[3].Set(wxACCEL_ALT, (int) 'C', BG_CHILD_EDGE_QUIT);
	entries[4].Set(wxACCEL_SHIFT, (int) 'C', BG_CHILD_SEGM_QUIT);
	entries[5].Set(wxACCEL_CTRL, (int) 'H', BG_HELP);
	entries[6].Set(wxACCEL_CTRL, (int) 'S', BG_EDGE_SAVE_MAP);
	entries[7].Set(wxACCEL_SHIFT, (int) 'S', BG_SEGM_SAVE_SEGMENTED);
	entries[8].Set(wxACCEL_CTRL, (int) 'L', BG_LOAD_IMAGE_EDGE);
	entries[9].Set(wxACCEL_SHIFT, (int) 'L', BG_SEGM_LOAD_IMAGE);
	entries[10].Set(wxACCEL_SHIFT, (int) 'M', BG_SEGM_LOAD_MAP);
	entries[11].Set(wxACCEL_CTRL, (int) 'R', BG_EDGE_DETECT);
	entries[12].Set(wxACCEL_SHIFT, (int) 'R', BG_SEGM_SEGMENT);
	wxAcceleratorTable accel(13, entries);
	SetAcceleratorTable(accel);
	glogfile = 0;
}

void BgMdiFrame::OnClose(wxCloseEvent& event)
{
	if ( event.CanVeto() && (gs_nFrames > 0) )
	{
		wxString msg;
		if (gs_nFrames == 1)
			msg.Printf(_T("%d window still open, close anyhow?"), gs_nFrames);
		else
			msg.Printf(_T("%d windows still open, close anyhow?"), gs_nFrames);
		if ( wxMessageBox(msg, "Please confirm",
			wxICON_QUESTION | wxYES_NO) != wxYES )
		{
			event.Veto();

			return;
		}
	}

	//indicate that the system is exiting
	on_exit	= true;

	wxLog::SetActiveTarget(logTargetOld_);
	delete bglogctrl_;
	delete logtext_;

	// bgFileLog
	if (glogfile != 0)
		fclose(glogfile);

	event.Skip();
}

//sets the title of the active child frame
void BgMdiFrame::SetChildTitle(wxMDIChildFrame *activeChild, int zconst, int maxZoom, int minZoom)
{
	wxString	title;
	if(activeChild->GetId() == BG_SEGM_WINDOW)
	{
		BgMdiSegmentChild *segmChild	= (BgMdiSegmentChild *) activeChild;
		if(maxZoom)
			title.Printf(_T("Segmentation Frame %d - %s (%d x %d) x %d [Maximum Zoom]"), segmChild->window_number_, segmChild->filename_, segmChild->width_, segmChild->height_, zconst);
		else if(minZoom)
			title.Printf(_T("Segmentation Frame %d - %s (%d x %d) [Original Image]"), segmChild->window_number_, segmChild->filename_, segmChild->width_, segmChild->height_);
		else
			title.Printf(_T("Segmentation Frame %d - %s (%d x %d) x %d [Zoom]"), segmChild->window_number_, segmChild->filename_, segmChild->width_, segmChild->height_, zconst);
	}
	activeChild->SetTitle(title);
	return;
}

//updates toolbar when maximum zoom occurs
void BgMdiFrame::UpdateZoomControl(wxMDIChildFrame *activeChild, int maxZoom, int minZoom)
{
	if (activeChild->GetId() == BG_SEGM_WINDOW)
	{
		if(maxZoom)
			((BgMdiSegmentChild *) activeChild)->maxZoom_	= true;
		else
			((BgMdiSegmentChild *) activeChild)->maxZoom_	= false;
		if(minZoom)
			((BgMdiSegmentChild *) activeChild)->minZoom_	= true;
		else
			((BgMdiSegmentChild *) activeChild)->minZoom_	= false;
		((BgMdiSegmentChild *) activeChild)->UpdateZoomControl();
	}
}

void BgMdiFrame::OnQuit(wxCommandEvent& WXUNUSED(event))
{
	Close();
}


void BgMdiFrame::OnLoadImage(wxCommandEvent& WXUNUSED(event))
{

	wxMDIChildFrame *activeChild = GetActiveChild();
	wxCommandEvent zcev;

	{
		//read an image
		char *pathname, *filename;
		GetImageFileInfo(&pathname, &filename);
		if(pathname)
		{

			//get current width and height of this window
			int width, height;
			GetSize(&width, &height);

			//half window width
			width = width/2;




			//create a segmentation window
			OnNewSegmWindow(zcev);

			//load read image into segment window
			activeChild = GetActiveChild();
			((BgMdiSegmentChild*) activeChild)->ReadFileDir(pathname);
		

			//set position and size of segmnetation window
			activeChild->SetSize(0,0,width+350,height);

			//de-allocate memory used by filename
			delete [] filename;
		}
	}

}

void BgMdiFrame::OnLoadImageSegm(wxCommandEvent& WXUNUSED(event))
{
	BgMdiSegmentChild* activeChild;
	activeChild = 0;
	activeChild = (BgMdiSegmentChild*) GetActiveChild();
	wxCommandEvent zcev;
	if (activeChild != 0)
	{
		activeChild->OnLoadImage(zcev);
	} else
	{
		OnNewSegmWindow(zcev);
		activeChild = (BgMdiSegmentChild*) GetActiveChild();
		activeChild->OnLoadImage(zcev);
	}
}

void BgMdiFrame::OnSaveResult(wxCommandEvent& WXUNUSED(event))
{
	wxMDIChildFrame* activeChild = GetActiveChild();
	if(activeChild)
	{
		wxCommandEvent zcev;
		if (activeChild->GetId() == BG_SEGM_WINDOW)
			((BgMdiSegmentChild *) activeChild)->OnSaveSegmentedImage(zcev);
	}
}


void BgMdiFrame::OnNewSegmWindow(wxCommandEvent& WXUNUSED(event) )
{

	//indicate that another child frame will be created
	gs_nFrames++;

	// Make another frame, containing a edge processing window
	BgMdiSegmentChild *subframe = new BgMdiSegmentChild(g_frame, "Segmentation Frame",
		wxPoint(-1, -1), wxSize(-1, -1),
		wxDEFAULT_FRAME_STYLE);

	wxString title;
	title.Printf(_T("Segmentation Frame %d"), gs_nFrames);

	subframe->SetTitle(title);

	// Give it an icon
#ifdef __WXMSW__
	subframe->SetIcon(wxIcon("chrt_icn"));
#else
	subframe->SetIcon(wxIcon( mondrian_xpm ));
#endif

	//subframe->CreateStatusBar();


	subframe->Show(true);
	subframe->Fit();
}

void BgMdiFrame::GetImageFileInfo(char **pathname, char **filename)
{

	// get the file name
#if defined(__WXGTK__) || defined(__WXMOTIF__)
	wxFileDialog filedialog(this,"Choose an image file","","",
		"*",wxOPEN);
#else
	wxDirDialog filedialog(this,"ѡ���ļ���","E:/opencv/build/x86/vc9/bin/image/general_test");
#endif

	//retrieve and check filename
	*filename = (char *) NULL;
	*pathname = (char *) NULL;
	BgImCanvas *temp = new BgImCanvas(this, this, wxDefaultPosition, wxDefaultSize);
	if(filedialog.ShowModal()==wxID_OK)
	{
		char* temp_str	= (char *) filedialog.GetPath().c_str();
		*pathname	= new char [strlen(temp_str) + 1];
		strcpy(*pathname, temp_str);
	
	}

	//de-allocate memory
	delete temp;

	//done.
	return;
}

//manages toolbar zoom controls
void BgMdiFrame::ZoomControl(wxCommandEvent& event)
{
	//set display
	wxToolBar	*toolbar = GetToolBar();
	switch (event.m_id)
	{
	case BG_CROSS:
		toolbar->ToggleTool(BG_CROSS, true);
		toolbar->ToggleTool(BG_ZOOM_IN, false);
		toolbar->ToggleTool(BG_ZOOM_OUT, false);
		toolbar->ToggleTool(BG_POINTER, false);
		break;
	case BG_ZOOM_IN:
		toolbar->ToggleTool(BG_CROSS, false);
		toolbar->ToggleTool(BG_ZOOM_IN, true);
		toolbar->ToggleTool(BG_ZOOM_OUT, false);
		toolbar->ToggleTool(BG_POINTER, false);
		break;
	case BG_ZOOM_OUT:
		toolbar->ToggleTool(BG_CROSS, false);
		toolbar->ToggleTool(BG_ZOOM_IN, false);
		toolbar->ToggleTool(BG_ZOOM_OUT, true);
		toolbar->ToggleTool(BG_POINTER, false);
		break;
		//BG_POINTER:
	default:
		toolbar->ToggleTool(BG_CROSS, false);
		toolbar->ToggleTool(BG_ZOOM_IN, false);
		toolbar->ToggleTool(BG_ZOOM_OUT, false);
		toolbar->ToggleTool(BG_POINTER, true);
		break;
	}

	//set zoom functionality
	wxMDIChildFrame	*activeChild	= GetActiveChild();
	if(activeChild->GetId() == BG_SEGM_WINDOW)
	{
		switch (event.m_id)
		{
		case BG_CROSS:
			((BgMdiSegmentChild *) activeChild)->ZoomWindow();
			break;
		case BG_ZOOM_IN:
			((BgMdiSegmentChild *) activeChild)->ZoomIn();
			break;
		case BG_ZOOM_OUT:
			((BgMdiSegmentChild *) activeChild)->ZoomOut();
			break;
			//BG_POINTER:
		default:
			((BgMdiSegmentChild *) activeChild)->NoZoom();
			break;
		}
	}

	return;

}


void BgMdiFrame::OnSize(wxSizeEvent& WXUNUSED(event))
{
	int w, h;
	GetClientSize(&w, &h);
	logtext_->SetSize(0, h-logsize_, w, logsize_);
	GetClientWindow()->SetSize(0, 0, w, h-logsize_);
}


void BgMdiFrame::InitToolBar(wxToolBar* toolBar)
{
	const int	BITMAP_COUNT = 9;
	wxBitmap* bitmaps[BITMAP_COUNT];

#ifdef __WXMSW__
	bitmaps[0] = new wxBitmap( "icon1", wxBITMAP_TYPE_RESOURCE);
	bitmaps[1] = new wxBitmap( "icon7", wxBITMAP_TYPE_RESOURCE);
	bitmaps[2] = new wxBitmap( "icon8", wxBITMAP_TYPE_RESOURCE);
	bitmaps[3] = new wxBitmap( "icon2", wxBITMAP_TYPE_RESOURCE);
	bitmaps[4] = new wxBitmap( "icon3", wxBITMAP_TYPE_RESOURCE);
	bitmaps[5] = new wxBitmap( "icon9", wxBITMAP_TYPE_RESOURCE);
	bitmaps[6] = new wxBitmap("icon10", wxBITMAP_TYPE_RESOURCE);
	bitmaps[7] = new wxBitmap("icon11", wxBITMAP_TYPE_RESOURCE);
	bitmaps[8] = new wxBitmap("icon12", wxBITMAP_TYPE_RESOURCE);
#else
	bitmaps[0] = new wxBitmap( bnew_xpm );
	bitmaps[1] = new wxBitmap( bnsg_xpm );
	bitmaps[2] = new wxBitmap( bhelp_xpm );
	bitmaps[3] = new wxBitmap( bopen_xpm );
	bitmaps[4] = new wxBitmap( bsave_xpm );
	bitmaps[5] = new wxBitmap( bcros_xpm );
	bitmaps[6] = new wxBitmap( bzin_xpm );
	bitmaps[7] = new wxBitmap( bzout_xpm );
	bitmaps[8] = new wxBitmap( bpoin_xpm );

#endif

#ifdef __WXMSW__
	int width = 24;
#else
	int width = 16;
#endif
	int currentX = 5;

	toolBar->AddTool( BG_LOAD_IMAGE, *(bitmaps[3]), wxNullBitmap, false, currentX, -1, (wxObject *) NULL, "Load image for processing");
	currentX += width + 5;
	toolBar->AddTool( BG_SAVE_RESULT, *(bitmaps[4]), wxNullBitmap, false, currentX, -1, (wxObject *) NULL, "Save result");
	currentX += width + 5;


	//set bitmap size of controls buttons to 20x20
	wxSize tool_size(20,20);
	toolBar->SetToolBitmapSize(tool_size);

	toolBar->Realize();

	//disable certain tools
	toolBar->EnableTool(BG_SAVE_RESULT, false);
	toolBar->EnableTool(BG_CROSS, false);
	toolBar->EnableTool(BG_ZOOM_IN, false);
	toolBar->EnableTool(BG_ZOOM_OUT, false);
	toolBar->EnableTool(BG_POINTER, false);

	int i;
	for (i = 0; i < BITMAP_COUNT; i++)
		delete bitmaps[i];
}


// ---------------------------------------------------------------------------
// CBgPointSet
// ---------------------------------------------------------------------------



// ---------------------------------------------------------------------------
// BgParameterHistory
// ---------------------------------------------------------------------------

BgParameterHistory::BgParameterHistory( void )
{
	params_		= (void *) NULL;
	listSize_	= 0;
	next_		= (BgParameterHistory *) NULL;
}

BgParameterHistory::BgParameterHistory(void *parameters, int itemCount)
{
	params_		= parameters;
	listSize_	= itemCount;
	next_		= (BgParameterHistory *) NULL;
}


BgParameterHistory::~BgParameterHistory( void )
{
	if(params_) delete [] params_;
}

// ---------------------------------------------------------------------------
// BgParameterHistoryBox
// ---------------------------------------------------------------------------

BgParameterHistoryBox::BgParameterHistoryBox(wxWindow* parent, wxWindowID id, const wxString& value, const wxPoint& pos, const wxSize& size, int n, long style, const wxValidator& validator, const wxString& name)
                     : wxComboBox(parent, id, value, pos, size, 0, (wxString*) NULL, style, validator, name)
{
	//initialize history list
	maxCount_		= n;
	listCount_		= 0;
	historyList_	= (BgParameterHistory *) NULL;

	//initialize combo box
	Append("Current");
	SetSelection(0);
}

BgParameterHistoryBox::~BgParameterHistoryBox( void )
{
	//delete history...
	BgParameterHistory	*temp;
	while(historyList_)
	{
		temp			= historyList_;
		historyList_	= historyList_->next_;
		delete temp;
	}
}

void BgParameterHistoryBox::AddParameterList(void *parameters, int itemCount)
{
	if(listCount_ < maxCount_)
	{
		BgParameterHistory	*newHistory	= new BgParameterHistory(parameters, itemCount);
		newHistory->next_	= historyList_;
		historyList_		= newHistory;
		listCount_++;
		char str[40];
		sprintf(str, "Parameter List -%d", listCount_);
		Append(str);
	}
	else
	{
		BgParameterHistory	*newHistory	= historyList_;
		while(newHistory->next_->next_)	newHistory	= newHistory->next_;
		if(newHistory->next_->params_) delete newHistory->next_->params_;
		newHistory->next_->params_		= parameters;
		newHistory->next_->listSize_	= itemCount;
		newHistory->next_->next_		= historyList_;
		historyList_					= newHistory->next_;
		newHistory->next_				= (BgParameterHistory *) NULL;
	}
}

void *BgParameterHistoryBox::GetParameterListData(int indexNumber)
{
	if(indexNumber < listCount_)
	{
		BgParameterHistory	*currentHistory	= historyList_;
		int count = 0;
		while(indexNumber != count)
		{
			currentHistory	= currentHistory->next_;
			count++;
		}
		return currentHistory->params_;
	}
	return (void *) NULL;
}

int BgParameterHistoryBox::GetParameterListCount(int indexNumber)
{
	if(indexNumber < listCount_)
	{
		BgParameterHistory	*currentHistory	= historyList_;
		int count = 0;
		while(indexNumber != count)
		{
			currentHistory	= currentHistory->next_;
			count++;
		}
		return currentHistory->listSize_;
	}
	return -1;
}

void BgParameterHistoryBox::UseParameterList(int indexNumber)
{
	if((indexNumber < listCount_) && (indexNumber != 0))
	{
		BgParameterHistory	*previousHistory	= historyList_;
		int count = 0;
		while(count != indexNumber - 1)
		{
			previousHistory	= previousHistory->next_;
			count++;
		}
		BgParameterHistory	*currentHistory		= previousHistory->next_;
		previousHistory->next_					= currentHistory->next_;
		currentHistory->next_					= historyList_;
		historyList_							= currentHistory;
	}
	return;
}

void BgParameterHistoryBox::SetCurrentList(void *parameters, int itemCount)
{
}

void *BgParameterHistoryBox::GetCurrentListData( void )
{
	return currentList_.params_;
}

int BgParameterHistoryBox::GetCurrentListCount( void )
{
	return currentList_.listSize_;
}


// ---------------------------------------------------------------------------
// BgThread
// ---------------------------------------------------------------------------

BgThread::BgThread(wxThreadKind kind, void foo(void*), void *Object) : wxThread(kind)
{
	function_	= foo;
	Object_		= Object;
}

BgThread::~BgThread( void )
{
	function_	= NULL;
	Object_		= NULL;
}

void *BgThread::Entry( void )
{
	function_(Object_);
	return (void *) NULL;
}

// ---------------------------------------------------------------------------
// BgDialog
// ---------------------------------------------------------------------------

BgDialog::BgDialog(wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style, const wxString& name)
		: wxDialog(parent, id, title, pos, size, style, name)
{
	
	okButton_	= new wxButton(this, BG_DIALOG_OK, "OK", wxPoint(size.GetWidth()/2-40, size.GetHeight()-60));
}

BgDialog::~BgDialog( void )
{
	delete okButton_;
}

void BgDialog::AddText(BgText *text)
{
	tlist_.AddText(text);
}

void BgDialog::AddBitmap(BgBitmap *bitmap)
{
	blist_.AddBitmap(bitmap);
}

void BgDialog::RemoveText(int id)
{
	tlist_.RemoveText(id);
}

void BgDialog::RemoveBitmap(BgBitmap *bitmap)
{
	blist_.RemoveBitmap(bitmap);
}

void BgDialog::OnPaint(wxPaintEvent& WXUNUSED(event))
{

	wxPaintDC	dc(this);

	//draw new text to the image from text object list
	BgText	*bgText;
	tlist_.ResetList();
	while(bgText = tlist_.GetText())
	{
		dc.SetFont(*(bgText->font_));
		dc.DrawText(bgText->text_, bgText->x_, bgText->y_);
	}

	//draw bitmaps
	blist_.ResetList();
	BgBitmap	*bitmap;
	while(bitmap = blist_.GetBitmap())
		dc.DrawBitmap(*(bitmap->bitmap_), bitmap->location_x_, bitmap->location_y_, true);

}

void BgDialog::OnExit(wxCommandEvent& WXUNUSED(event))
{
	EndModal(wxID_OK);
}

// ---------------------------------------------------------------------------
// BgHoverBar
// ---------------------------------------------------------------------------

BgHoverBar::BgHoverBar(wxWindow* parent, wxWindowID id, int gradViewId, int confViewId, int weitViewId, int custViewId, int gradSaveId, int confSaveId, int weitSaveId)
		  : wxWindow(parent, id, wxDefaultPosition, wxDefaultSize, wxRAISED_BORDER)
{
	//set the size of the window
	SetSize(120,30);

	//place a button using a bitmap
	menuButton1_	= new wxBitmapButton(this, BG_CANVAS_VIEW_BUTTON, wxBitmap("down_arrow", wxBITMAP_TYPE_RESOURCE), wxPoint(33,2), wxSize(18,20));
	menuButton2_	= new wxBitmapButton(this, BG_CANVAS_SAVE_BUTTON, wxBitmap("down_arrow", wxBITMAP_TYPE_RESOURCE), wxPoint(92,2), wxSize(18,20));
	menuText1_		= new wxStaticText(this, -1, "View", wxPoint(5,5), wxSize(25,20));
	menuText2_		= new wxStaticText(this, -1, "Save", wxPoint(62,5), wxSize(25,20));

	//get view menu identification constants
	gradViewId_	= gradViewId;
	confViewId_	= confViewId;
	weitViewId_	= weitViewId;
	custViewId_	= custViewId;
	gradSaveId_	= gradSaveId;
	confSaveId_	= confSaveId;
	weitSaveId_	= weitSaveId;

	//create view menu
	view_menu = new wxMenu;
	view_menu->Append(gradViewId_, "&Gradient Map", "", true);
	view_menu->Append(confViewId_, "&Confidence Map", "", true);
	view_menu->Append(weitViewId_, "&Weight Map12", "", true);
	view_menu->Append(custViewId_, "C&ustom Weight Map", "", true);

	//create save menu
	save_menu = new wxMenu;
	save_menu->Append(gradSaveId_, "&Gradient Map");
	save_menu->Append(confSaveId_, "&Confidence Map");
	save_menu->Append(weitSaveId_, "&Weight Map123");

}

BgHoverBar::~BgHoverBar( void )
{
	//de-allocate menus...
	delete view_menu;
	delete save_menu;
}

void BgHoverBar::ShowMenu(wxCommandEvent& event)
{
	int buttonId	= event.GetId();
	if(buttonId	== BG_CANVAS_VIEW_BUTTON)
	{
		menuText1_->SetForegroundColour(wxColour(0,0,100));
		menuText2_->SetForegroundColour(wxColour(0,0,0));
		menuText1_->Refresh();
		menuText2_->Refresh();
		PopupMenu(view_menu, 0, 26);
	}
	else
	{
		menuText1_->SetForegroundColour(wxColour(0,0,0));
		menuText2_->SetForegroundColour(wxColour(0,0,100));
		menuText1_->Refresh();
		menuText2_->Refresh();
		PopupMenu(save_menu, 0, 26);
	}
	Update();
}

void BgHoverBar::CheckViewItem(long viewItemId)
{
	view_menu->Check(gradViewId_, false);
	view_menu->Check(confViewId_, false);
	view_menu->Check(weitViewId_, false);
	view_menu->Check(custViewId_, false);
	view_menu->Check(viewItemId, true);
}

void BgHoverBar::Update( void )
{
	menuText1_->SetForegroundColour(wxColour(0,0,0));
	menuText2_->SetForegroundColour(wxColour(0,0,0));
	menuText1_->Refresh();
	menuText2_->Refresh();
}

// ---------------------------------------------------------------------------
// BgMenuPanel
// ---------------------------------------------------------------------------

BgMenuPanel::BgMenuPanel(wxWindow* parent, wxWindowID id, int gradViewId, int confViewId, int weitViewId, int custViewId, int gradSaveId, int confSaveId, int weitSaveId)
		   : wxPanel(parent, id, wxDefaultPosition, wxDefaultSize)
{
	//keep pointer to scroll window
	scrollWindow_	= (wxWindow *) NULL;

	//set the position and size of the window
	SetSize(0,0,120,30);

	//place a button using a bitmap
	menuButton1_	= new wxBitmapButton(this, BG_CANVAS_VIEW_BUTTON, wxBitmap("down_arrow", wxBITMAP_TYPE_RESOURCE), wxPoint(33,2), wxSize(18,20));
	menuButton2_	= new wxBitmapButton(this, BG_CANVAS_SAVE_BUTTON, wxBitmap("down_arrow", wxBITMAP_TYPE_RESOURCE), wxPoint(92,2), wxSize(18,20));
	menuText1_		= new wxStaticText(this, -1, "View", wxPoint(5,5), wxSize(25,20));
	menuText2_		= new wxStaticText(this, -1, "Save", wxPoint(62,5), wxSize(25,20));

	//get view menu identification constants
	gradViewId_	= gradViewId;
	confViewId_	= confViewId;
	weitViewId_	= weitViewId;
	custViewId_	= custViewId;
	gradSaveId_	= gradSaveId;
	confSaveId_	= confSaveId;
	weitSaveId_	= weitSaveId;

	//create view menu
	view_menu = new wxMenu;
	view_menu->Append(gradViewId_, "&Gradient Map", "", true);
	view_menu->Append(confViewId_, "&Confidence Map", "", true);
	view_menu->Append(weitViewId_, "&Weight Map11", "", true);
	view_menu->Append(custViewId_, "C&ustom Weight Map", "", true);

	//create save menu
	save_menu = new wxMenu;
	save_menu->Append(gradSaveId_, "&Gradient Map");
	save_menu->Append(confSaveId_, "&Confidence Map");
	save_menu->Append(weitSaveId_, "&Weight Map");

}

BgMenuPanel::~BgMenuPanel( void )
{
	//de-allocate menus...
	delete view_menu;
	delete save_menu;
}

void BgMenuPanel::ShowMenu(wxCommandEvent& event)
{
	int buttonId	= event.GetId();
	if(buttonId	== BG_CANVAS_VIEW_BUTTON)
	{
		menuText1_->SetForegroundColour(wxColour(0,0,200));
		menuText2_->SetForegroundColour(wxColour(0,0,0));
		menuText1_->Refresh();
		menuText2_->Refresh();
		PopupMenu(view_menu, 0, 26);
	}
	else
	{
		menuText1_->SetForegroundColour(wxColour(0,0,0));
		menuText2_->SetForegroundColour(wxColour(0,0,200));
		menuText1_->Refresh();
		menuText2_->Refresh();
		PopupMenu(save_menu, 0, 26);
	}
	Update();
}

void BgMenuPanel::CheckViewItem(long viewItemId)
{
	view_menu->Check(gradViewId_, false);
	view_menu->Check(confViewId_, false);
	view_menu->Check(weitViewId_, false);
	view_menu->Check(custViewId_, false);
	view_menu->Check(viewItemId, true);
}

void BgMenuPanel::Update( void )
{
	menuText1_->SetForegroundColour(wxColour(0,0,0));
	menuText2_->SetForegroundColour(wxColour(0,0,0));
	menuText1_->Refresh();
	menuText2_->Refresh();
}

void BgMenuPanel::EnableMenu(bool enable)
{
	menuText1_->Enable(enable);
	menuText2_->Enable(enable);
	menuButton1_->Enable(enable);
	menuButton2_->Enable(enable);
}

//adjusts size of scroll window
void BgMenuPanel::OnSize(wxSizeEvent& WXUNUSED(event))
{
	if(scrollWindow_)
	{
		int w, h;
		GetClientSize(&w, &h);
		scrollWindow_->SetSize(0,PLOT_MENU_HEIGHT,w,h-PLOT_MENU_HEIGHT);
	}
}

void BgMenuPanel::SetScrollWindow(wxWindow *scrollwindow)
{
	scrollWindow_	= scrollwindow;
}

// ---------------------------------------------------------------------------
// BgLineSet
// ---------------------------------------------------------------------------


// ---------------------------------------------------------------------------
// BgParamDialog
// ---------------------------------------------------------------------------

BgParamDialog::BgParamDialog(wxWindow* parent, wxWindowID id, const wxString& title,
      const wxPoint& pos, const wxSize& size,
      long style, const wxString& name)
: wxDialog(parent, id, title, pos, size, style, name)
{
   okButton_ = new wxButton(this, BG_PARAMD_OK, "Ok", wxPoint(20+C_PARAMX+10,450));
   cancelButton_ = new wxButton(this, BG_PARAMD_CANCEL, "Cancel", wxPoint(20+C_PARAMX+10+C_PARAMDX+60,450));
   
 

   txtKernelSize_ = new wxStaticText(this, -1, "Grad Win.", wxPoint(20+C_PARAMX-5,0+C_PARAMY+0*C_PARAMDY));
   valKernelSize_ = new wxTextCtrl(this, -1, "NA     ", wxPoint(20+C_PARAMX+C_PARAMDX+35,0+C_PARAMY+0*C_PARAMDY), wxSize(C_PARAMSX-20,C_PARAMSY));

   txtMinPt_ = new wxStaticText(this, -1, "Min. length", wxPoint(20+C_PARAMX-5,0+C_PARAMY+1*C_PARAMDY));
   valMinPt_ = new wxTextCtrl(this, -1, "NA     ", wxPoint(20+C_PARAMX+C_PARAMDX+35,0+C_PARAMY+1*C_PARAMDY), wxSize(C_PARAMSX-20,C_PARAMSY));

   wxStaticBox* nmxSB = new wxStaticBox(this, -1, "Nonmaxima supp.", wxPoint(20+5, 80+0), wxSize(140,4*C_PARAMDY-5));
   txtNmxType_ = new wxStaticText(this, -1, "Type", wxPoint(20+C_PARAMX, 80+C_PARAMY+0*C_PARAMDY));
   valNmxType_ = new wxChoice(this, -1, wxPoint(20+C_PARAMX+C_PARAMDX,80+C_PARAMY+0*C_PARAMDY), wxSize(C_PARAMSX,C_PARAMSY));
   txtNmxR_ = new wxStaticText(this, -1, "Rank", wxPoint(20+C_PARAMX,80+C_PARAMY+1*C_PARAMDY));
   valNmxR_ = new wxTextCtrl(this, -1, "NA     ", wxPoint(20+C_PARAMX+C_PARAMDX,80+C_PARAMY+1*C_PARAMDY), wxSize(C_PARAMSX,C_PARAMSY));
   txtNmxC_ = new wxStaticText(this, -1, "Conf", wxPoint(20+C_PARAMX,80+C_PARAMY+2*C_PARAMDY));
   valNmxC_ = new wxTextCtrl(this, -1, "NA     ", wxPoint(20+C_PARAMX+C_PARAMDX,80+C_PARAMY+2*C_PARAMDY), wxSize(C_PARAMSX,C_PARAMSY));

   wxStaticBox* hhSB = new wxStaticBox(this, -1, "Hyst. High Tr.", wxPoint(20+5, 200+0), wxSize(140,4*C_PARAMDY-5));
   txtHHType_ = new wxStaticText(this, -1, "Type", wxPoint(20+C_PARAMX,200+C_PARAMY+0*C_PARAMDY));
   txtHHR_ = new wxStaticText(this, -1, "Rank", wxPoint(20+C_PARAMX,200+C_PARAMY+1*C_PARAMDY));
   txtHHC_ = new wxStaticText(this, -1, "Conf", wxPoint(20+C_PARAMX,200+C_PARAMY+2*C_PARAMDY));
   valHHType_ = new wxChoice(this, -1, wxPoint(20+C_PARAMX+C_PARAMDX,200+C_PARAMY+0*C_PARAMDY), wxSize(C_PARAMSX,C_PARAMSY));
   valHHR_ = new wxTextCtrl(this, -1, "NA     ", wxPoint(20+C_PARAMX+C_PARAMDX,200+C_PARAMY+1*C_PARAMDY), wxSize(C_PARAMSX,C_PARAMSY));
   valHHC_ = new wxTextCtrl(this, -1, "NA     ", wxPoint(20+C_PARAMX+C_PARAMDX,200+C_PARAMY+2*C_PARAMDY), wxSize(C_PARAMSX,C_PARAMSY));

   wxStaticBox* hlSB = new wxStaticBox(this, -1, "Hyst. Low Tr.", wxPoint(20+5, 320+0), wxSize(140, 4*C_PARAMDY-5));
   txtHLType_ = new wxStaticText(this, -1, "Type", wxPoint(20+C_PARAMX,320+C_PARAMY+0*C_PARAMDY));
   txtHLR_ = new wxStaticText(this, -1, "Rank", wxPoint(20+C_PARAMX,320+C_PARAMY+1*C_PARAMDY));
   txtHLC_ = new wxStaticText(this, -1, "Conf", wxPoint(20+C_PARAMX,320+C_PARAMY+2*C_PARAMDY));
   valHLType_ = new wxChoice(this, -1, wxPoint(20+C_PARAMX+C_PARAMDX,320+C_PARAMY+0*C_PARAMDY), wxSize(C_PARAMSX,C_PARAMSY));
   valHLR_ = new wxTextCtrl(this, -1, "NA     ", wxPoint(20+C_PARAMX+C_PARAMDX,320+C_PARAMY+1*C_PARAMDY), wxSize(C_PARAMSX,C_PARAMSY));
   valHLC_ = new wxTextCtrl(this, -1, "NA     ", wxPoint(20+C_PARAMX+C_PARAMDX,320+C_PARAMY+2*C_PARAMDY), wxSize(C_PARAMSX,C_PARAMSY));



   // put choices
   valNmxType_->Append("Arc");
   valNmxType_->Append("Vertical Line");
   valNmxType_->Append("Horizontal Line");
   valNmxType_->Append("Line");
   valNmxType_->Append("Box");

   valHHType_->Append("Arc");
   valHHType_->Append("Vertical Line");
   valHHType_->Append("Horizontal Line");
   valHHType_->Append("Line");
   valHHType_->Append("Box");
   valHHType_->Append("Custom");

   valHLType_->Append("Arc");
   valHLType_->Append("Vertical Line");
   valHLType_->Append("Horizontal Line");
   valHLType_->Append("Line");
   valHLType_->Append("Box");
   valHLType_->Append("Custom");

}

BgParamDialog::~BgParamDialog()
{
   delete txtNmxR_;
   delete txtNmxC_;
   delete txtHHR_;
   delete txtHHC_;
   delete txtHLR_;
   delete txtHLC_;
   delete txtMinPt_;
   delete txtNmxType_;
   delete txtHHType_;
   delete txtHLType_;
   delete txtKernelSize_;

   delete valNmxR_;
   delete valNmxC_;
   delete valHHR_;
   delete valHHC_;
   delete valHLR_;
   delete valHLC_;
   delete valMinPt_;
   delete valNmxType_;
   delete valHHType_;
   delete valHLType_;
   delete valKernelSize_;

   delete okButton_;
   delete cancelButton_;
}

void BgParamDialog::OnOk(wxCommandEvent& WXUNUSED(event))
{
   EndModal(wxID_OK);
}

void BgParamDialog::OnCancel(wxCommandEvent& WXUNUSED(event))
{
   EndModal(wxID_CANCEL);
}

void BgParamDialog::SetValues(double nmxR, double nmxC, double hhR, double hhC, double hlR, double hlC,
                              int nMin, int nmxT, int hhT, int hlT, int ks)
{
   wxString ts;
   ts = wxString::Format("%.3g", nmxR);
   valNmxR_->SetValue(ts);
   ts = wxString::Format("%.3g", nmxC);
   valNmxC_->SetValue(ts);
   ts = wxString::Format("%.3g", hhR);
   valHHR_->SetValue(ts);
   ts = wxString::Format("%.3g", hhC);
   valHHC_->SetValue(ts);
   ts = wxString::Format("%.3g", hlR);
   valHLR_->SetValue(ts);
   ts = wxString::Format("%.3g", hlC);
   valHLC_->SetValue(ts);
   ts = wxString::Format("%d", nMin);
   valMinPt_->SetValue(ts);
   valNmxType_->SetSelection(nmxT);
   valHHType_->SetSelection(hhT);
   valHLType_->SetSelection(hlT);
   ts = wxString::Format("%d", ks);
   valKernelSize_->SetValue(ts);

}

void BgParamDialog::GetValues(double& nmxR, double& nmxC, double& hhR, double& hhC, double& hlR, double& hlC,
                              int& nMin, int& nmxT, int& hhT, int& hlT, int& ks)
{
   double td;
   long tl;
   int ti;

   td = -1;
   tl = -1;
   ti = -1;
   if ((valNmxR_->GetValue().ToDouble(&td) == true) && (td>=0))
      nmxR = td;
   else
      bgLog("nmx. rank value out of range.\n");
   
   if ((valNmxC_->GetValue().ToDouble(&td) == true) && (td>=0))
      nmxC = td;
   else
      bgLog("nmx. conf. value out of range.\n");

   if ((valHHR_->GetValue().ToDouble(&td) == true) && (td>=0))
      hhR = td;
   else
      bgLog("hyst. high rank value out of range.\n");

   if ((valHHC_->GetValue().ToDouble(&td) == true) && (td>=0))
      hhC = td;
   else
      bgLog("hyst. high conf. value out of range.\n");

   if ((valHLR_->GetValue().ToDouble(&td) == true) && (td>=0))
      hlR = td;
   else
      bgLog("hyst. low rank value out of range.\n");

   if ((valHLC_->GetValue().ToDouble(&td) == true) && (td>=0))
      hlC = td;
   else
      bgLog("hyst. low conf. value out of range.\n");

   if ((valMinPt_->GetValue().ToLong(&tl) == true) && (tl>=0))
      nMin = (int) tl;
   else
      bgLog("min. edge points value out of range.\n");

   if ((ti=valNmxType_->GetSelection()) != -1)
      nmxT = ti;

   if ((ti=valHHType_->GetSelection()) != -1)
      hhT = ti;

   if ((ti=valHLType_->GetSelection()) != -1)
      hlT = ti;

   if ((valKernelSize_->GetValue().ToLong(&tl) == true) && (tl>0) && ((2*tl+1)<=MAX_FILTS))
      ks = (int) tl;
   else
      bgLog("kernel radius value out of range.\n");


}

// ---------------------------------------------------------------------------
// BgSpeedSelect
// ---------------------------------------------------------------------------

BgSpeedSelect::BgSpeedSelect(wxWindow* parent, wxWindowID id, const wxString& title,
      const wxPoint& pos, const wxSize& size,
      long style, const wxString& name)
: wxDialog(parent, id, title, pos, size, style, name)
{
   okButton_ = new wxButton(this, BG_SPEEDSEL_OK, "Ok", wxPoint(30,80));
   cancelButton_ = new wxButton(this, BG_SPEEDSEL_CANCEL, "Cancel", wxPoint(120,80));
   
   txtQuality_ = new wxStaticText(this, -1, "Speed", wxPoint(160, 10));
   txtSpeed_ = new wxStaticText(this, -1, "Quality", wxPoint(40, 10));

   sldSpeed_ = new wxSlider(this, BG_SPEEDSEL_SLD, 0, 0, 100, wxPoint(18,40), wxSize(155,-1),
                             wxSL_AUTOTICKS | wxSL_LABELS);
   sldSpeed_->SetTickFreq(20, 0);
}

BgSpeedSelect::~BgSpeedSelect()
{
   delete sldSpeed_;

   delete okButton_;
   delete cancelButton_;
}

void BgSpeedSelect::OnOk(wxCommandEvent& WXUNUSED(event))
{
   EndModal(wxID_OK);
}

void BgSpeedSelect::OnCancel(wxCommandEvent& WXUNUSED(event))
{
   EndModal(wxID_CANCEL);
}

void BgSpeedSelect::SetSliderValue(float sliderV)
{
   sldSpeed_->SetValue((int) (sliderV*100));
}

void BgSpeedSelect::GetSliderValue(float& sliderV)
{
   sliderV = (float) (sldSpeed_->GetValue() / 100.0);
}

// ---------------------------------------------------------------------------
// BgMdiSegmentChild
// ---------------------------------------------------------------------------

BgMdiSegmentChild::BgMdiSegmentChild(wxMDIParentFrame *parent, const wxString& title,
                           const wxPoint& pos, const wxSize& size,
                           const long style)
                           : wxMDIChildFrame(parent, BG_SEGM_WINDOW, title, pos, size, style)
{

   //set window number
   window_number_ = gs_nFrames;

   //assume image is not yet loaded into segmentation window
   filename_	= NULL;

   //split window to display the segmented image on the left hand side,
   //and the ph diagram on the right hand side

  
	int w, h;
	GetClientSize(&w, &h);
   //define ph diagram and segmented display image
 
   displayImage_ = new BgImCanvas(this, this, wxPoint(250, 0), wxSize( 2000, 900));
   displayImage_->SetScrollbars(20, 20, 50, 50);

 /*  
 */
  
  /* imagePlotSplitter_->SetSize(, w-bpsize_, h);
   displayImage_->setS*/


   //set lower bound zoom limit on display image
   //to the size of the original image
   displayImage_->SetMinZoomLevel(1);

   //place each image object into their corresponding positions in the split
   //window

   //inititalize segmentation parameters
   sigmaS		= 9;
   sigmaR		= float(5.5);
   aij			= float(0.3);
   epsilon		= float(0.3);
   minRegion	= 30;
   kernelSize	= 2;
	
   //set text size
   wxSize txtSize(50, 20);

   //allocate memory for display images
   cbgImage_			= NULL;

 
   //shut off text box monitoring
   checkTextBoxes_	= false;

   optionsPanel_	= new wxPanel(this, -1, wxPoint(0, 0), wxSize(BG_SEGM_OP_SIZEX, BG_SEGM_OP_SIZEY));

   wxBoxSizer	*toplayout = new wxBoxSizer(wxVERTICAL);

   loadButton_ = new wxButton(optionsPanel_, BG_SEGM_LOAD_IMAGE, "����ͼƬ");
   toplayout->Add(loadButton_, 0, wxCENTER | wxBOTTOM | wxTOP, 5);
   loadButton_->Show(false);
   
  
  
  

   wxArrayString pics;
   listBoxPic_ = new wxListBox(optionsPanel_,BG_LISTBOX_PIC,wxDefaultPosition,wxSize(BG_SP_WIDTH, 1000),pics);
   toplayout->Add(listBoxPic_, 0, wxCENTER | wxBOTTOM, 5);
    
   optionsPanel_->SetAutoLayout(true);
   toplayout->Fit(optionsPanel_);
   optionsPanel_->SetSizer(toplayout);

   g_children.Append(this);

   //set the size and sash position of the splitters

   GetClientSize(&w, &h);


   //indicate that the edge arameters have not changed
   edgeParamsHaveChanged_	= false;

   //place greek symbols
   wxBitmap	ro("ro", wxBITMAP_TYPE_RESOURCE), eta("eta", wxBITMAP_TYPE_RESOURCE);
   BgBitmap	ro_bmp(&ro, 1, RANK_CONF_MARGINX - 10, RANK_CONF_MARGINY/2 - 3);
   BgBitmap eta_bmp(&eta, 2, RANK_CONF_MARGINX, RANK_CONF_MARGINY/2 - 3);

   //declare that segmentation window is open
   window_open	= true;

   //get parent tool bar and update it
   toolbar	= parent->GetToolBar();
   UpdateToolBar();


   //intialize parameter combo box
   float *myParameters = new float [6];
   myParameters[0]	= sigmaS;
   myParameters[1]	= sigmaR;
   myParameters[2]	= aij;
   myParameters[3]	= epsilon;
   myParameters[4]	= minRegion;
   myParameters[5]	= kernelSize;
   paramComboBox_->SetCurrentList((void *) myParameters, 6);
   isCurrentHistory_	= true;

   //turn on text box monitoring
   checkTextBoxes_	= true;

   //initialize speedup level to medium
   speedUpLevel_	= HIGH_SPEEDUP;
   speedUpThreshold_ = (float) 0.8;

   //initialize max/min zoom
   maxZoom_	= 0;
   minZoom_	= 1;


   m_bRunning = true;

}


BgMdiSegmentChild::~BgMdiSegmentChild()
{
	if(filename_)	delete [] filename_;

   delete optionsPanel_;
   delete displayImage_;

   g_children.DeleteObject(this);
}


void BgMdiSegmentChild::OnListBox1Select(wxCommandEvent& event)
{
	int index =	listBoxPic_->GetSelection();
	if(index >=0 )
	{
		wxString fileFullPath = arrayListFullPath[index];

		CMatLogic::Instance()->DoReadImg((char*)fileFullPath.To8BitData());
		//acurayTest(GENERAL_TEST_PATH);
		if(testMain((char*)fileFullPath.To8BitData()) == 1)
		{
			wxString wxItem = arrayListFileName[index]+" ��ͬ";
			listBoxPic_->SetString(index,wxItem);
		}else
		{
			wxString wxItem = arrayListFileName[index]+" ����ͬ";
			listBoxPic_->SetString(index,wxItem);
		}
		//annMain();
	
		wxCommandEvent zcev;
		OnViewImSeg(zcev);
		timer_stop("end");
	}

}


void BgMdiSegmentChild::OnSegSelOper(wxCommandEvent&  WXUNUSED(event))
{
	
}
void BgMdiSegmentChild::OnViewImSeg(wxCommandEvent&  WXUNUSED(event))
{
	
	displayImage_->SetImage((unsigned char*)cbgImage_->imageData, 
				cbgImage_->width, cbgImage_->height);
	
}

//changes the paramters depending on the parameter list
void BgMdiSegmentChild::OnChangeParameters(wxCommandEvent& WXUNUSED(event))
{
	float	*myParameters;

	//get current selection index...
	int	selIndex	= paramComboBox_->GetSelection();

	//aquire current parameters and store them in "current parameter" slot...
	if(isCurrentHistory_)
	{
		int		csigmaS, cminRegion, ckernelSize;
		float	csigmaR, caij, cepsilon;
		GetParameters(csigmaS, csigmaR, caij, cepsilon, cminRegion, ckernelSize, 0);
		myParameters	= (float *) paramComboBox_->GetCurrentListData();
		myParameters[0]	= csigmaS;
		myParameters[1]	= csigmaR;
		myParameters[2]	= caij;
		myParameters[3]	= cepsilon;
		myParameters[4]	= cminRegion;
		myParameters[5]	= ckernelSize;
	}

	//check to see if the "current parameter" slot has been selected,
	//if so set the current history flag and use the parameters from
	//current history slot
	if(selIndex == 0)
	{
		isCurrentHistory_		= true;
		myParameters			= (float *) paramComboBox_->GetCurrentListData();
	}
	//otherwise indicate that the current slot has not just been selected
	//and get parameters from current parameter list
	else
	{
		isCurrentHistory_		= false;
		myParameters			= (float *) paramComboBox_->GetParameterListData(selIndex-1);
	}

	//set the text boxes...
	char str[10];
	checkTextBoxes_	= false;
	sprintf(str, "%d", bgRoundSign(myParameters[0]));
	txtSigmaS_->SetValue(str);
	sprintf(str, "%3.1f", myParameters[1]);
	txtSigmaR_->SetValue(str);
	sprintf(str, "%3.1f", myParameters[2]);
	txtA_->SetValue(str);
	sprintf(str, "%3.1f", myParameters[3]);
	txtEpsilon_->SetValue(str);
	sprintf(str, "%d", bgRoundSign(myParameters[4]));
	txtMinRegion_->SetValue(str);
	sprintf(str, "%d", bgRoundSign(myParameters[5]));
	txtKernelSize_->SetValue(str);
	checkTextBoxes_	= true;

}

void BgMdiSegmentChild::OnUpdateTextBoxes(wxCommandEvent& event)
{
	//update parameter history....
	if(checkTextBoxes_)
	{
		paramComboBox_->SetSelection(0);
		isCurrentHistory_	= true;
	}

	//check if a edge parameter has been changed
	int	id	= event.GetId();
	if((id == BG_SEGM_TEXT_GRADWIN)||(id == BG_SEGM_TEXT_AIJ)||(id == BG_SEGM_TEXT_EPSILON))
		edgeParamsHaveChanged_	= true;

}

void BgMdiSegmentChild::OnUpdateSpeedUpLevel(wxCommandEvent& event)
{
	long menuItemId			= event.GetId();
	wxMenuBar*	myMenuBar	= GetMenuBar();
	switch(menuItemId)
	{
	case BG_SEGM_SPEEDUP_MEDM:
		speedUpLevel_	= MED_SPEEDUP;
		myMenuBar->Check(BG_SEGM_SPEEDUP_NONE, false);
		myMenuBar->Check(BG_SEGM_SPEEDUP_HIGH, false);
		break;
	case BG_SEGM_SPEEDUP_HIGH:
		speedUpLevel_	= HIGH_SPEEDUP;
		myMenuBar->Check(BG_SEGM_SPEEDUP_NONE, false);
		myMenuBar->Check(BG_SEGM_SPEEDUP_MEDM, false);
      {
         BgSpeedSelect speedSelect(this, -1, "Select speed/quality", wxDefaultPosition, wxSize(220,150),
            wxDEFAULT_DIALOG_STYLE | wxDIALOG_MODAL);
         speedSelect.SetSliderValue(speedUpThreshold_);
         if (speedSelect.ShowModal()==wxID_OK)
         {
            speedSelect.GetSliderValue(speedUpThreshold_);
         }
      }

		break;
	default:
		speedUpLevel_	= NO_SPEEDUP;
		myMenuBar->Check(BG_SEGM_SPEEDUP_MEDM, false);
		myMenuBar->Check(BG_SEGM_SPEEDUP_HIGH, false);
	}
}

void BgMdiSegmentChild::OnViewBoundaries(wxCommandEvent&  WXUNUSED(event))
{
		

	bool	isChecked;
	isChecked = viewBoundariesCheck_->GetValue();

	Refresh();

}


//activates/de-activates the text boxes used for
//synergistic segmentation based on the use confidence
//map checkbox
void BgMdiSegmentChild::OnUseWeightMap(wxCommandEvent& WXUNUSED(event))
{

	//depending on use confidence map checkbox, activate/de-activate
	//text boxes

	//enable text boxes
	txtA_->Enable(true);
	txtEpsilon_->Enable(true);
	txtKernelSize_->Enable(true);
	textA_->Enable(true);
	textEpsilon_->Enable(true);
	textKernelSize_->Enable(true);
	//done.
	return;
}


void BgMdiSegmentChild::OnSaveEdgeInformation(wxCommandEvent& event)
{

#if defined(__WXGTK__) || defined(__WXMOTIF__)
	wxFileDialog filedialog(this,"Save Edge Information","","",
		"*",wxSAVE);
#else
	wxFileDialog filedialog(this,"Save Edge Information","","",
		"Matlab ASCII data files (*.dat)|*.dat|PGM Files (*.pgm)|*.pgm",
		wxSAVE);
#endif

   if(filedialog.ShowModal()==wxID_OK)
   {
   }

}

void BgMdiSegmentChild::OnSize(wxSizeEvent& WXUNUSED(event))
{
   int w, h;
   GetClientSize(&w, &h);
   optionsPanel_->SetSize(0, 0, BG_SEGM_OP_SIZEX, h);
   Refresh();
   //displayImage_->DoSetVirtualSize()

}



void BgMdiSegmentChild::OnQuit(wxCommandEvent& WXUNUSED(event))
{
   Close(true);
}


void BgMdiSegmentChild::OnClose(wxCloseEvent& event)
{
   //decrement global counter indicating number of frames open
   gs_nFrames--;
   //indicate that the window is now close (used by OnFocus)
   window_open = false;
   //reset the toolbar
   if(gs_nFrames == 0) ResetToolBar();
   event.Skip();
}

void BgMdiSegmentChild::OnFocus(wxFocusEvent& WXUNUSED(event))
{
	
}

void BgMdiSegmentChild::ZoomWindow(void)
{
	//display zoom window
	displayImage_->zoom_window	= true;
	displayImage_->zoom_in		= false;
	displayImage_->zoom_out		= false;
}

void BgMdiSegmentChild::ZoomIn(void)
{
	//zoom into display image
	displayImage_->zoom_window	= false;
	displayImage_->zoom_in		= true;
	displayImage_->zoom_out		= false;
	return;
}

void BgMdiSegmentChild::ZoomOut(void)
{
	//zoom out of display image
	displayImage_->zoom_window	= false;
	displayImage_->zoom_in		= false;
	displayImage_->zoom_out		= true;
	return;
}

void BgMdiSegmentChild::NoZoom(void)
{
	//do not zoom display image
	displayImage_->zoom_window	= false;
	displayImage_->zoom_in		= false;
	displayImage_->zoom_out		= false;
	return;
}

void BgMdiSegmentChild::UpdateZoomControl(void)
{
	//determine whether to enable zoom in control based on maximum zoom
	if(maxZoom_ || minZoom_)
		UpdateToolBar();
	else
	{
		toolbar->EnableTool(BG_ZOOM_IN, true);
		toolbar->EnableTool(BG_ZOOM_OUT, true);
//		toolbar->Realize();
	}
}
#include <stdio.h>
#include "wx/filefn.h"
#include "wx/dir.h"


void BgMdiSegmentChild::GetAllFilePath( wxString rootPath )
{
	wxArrayString pics;
	wxArrayString dirItems;                //Ŀ¼����
	dirItems.Add( rootPath );            //����������Ŀ¼·�����ӵ�Ŀ¼������

	wxString filename;    
	bool cont;   
	wxString tempPath;
	while( dirItems.GetCount() )        //��Ŀ¼���в�Ϊ��ʱִ��
	{
		wxDir dir( dirItems[0] );        //�򿪶���ǰ��Ŀ¼·��
		if( !dir.IsOpened() )
			return ;

		cont = dir.GetFirst( &filename );                        //��ȡ�׸��ļ�
		while ( cont )
		{
			tempPath = dirItems[0] + "\\" + filename;            //�ϳ� filename ������·��
			if( dir.Exists( tempPath ) )            //�ж� tempPath �Ƿ�ΪĿ¼
				dirItems.Add( tempPath );            //ΪĿ¼ʱ�����ӵ�Ŀ¼����
			else
			{
				printf("%s\n", tempPath );            //����������ļ�·��

				if(tempPath.find(".jpg") != -1 ||tempPath.find(".bmp") != -1
					|| tempPath.find(".png") != -1)
				{
					arrayListFullPath.push_back(tempPath);
					arrayListFileName.push_back(filename);
				}

			}

			cont = dir.GetNext(&filename);            //��ȡ��һ���ļ�
		}
		dirItems.RemoveAt(0);                //��ǰĿ¼������ɺ����Ŀ¼������ɾ��
	}
}



void BgMdiSegmentChild::SaveEnable(void)
{
	toolbar->EnableTool(BG_SAVE_RESULT, true);
}

void BgMdiSegmentChild::UpdateToolBar(void)
{
	//update toolbar (except during close)
	if(window_open)
	{
		//determine whether to enable save based on whether segmentation
		//has occurred
		bool save_enable =true;

		//determine whether to enable zoom controls based on whether image
		//has been loaded
		bool load_enable;
		load_enable	= true;
	

		//determine whether to enable zoom in control based on maximum zoom
		bool max_zoom;
		if(maxZoom_)
			max_zoom	= true;
		else
			max_zoom	= false;

		//determine whether to enable zoom out control based on minimum zoom
		bool min_zoom;
		if(minZoom_)
			min_zoom	= true;
		else
			min_zoom	= false;

		//adjust toolbar
		toolbar->SetToolShortHelp(BG_LOAD_IMAGE, "Load image to perform image segmentation");
		toolbar->SetToolShortHelp(BG_SAVE_RESULT, "Save segmented image");
		toolbar->EnableTool(BG_SAVE_RESULT, save_enable);
		toolbar->EnableTool(BG_CROSS, load_enable);
		toolbar->EnableTool(BG_ZOOM_IN, ((load_enable)&&(!max_zoom)));
		toolbar->EnableTool(BG_ZOOM_OUT, ((load_enable)&&(!min_zoom)));
		toolbar->EnableTool(BG_POINTER, true);

		//set to no zoom
		toolbar->ToggleTool(BG_CROSS, false);
		toolbar->ToggleTool(BG_ZOOM_IN, false);
		toolbar->ToggleTool(BG_ZOOM_OUT, false);
		toolbar->ToggleTool(BG_POINTER, true);
		displayImage_->SetCursor(wxCURSOR_ARROW);
		NoZoom();
	}
	return;
}

void BgMdiSegmentChild::ResetToolBar(void)
{
	//update toolbar
	toolbar->SetToolShortHelp(BG_LOAD_IMAGE, "Load image to process");
	toolbar->SetToolShortHelp(BG_SAVE_RESULT, "Save result");
	toolbar->EnableTool(BG_SAVE_RESULT, false);
	toolbar->EnableTool(BG_CROSS, false);
	toolbar->EnableTool(BG_ZOOM_IN, false);
	toolbar->EnableTool(BG_ZOOM_OUT, false);
	toolbar->EnableTool(BG_POINTER, false);
	toolbar->ToggleTool(BG_CROSS, false);
	toolbar->ToggleTool(BG_ZOOM_IN, false);
	toolbar->ToggleTool(BG_ZOOM_OUT, false);
	toolbar->ToggleTool(BG_POINTER, false);
	return;
}


void mySegment(void *Object)
{
	BgMdiSegmentChild *segmObj	= (BgMdiSegmentChild *) Object;
	segmObj->Segment();
}

void BgMdiSegmentChild::ShowDisplay()
{
	displayImage_->SetImage((unsigned char*)cbgImage_->imageData,cbgImage_->width,cbgImage_->height);
	wxCommandEvent zcev;
	OnViewImSeg(zcev);
}

void BgMdiSegmentChild::ReadFileDir(char * dir)
{
	GetAllFilePath(dir);

	for (int i=0;i<arrayListFileName.size();++i)
	{
		
		listBoxPic_->Append(arrayListFileName[i]);
	
	
	}

	//giveTheFile();

	//acurayTest(dir);
	//annMain();
	timer_stop("end");
}


void BgMdiSegmentChild::ReadImage(char *pathname, char *filename)
{


#ifdef DEBUG

#endif
	//done.
	return;
	/***********************************************/
}

void BgMdiSegmentChild::OnLoadImage(wxCommandEvent& WXUNUSED(event))
{
// get the file name
//   wxFileDialog filedialog(this,"Choose an image file","","",
//      "All files (*.*)|*.*|PNG files (*.png)|*.png|BMP files (*.bmp)|*.bmp|GIF files (*.gif)|*.gif|TIFF files (*.tif)|*.tif|JPEG files (*.jpg)|*.jpg|PNM files (*.pnm)|*.pnm",
//      wxOPEN);
#if defined(__WXGTK__) || defined(__WXMOTIF__)
  wxFileDialog filedialog(this,"Choose an image file","","",
			  "*",wxOPEN);
#else
   wxFileDialog filedialog(this,"Choose an image file","","",
      "Common image files|*.png;*.bmp;*.gif;*.tif;*.tiff;*.jpg;*.pnm;*.pgm;*.ppm|PNG files (*.png)|*.png|BMP files (*.bmp)|*.bmp|GIF files (*.gif)|*.gif|TIFF files (*.tif)|*.tif|JPEG files (*.jpg)|*.jpg|PNM files (*.pnm)|*.pnm|PGM/PPM files (*.pgm,*.ppm)|*.pgm;*.ppm",
	  wxOPEN|wxCHANGE_DIR);
#endif

   if(filedialog.ShowModal()==wxID_OK)
   {
	  ReadImage((char*)filedialog.GetPath().c_str(),(char*)filedialog.GetFilename().c_str());
   }
}


void BgMdiSegmentChild::OnSaveSegmentedImage(wxCommandEvent& WXUNUSED(event))
{
   

#if defined(__WXGTK__) || defined(__WXMOTIF__)
  wxFileDialog filedialog(this,"Choose an image file","","",
			  "*",wxSAVE);
#else
   wxFileDialog filedialog(this,"Choose an image file","","",
      "PNM files (*.pnm)|*.pnm|PNG files (*.png)|*.png|PCX files (*.pcx)|*.pcx|PGM files (*.pgm)|*.pgm|JPEG files (*.jpg) (not recommended)|*.jpg",
      wxSAVE);
#endif
   if(filedialog.ShowModal()==wxID_OK)
   {

	   //get the image type
	   int imtype;
	   switch (filedialog.GetFilterIndex())
	   {
	   case 0:
		   imtype = wxBITMAP_TYPE_PNM;
		   break;
	   case 1:
		   imtype = wxBITMAP_TYPE_PNG;
		   break;
	   case 2:
		   imtype = wxBITMAP_TYPE_PCX;
		   break;
	   case 3:
		   imtype = wxBITMAP_TYPE_ANY;
		   break;
	   case 4:
		   imtype = wxBITMAP_TYPE_JPEG;
		   break;
	   default:
		   return;
	   }
	   
	   
		   
		   //get path and add extension
		   char *path	= new char [strlen(filedialog.GetPath()) + 1];
		   strcpy(path, filedialog.GetPath());
		   BgAddExtension(&path, "_segm");
		   
		   //convert the image to wxImage format...
		   wxImage tmpIm(segmImage_->x_, segmImage_->y_);
		   unsigned char* tmpImData;
		   tmpImData = tmpIm.GetData();
		   segmImage_->GetImageColor(tmpImData);
		   
		   //save the image...
		   tmpIm.SaveFile(path, imtype);
		   bgLog("Segmented image saved to:\t'%s'.\n", path);

		   //de-allocate memory
		   delete [] path;
		   
	 
	   
	   //save boundaries
	   OnSaveBoundaries((char*)filedialog.GetPath().c_str(), imtype);
	   
   }
}

//saves edge map
void BgMdiSegmentChild::OnSaveBoundaries(char *filename, int imtype)
{

}

//construct a ph diagram using the boundary pixels
//aquired from image segmentation (also outputs results
//to 'xyrc.txt'
void BgMdiSegmentChild::SetphDiagram(int width, float *confMap, float *rankMap)
{
   
}


void BgMdiSegmentChild::OnSegment(wxCommandEvent& WXUNUSED(event))
{

	//get parameters from GUI
	int error = GetParameters(sigmaS, sigmaR, aij, epsilon, minRegion, kernelSize, 1);
	if(error)
		return;


	viewImSegRadio_->Enable(1, true);
	viewImSegRadio_->SetSelection(0);
	viewImSegRadio_->Enable(2, true);
	viewBoundariesCheck_->Enable(true);

	
	paramComboBox_->SetSelection(0);
	
	return;

}

/*
	��ʱ��ʾ��ǰЧ��

*/
void BgMdiSegmentChild::Segment(void)
{
	int j = 0;
	//while(m_bRunning)
	//{
	//	if(j%2 == 0)
	//	{
	//		displayImage_->ShowNowPic(true);
	//	}
	//	else
	//	{
	//		displayImage_->ShowNowPic(false);
	//	}
	//	
	//	j++;
	//	Sleep(500);
	//}
}

int BgMdiSegmentChild::GetParameters(int &sigmaS, float &sigmaR, float &aij, float &epsilon, int &minRegion, int &kernelSize, int dataEntryCheck)
{

   double	tempd;
   char		str[10];

   //do not perform data entry check
   if(!dataEntryCheck)
   {
	   //sigmaS
	   txtSigmaS_->GetValue().ToDouble(&tempd);
	   sigmaS			= bgRoundSign(tempd);

	   //sigmaR
	   txtSigmaR_->GetValue().ToDouble(&tempd);
	   sigmaR			= (float) tempd;

	   //minRegion
	   txtMinRegion_->GetValue().ToDouble(&tempd);
	   minRegion		= bgRoundSign(tempd);

	   //kernel size
	   txtKernelSize_->GetValue().ToDouble(&tempd);
	   kernelSize		= bgRoundSign(tempd);

	   //aij
	   txtA_->GetValue().ToDouble(&tempd);
	   aij				= (float) tempd;

	   //epsilon
	   txtEpsilon_->GetValue().ToDouble(&tempd);
	   epsilon			= (float) tempd;

	   //done.
	   return 0;
   }
   
   //perform data entry check
   if ((txtSigmaS_->GetValue().ToDouble(&tempd) == true) && (tempd > 0))
   {
	   sigmaS = (int)(tempd + 0.5);
	   sprintf(str, "%d", sigmaS);
	   txtSigmaS_->SetValue(str);
   }
   else
   {
	   bgLog("The value of the spatial bandwidth cannot be zero or negative.\n");
	   return 1;
   }
   if ((txtSigmaR_->GetValue().ToDouble(&tempd) == true) && (tempd > 0))
	   sigmaR = tempd;
   else
   {
	   bgLog("The value of the range bandwidth cannot be zero or negative.\n");
	   return 1;
   }
   if ((txtMinRegion_->GetValue().ToDouble(&tempd) == true) && (tempd >= 0))
   {
	   minRegion = (int)(tempd + 0.5);
	   sprintf(str, "%d", minRegion);
	   txtMinRegion_->SetValue(str);
   }
   else
   {
	   bgLog("The value of minimum region cannot be negative.\n");
	   return 1;
   }
   if ((txtKernelSize_->GetValue().ToDouble(&tempd) == true) && (tempd > 0))
   {
	   kernelSize = (int)(tempd + 0.5);
	   sprintf(str, "%d", kernelSize);
	   txtKernelSize_->SetValue(str);
   }
   else
   {
	   bgLog("The gradient window radius cannot be zero or negative.\n");
	   return 1;
   }
   if ((txtA_->GetValue().ToDouble(&tempd) == true) && (tempd >= 0) && (tempd <= 1))
   {
	   aij = tempd;
	   if(aij < 0.01) txtA_->SetValue("0.0");
   }
   else
   {
	   bgLog("The value of the mixture parameter cannot be negative or greater than one.\n");
	   return 1;
   }
   if ((txtEpsilon_->GetValue().ToDouble(&tempd) == true) && (tempd >= 0) && (tempd <= 1))
   {
	   epsilon = tempd;
	   if(epsilon < 0.01) txtEpsilon_->SetValue("0.0");
   }
   else
   {
	   bgLog("The threshold value cannot be negative or greater than one.\n");
	   return 1;
   }
   return 0;
}