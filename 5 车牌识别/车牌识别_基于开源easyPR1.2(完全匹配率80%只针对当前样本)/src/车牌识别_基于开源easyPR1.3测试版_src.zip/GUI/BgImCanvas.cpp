
#include "BgImCanvas.h"
#include "../segm/msImageProcessor.h"
#include "wx/dc.h"


BgLineSet::BgLineSet()
{
	xs_ = ys_ = xe_ = ye_ = 0;
	lineParam_ = 0;
	n_ = 0;
	pen_.SetColour(*wxRED);
	//pen_.SetColour(*wxWHITE);
	pen_.SetWidth(2);
	pen_.SetStyle(wxSOLID);
}

BgLineSet::~BgLineSet()
{
	CleanData();
}

void BgLineSet::CleanData()
{
	if (n_ > 0)
	{
		delete [] xs_;
		delete [] xe_;
		delete [] ys_;
		delete [] ye_;
		delete [] lineParam_;
		xs_ = ys_ = xe_ = ye_ = 0;
		lineParam_ = 0;
		n_ = 0;
	}
}

void BgLineSet::SetLines(int* xs, int* xe, int* ys, int* ye, double* lineParam, int n)
{
	CleanData();
	n_ = n;
	xs_ = new int[n_];
	xe_ = new int[n_];
	ys_ = new int[n_];
	ye_ = new int[n_];
	lineParam_ = new double[n_*3];
	int i;
	for (i=0; i<n; i++)
	{
		xs_[i] = xs[i];
		ys_[i] = ys[i];
		xe_[i] = xe[i];
		ye_[i] = ye[i];
	}
	for (i=0; i<(3*n); i++)
		lineParam_[i] = lineParam[i];
}

void BgLineSet::SetLines(double* startp, double* endp, double* lineParam, int n)
{
	CleanData();
	n_ = n;
	xs_ = new int[n_];
	xe_ = new int[n_];
	ys_ = new int[n_];
	ye_ = new int[n_];
	lineParam_ = new double[n_*3];
	int i;
	for (i=0; i<n; i++)
	{
		xs_[i] = (int) startp[2*i];
		ys_[i] = (int) startp[2*i+1];
		xe_[i] = (int) endp[2*i];
		ye_[i] = (int) endp[2*i+1];
	}
	for (i=0; i<(3*n); i++)
		lineParam_[i] = lineParam[i];
}


// ---------------------------------------------------------------------------
// BgCurveSet
// ---------------------------------------------------------------------------

BgCurveSet::BgCurveSet()
{
	x_ = y_ = 0;
	xs_ = ys_ = 0;
	n_ = 0;
	type_ = -1;
	pen_.SetColour(*wxBLUE);
	pen_.SetWidth(3);
	pen_.SetStyle(wxSOLID);
	isDragging_ = 0;
}

BgCurveSet::~BgCurveSet()
{
	CleanData();
}

void BgCurveSet::CleanData()
{
	if (n_ > 0)
	{
		delete [] x_;
		delete [] y_;
		x_ = y_ = 0;
		n_ = 0;
	}
	type_ = -1;
	xs_ = ys_ = 0;
}

void BgCurveSet::SetCurve(BgCurveSet* bgc)
{
	CleanData();
	type_ = bgc->type_;
	n_ = bgc->n_;
	x_ = new int[n_];
	y_ = new int[n_];
	xs_ = bgc->xs_;
	ys_ = bgc->ys_;
	for (int i=0; i<n_; i++)
	{
		x_[i] = bgc->x_[i];
		y_[i] = bgc->y_[i];
	}
}

void BgCurveSet::SetParamCurve(int type, double* x, double* y, int n, int xs, int ys)
{
	CleanData();
	type_ = type;
	n_ = n;
	x_ = new int[n_];
	y_ = new int[n_];
	xs_ = xs;
	ys_ = ys;
	for (int i=0; i<n; i++)
	{
		x_[i] = (int) (x[i]*xs);
		y_[i] = (int) (ys-y[i]*ys);
	}
}

void BgCurveSet::GetParamCurve(double* x, double* y, int& type, int& n)
{
	for (int i=0; i<n_; i++)
	{
		x[i] = ((double)x_[i])/xs_;
		y[i] = ((double)(ys_-y_[i]))/ys_;
	}
	type = type_;
	n = n_;
}

void BgCurveSet::DrawYourself(unsigned char* buf, int val)
{
	int j;
	switch (type_)
	{
	case -1:
		break;
	case FC_ELLIPSE:
		DrawEllipticArc(buf, val, -x_[0], y_[0], 2*x_[0], 2*(ys_-y_[0]), 0, 90);
		break;
	case FC_VERT_LINE:
		DrawLine(buf, val, x_[0], 0, x_[0], ys_);
		break;
	case FC_HORIZ_LINE:
		DrawLine(buf, val, 0, y_[0], xs_, y_[0]);
		break;
	case FC_LINE:
		DrawLine(buf, val, 0, y_[0], x_[0], ys_);
		break;
	case FC_SQUARE_BOX:
		DrawLine(buf, val, 0, y_[0], x_[0], y_[0]);
		DrawLine(buf, val, x_[0], y_[0], x_[0], ys_);
		break;
	case FC_CUSTOM:
		// lines
		for (j=0; j<(n_-1); j++)
			DrawLine(buf, val, x_[j], y_[j], x_[j+1], y_[j+1]);
		// control points
		for (j=0; j<n_; j++)
			DrawPoint(buf, val ,x_[j], y_[j]);
		break;
	}

}

void BgCurveSet::DrawPoint(unsigned char* buf, int val, int x, int y)
{
	int r, c;
	int dx, dy;
	for (dx=-2; dx<=2; dx++)
	{
		for (dy=-2; dy<=2; dy++)
		{
			c=x+dx;
			r=y+dy;
			if ((c>=0) && (c<xs_) && (r>=0) && (r<ys_) && ((abs(dx)+abs(dy))<4))
				buf[c+r*ys_] = val;
		}
	}
}

void BgCurveSet::DrawLine(unsigned char* buf, int val, int xs, int ys, int xe, int ye)
{
	int r, c;
	double dsx, dsy, dex, dey;
	if (abs(xs-xe)>abs(ys-ye))
	{
		// x scan
		if (xs > xe)
		{
			dsx = xe;
			dsy = ye;
			dex = xs;
			dey = ys;
		}
		else 
		{
			dex = xe;
			dey = ye;
			dsx = xs;
			dsy = ys;
		}

		for (c = (int) dsx; c<=(int)dex; c++)
		{
			if (c>=0 && c<xs_)
			{
				r = bgRound(dey-(dey-dsy)*(dex-c)/(dex-dsx));
				if (r>=0 && r<ys_)
				{
					buf[c+r*xs_] = val;
					// +/- 1
					if ((r+1)<ys_) buf[c+(r+1)*xs_] = val;
					if ((r-1)>=0) buf[c+(r-1)*xs_] = val;
					// +/- 2
					if ((r+2)<ys_) buf[c+(r+2)*xs_] = val;
					if ((r-2)>=0) buf[c+(r-2)*xs_] = val;
				}
			}
		}
	}
	else
	{
		// y scan
		if (ys > ye)
		{
			dsx = xe;
			dsy = ye;
			dex = xs;
			dey = ys;
		}
		else 
		{
			dex = xe;
			dey = ye;
			dsx = xs;
			dsy = ys;
		}

		// check bounds

		for (r = (int) dsy; r<=(int) dey; r++)
		{
			if (r>=0 && r<ys_)
			{
				c = bgRound(dex-(dex-dsx)*(dey-r)/(dey-dsy));
				if (c>=0 && c<xs_)
				{
					buf[c+r*xs_] = val;
					// +/- 1
					if ((c+1)<xs_) buf[c+1+r*xs_] = val;
					if ((c-1)>=0) buf[c-1+r*xs_] = val;
					// +/- 2
					if ((c+2)<xs_) buf[c+2+r*xs_] = val;
					if ((c-2)>=0) buf[c-2+r*xs_] = val;
				}
			}
		}
	}
}
void BgCurveSet::DrawEllipticArc(unsigned char* buf, int val, int x, int y, int w, int h, int sa, int ea)
{
	double xc, yc, rx, ry;
	rx = w/2;
	ry = h/2;
	xc = x+rx;
	yc = y+ry;
	int r, c;

	//   if (rx > ry)
	//   {
	// x scan
	for (c = (int) xc; c<=(int) (xc+rx); c++)
	{
		if (c>=0 && c<xs_)
		{
			r = bgRound(yc-ry*sqrt(1-(c-xc)*(c-xc)/(rx*rx)));
			if (r>=0 && r<ys_)
			{
				buf[c+r*xs_] = val;
				// +/- 1
				if ((r+1)<ys_) buf[c+(r+1)*xs_] = val;
				if ((r-1)>=0) buf[c+(r-1)*xs_] = val;
				// +/- 2
				if ((r+2)<ys_) buf[c+(r+2)*xs_] = val;
				if ((r-2)>=0) buf[c+(r-2)*xs_] = val;
			}
		}
	}
	//   }
	//   else
	//   {
	// y scan
	for (r = (int)(yc-ry); r<=(int) yc; r++)
	{
		if (r>=0 && r<ys_)
		{
			c = bgRound(xc+rx*sqrt(1-(r-yc)*(r-yc)/(ry*ry)));
			if (c>=0 && c<xs_)
			{
				buf[c+r*xs_] = val;
				// +/- 1
				if ((c+1)<xs_) buf[c+1+r*xs_] = val;
				if ((c-1)>=0) buf[c-1+r*xs_] = val;
				// +/- 2
				if ((c+2)<xs_) buf[c+2+r*xs_] = val;
				if ((c-2)>=0) buf[c-2+r*xs_] = val;
			}
		}
	}
	//   }
}

void BgCurveSet::StartDragging(int x, int y)
{
	isDragging_ = 1;
	int j;
	switch (type_)
	{
	case -1:
		break;
	case FC_ELLIPSE:
		if (abs(x)<3)
			ltodrag_ = 1;
		else if (abs(y-ys_)<3)
			ltodrag_ = 2;
		else
			ltodrag_ = 0;
		break;
	case FC_VERT_LINE:
		ltodrag_ = 0;
		break;
	case FC_HORIZ_LINE:
		ltodrag_ = 0;
		break;
	case FC_LINE:
		if (abs(x)<3)
			ltodrag_ = 1;
		else if (abs(y-ys_)<3)
			ltodrag_ = 2;
		else
			ltodrag_ = 0;
		break;
	case FC_SQUARE_BOX:
		if (abs((abs(x-x_[0])-abs(y-y_[0])))<3)
		{
			// drag corner
			ltodrag_ = 2;
		}
		else if (abs(x-x_[0])>abs(y-y_[0]))
		{
			// drag horizontal
			ltodrag_ = 0;
		}
		else
		{
			// drag vertical
			ltodrag_ = 1;
		}
		break;
	case FC_CUSTOM:
		// find point to drag
		int mind = abs(x-x_[0]) + abs(y-y_[0]);
		int cmind, mj;
		mj = 0;
		for (j=1; j<n_; j++)
		{
			cmind = abs(x-x_[j]) + abs(y-y_[j]);
			if (cmind < mind)
			{
				mind = cmind;
				mj = j;
			}
		}
		ltodrag_ = mj;
		break;
	}
}

void BgCurveSet::DragTo(int x, int y)
{
	if ((x<0) || (y<0) || (x>=xs_) || (y>=ys_))
		return;
	double k, ry;
	switch (type_)
	{
	case -1:
		break;
	case FC_ELLIPSE:
		// modify ellipse to drag
		if (ltodrag_ == 0)
		{
			k = ((double)x_[0])/(ys_-y_[0]);
			ry = sqrt(((double)x*x)/(k*k)+(y-ys_)*(y-ys_));
			x_[0] = bgRound(k*ry);
			y_[0] = bgRound(ys_-ry);
		}
		else if (ltodrag_ == 1)
		{
			y_[0] = y;
		}
		else
		{
			x_[0] = x;
		}
		break;
	case FC_VERT_LINE:
		x_[0] = x;
		break;
	case FC_HORIZ_LINE:
		y_[0] = y;
		break;
	case FC_LINE:
		// modify line to drag
		if (ltodrag_ == 0)
		{
			k = ((double) (ys_-y_[0])/x_[0]);
			y_[0] = ys_-bgRound((double (ys_-y)+k*x));
			x_[0] = bgRound((double (ys_-y)+k*x)/(k));
		}
		else if (ltodrag_ == 1)
		{
			y_[0] = y;
		}
		else
		{
			x_[0] = x;
		}
		break;
	case FC_SQUARE_BOX:
		if (ltodrag_ == 0)
			y_[0] = y;
		else if (ltodrag_ == 1)
			x_[0] = x;
		else
		{
			x_[0] = x;
			y_[0] = y;
		}
		break;
	case FC_CUSTOM:
		// modify line to drag
		if (ltodrag_ == 0)
		{
			y_[0] = y;
		} else if (ltodrag_ == (n_-1))
		{
			x_[n_-1] = x;
		} else
		{
			x_[ltodrag_] = x;
			y_[ltodrag_] = y;
		}
		break;
	}
}

void BgCurveSet::EndDragging(int x, int y)
{
	isDragging_ = 0;
}


// ---------------------------------------------------------------------------
// BgText
// ---------------------------------------------------------------------------

//default constructor
BgText::BgText(void)
{
	text_	= (char *)	NULL;
	font_	= (wxFont *)	NULL;
	id_		= 0;
	x_		= 0;
	y_		= 0;
}

//overloaded constructor
BgText::BgText(int id, char *text, wxFont font, int x, int y)
{
	text_		= new char [strlen(text) + 1];
	strcpy(text_, text);
	font_		= new wxFont;
	(*font_)	= font;
	id_			= id;
	x_			= x;
	y_			= y;
}

//destructor
BgText::~BgText(void)
{
	delete text_;
	delete font_;
}

//sets text string
//pre : text is a character string used to set the text
//      field of the text object
//post: the text field of the text object has been set to text
void BgText::SetText(char *text)
{
	if((text_)&&(strlen(text) > strlen(text_)))
	{
		delete [] text_;
		text_	= new char [strlen(text) + 1];
	}
	strcpy(text_, text);
	return;
}

//sets font of text
//pre : font specifies the new font of the text object
//post: the font of the text object has been changed to font
void BgText::SetFont(wxFont font)
{
	if(!font_)	font_	= new wxFont;
	(*font_)	= font;
	return;
}

//sets id of text
//pre : id is the new id of the text object
//post: the id of the text object has been set to id
void BgText::SetId(int id)
{
	id_	= id;
}

//sets plot location of text
//pre : (x,y) determine the new plot location of the text object
//post: the plot location of the text object has been set to (x,y)
void BgText::SetPlotLocation(int x, int y)
{
	x_	= x;
	y_	= y;
}

// ---------------------------------------------------------------------------
// BgTextObj
// ---------------------------------------------------------------------------

//constructor
BgTextObj::BgTextObj(BgText *text)
{
	text_	= new BgText(text->id_, text->text_, *(text->font_), text->x_, text->y_);
	next_	= NULL;
}

//destructor
BgTextObj::~BgTextObj(void)
{
	delete text_;
}

// ---------------------------------------------------------------------------
// BgTextList
// ---------------------------------------------------------------------------

// *** public methods *** //

//constructor
BgTextList::BgTextList(void)
{
	head_		= cur_	= (BgTextObj *) NULL;
	itemcount_	= 0;
}

//destructor
BgTextList::~BgTextList(void)
{
	cur_ = head_;
	while(cur_)
		DeleteText();
}

//adds text object to list
//pre : text is a text object to be added to the list
//post: text has been added to the list
int BgTextList::AddText(BgText *text)
{
	//search for existsing text object
	int id	= text->id_;
	cur_	= head_;
	while((cur_)&&(cur_->text_->id_ != id))
		cur_ = cur_->next_;

	//if it exists change its contents
	if(cur_)
	{
		BgText *tmp_text	= cur_->text_;
		tmp_text->SetText(text->text_);
		tmp_text->SetFont(*(text->font_));
		tmp_text->SetPlotLocation(text->x_, text->y_);
	}
	//otherwise add it to existing list
	else
	{
		BgTextObj	*temp;
		if((temp = new BgTextObj(text)) == NULL)
			return 1;

		temp->next_	= head_;
		if(head_ == NULL)
			cur_	= temp;
		head_		= temp;
		itemcount_++;
	}

	return 0;
}		

//removes text object from list
//pre : textId is the id of the text to be removed from the
//      list
//post: text object having id textId has been removed from the
//      list if it exists (1 is returned upon error)
int BgTextList::RemoveText(int textId)
{
	cur_ = head_;
	while((cur_)&&(cur_->text_->id_ != textId))
		cur_	= cur_->next_;

	if(cur_)
	{
		DeleteText();
		return 0;
	}
	else
		return 1;
}

//returns text object from text list
//post: the text object pointed to by cur_ is returned
BgText	*BgTextList::GetText(void)
{
	if(cur_)
	{
		BgText	*text;
		text	= cur_->text_;
		cur_	= cur_->next_;
		return text;
	}
	else
		return (BgText *) NULL;
}

//resets cur_ pointer to head of the list
void BgTextList::ResetList(void)
{
	cur_	= head_;
}

//returns the number of text objects contained
//within the list
//post: count of text objects contained by list is returned
int	BgTextList::GetTextCount(void)
{
	return itemcount_;
}

// *** private methods ***

//deletes a text object node pointed to
//by cur_
//post: text object has been deleted from the text list
void BgTextList::DeleteText(void)
{
	if(cur_ == head_)
	{
		head_	= head_->next_;
		delete cur_;
		cur_		= head_;
	}
	else
	{
		BgTextObj	*temp = cur_;
		cur_	= cur_->next_;
		if(!cur_)	cur_	= head_;
		delete temp;
	}
}

// ---------------------------------------------------------------------------
// BgBitmap
// ---------------------------------------------------------------------------

//default constructor
BgBitmap::BgBitmap(void)
{
	bitmap_		= (wxBitmap *) NULL;
	location_x_	= location_y_	= 0;
	id_			= 0;
}

//overloaded constructor
BgBitmap::BgBitmap(wxBitmap *bitmap, int id, int location_x, int location_y)
{
	bitmap_		= new wxBitmap;
	(*bitmap_)	= (*bitmap);
	id_			= id;
	location_x_	= location_x;
	location_y_	= location_y;
}

//destructor
BgBitmap::~BgBitmap(void)
{
	if(bitmap_)	delete bitmap_;
}

//set bitmap content
//pre : bitmap is the new bitmap content
//post: bitmap content has been changed to that of bitmap
void BgBitmap::SetMap(wxBitmap *bitmap)
{
	if(!bitmap_)	bitmap_	= new wxBitmap;
	(*bitmap_)	= (*bitmap);
}

//set plot location
//pre : (location_x, location_y) define new plot location of bitmap
//post: plot location of bitmap has been set to (location_x, location_y)
void BgBitmap::SetPlotLocation(int location_x, int location_y)
{
	location_x_	= location_x;
	location_y_	= location_y;
}

//set bitmap id
//pre : id is the new bitmap id
//post: the bitmap id has been set to id
void BgBitmap::SetId(int id)
{
	id_	= id;
}

// ---------------------------------------------------------------------------
// BgBitmapObj
// ---------------------------------------------------------------------------

//default constructor
BgBitmapObj::BgBitmapObj(void)
{
	bitmap_	= (BgBitmap *) NULL;
	next_	= (BgBitmapObj *) NULL;
}

//overloaded constructor
BgBitmapObj::BgBitmapObj(BgBitmap* bitmap)
{
	bitmap_	= new BgBitmap(bitmap->bitmap_, bitmap->id_,
		bitmap->location_x_, bitmap->location_y_);
	next_	= (BgBitmapObj *) NULL;
}

//destructor
BgBitmapObj::~BgBitmapObj(void)
{
	if(bitmap_)	delete bitmap_;
}

// ---------------------------------------------------------------------------
// BgBitmap
// ---------------------------------------------------------------------------

//constructor
BgBitmapList::BgBitmapList(void)
{
	head_		= cur_	= (BgBitmapObj *) NULL;
	itemcount_	= 0;
}

//destuctor
BgBitmapList::~BgBitmapList(void)
{
	cur_ = head_;
	while(cur_)
		DeleteBitmap();
}

//add a bitmap object to the list
//pre : bitmap is a bitmap object to be added to the list
//post: bitmap has been added to the list
int BgBitmapList::AddBitmap(BgBitmap *bitmap)
{
	BgBitmapObj	*temp;
	if((temp = new BgBitmapObj(bitmap)) == NULL)
		return 1;

	temp->next_	= head_;
	if(head_ == NULL)
		cur_	= temp;
	head_		= temp;
	itemcount_++;

	return 0;
}		

//remove bitmap from list
//pre : bitmap is to be removed from list
//post: bitmap has been removed from the list
void BgBitmapList::RemoveBitmap(BgBitmap *bitmap)
{
	int	id	= bitmap->id_;
	cur_	= head_;
	while((cur_)&&(cur_->bitmap_->id_ != id))
		cur_	= cur_->next_;
	DeleteBitmap();
}

//get bitmap from the list pointed to by cur_
//post: bitmap pointed to by cur_ has been returned
//      and cur_ has been incremented to the next list
//      item
BgBitmap *BgBitmapList::GetBitmap(void)
{
	BgBitmap	*temp	= (BgBitmap *)	NULL;
	if(cur_)
	{
		temp	= cur_->bitmap_;
		cur_	= cur_->next_;
	}

	return temp;
}

//reset bitmap list cur_ pointer
//post: cur_ has been set to the head of the list
void BgBitmapList::ResetList(void)
{
	cur_	= head_;
}

//get the number of bitmaps stored by list
//post: bitmap count has been returned
int BgBitmapList::GetBitmapCount(void)
{
	return itemcount_;
}

//delete bitmap object from list
//post: bitmap object pointed to by cur has been deleted
void BgBitmapList::DeleteBitmap(void)
{
	if(cur_)
	{
		BgBitmapObj	*temp	= cur_;
		cur_				= cur_->next_;
		delete temp;
		itemcount_--;
	}
}

// ---------------------------------------------------------------------------
// BgAxis
// ---------------------------------------------------------------------------

//default constructor
BgAxis::BgAxis(void)
{
	start_x_	= 0; start_y_	= 0;
	length_		= 0;
	ticknum_	= 0;
	direction_	= 0;
	start_val_	= 0; stop_val_	= 0;
	label_		= (BgText *) NULL;
	rotation_	= 0;
}

//overloaded constructor
BgAxis::BgAxis(int start_x, int start_y, int length, int ticknum, int direction, float start_val, float stop_val)
{
	start_x_	= start_x;
	start_y_	= start_y;
	length_		= length;
	ticknum_	= ticknum;
	direction_	= direction;
	start_val_	= start_val;
	stop_val_	= stop_val;
	label_		= (BgText *) NULL;
	rotation_	= 0;
}

//destuctor
BgAxis::~BgAxis(void)
{
	if(label_)	delete label_;
}

//set plotting origin
//pre : (start_x, start_y) specify the new axis plotting origin
//post: axis plotting origin has been set to (start_x, start_y)
void BgAxis::SetPlotOrigin(int start_x, int start_y)
{
	start_x_	= start_x;
	start_y_	= start_y;
}

//set axis length
//pre : length specifies the new length of the axis
//post: the axis lengh has been set to length
void BgAxis::SetLength(int length)
{
	length_		= length;
}

//set axis tick number
//pre : ticknum is the new tick number of the axis
//post: the axis tick number has been set to ticknum
void BgAxis::SetTicknum(int ticknum)
{
	ticknum_	= ticknum;
}

//set axis boundaries
//pre : (start_val, stop_val) define the new axis boundaries
//post: the axis boundaries have been set to (start_val, stop_val)
void BgAxis::SetBounds(float start_val, float stop_val)
{
	start_val_	= start_val;
	stop_val_	= stop_val;
}

//add axis label
//pre : label specifies the axis label
//post: the axis has been labeled using label
void BgAxis::Label(BgText *label)
{
	if(label_)	delete label_;
	char *text	= label->text_;
	int label_length	= 3*strlen(text);
	//horizontal axis
	if(direction_ == 0)
	{
		label_x_	= start_x_ + length_/2 - label_length;
		label_y_	= start_y_ + 30;
	}
	//vertical axis
	else
	{
		label_x_	= start_x_ - 60;
		label_y_	= start_y_ - length_/2 + label_length;
	}
	label_	= new BgText(label->id_, text, *(label->font_), label_x_, label_y_);
}

//removes axis label
//post: the axis label has been removed
void BgAxis::RemoveLabel(void)
{
	if(label_)	delete label_;
	label_	= (BgText *) NULL;
}

//sets label rotation
//pre : rotation specifies clockwise label rotation (rotation = 0
//      leaves the label parallel to the axis)
//post: label rotation has been set to rotation
void BgAxis::SetLabelRotation(int rotation)
{
	rotation_	= rotation;
}

//draw axis object
//pre : dc is a dc object used to draw onto a window
//post: the axis has been drawn onto the window using
//      using the dc object
void BgAxis::PlotAxis(wxDC *dc)
{
	//set tick length
	int	ticklength = 8;

	//calculate axis ending locations
	int	end_x	= start_x_ + length_;
	int	end_y	= start_y_ - length_;

	//define shift in x and y direction
	int	shift_x	= 5;
	int	shift_y	= 5;

	//create font
	wxFont plotFont(7, wxSWISS, wxNORMAL, wxNORMAL, false, "", wxFONTENCODING_DEFAULT);

	//plot axis line
	//horizontal axis
	if(direction_ == 0)
	{
		//draw axis line
		dc->DrawLine(start_x_, start_y_, end_x, start_y_);
		dc->DrawLine(start_x_, start_y_+1, end_x, start_y_+1);

		//draw tick marks
		int	increment	= length_/ticknum_;
		if(length_%ticknum_ != 0)	increment++;
		int	x_location	= start_x_;
		while(x_location < end_x)
		{
			dc->DrawLine(x_location, start_y_, x_location, start_y_+ticklength);
			dc->DrawLine(x_location+1, start_y_, x_location+1, start_y_+ticklength);
			x_location	= x_location + increment;
		}
		dc->DrawLine(end_x-1, start_y_, end_x-1, start_y_+ticklength);
		dc->DrawLine(end_x, start_y_, end_x, start_y_+ticklength);

		//draw floating point axis markers
		x_location	= start_x_ - shift_x;
		float	marker_x			= start_val_;
		float	marker_increment	= (stop_val_ - start_val_)/ticknum_;
		char	marker_str[8];
		int i	= 0, fixed_y	= start_y_ + 10;
		char	align[6];
		if(stop_val_ < 10)
			strcpy(align, "%4.2f");
		else
		{
			strcpy(align, "%4.0f");
			x_location	= x_location - shift_x;
			shift_x		= 2*shift_x;
		}
		dc->SetFont(plotFont);
		for(i = 0; i < ticknum_; i++)
		{
			sprintf(marker_str, align, marker_x);
//			dc->DrawText(marker_str, x_location, fixed_y);
			marker_x	+= marker_increment;
			x_location	+= increment;
		}
		sprintf(marker_str, align, marker_x);
//		dc->DrawText(marker_str, end_x - shift_x, fixed_y);

		//add label
		if(label_)
		{
			dc->SetFont(*(label_->font_));
			dc->DrawRotatedText(label_->text_, label_x_, label_y_, 0+rotation_);
		}
	}
	//vertical axis
	else
	{
		//draw axis line
		dc->DrawLine(start_x_, start_y_, start_x_, end_y);
		dc->DrawLine(start_x_-1, start_y_, start_x_-1, end_y);

		//draw tick marks
		int	increment	= length_/ticknum_;
		if(length_%ticknum_ != 0)	increment++;
		int	y_location	= end_y;
		while(y_location < start_y_)
		{
			dc->DrawLine(start_x_, y_location, start_x_-ticklength, y_location);
			dc->DrawLine(start_x_, y_location+1, start_x_-ticklength, y_location+1);
			y_location	= y_location + increment;
		}
		dc->DrawLine(start_x_, start_y_, start_x_-ticklength, start_y_);
		dc->DrawLine(start_x_, start_y_+1, start_x_-ticklength, start_y_+1);

		//draw floating point axis markers
		y_location	= start_y_;
		float	marker_y			= start_val_;
		float	marker_increment	= (stop_val_ - start_val_)/ticknum_;
		char	marker_str[8];
		int i	= 0, fixed_x = start_x_ - 30;
		char	align[6];
		if(stop_val_ < 10)
			strcpy(align, "%4.2f");
		else
			strcpy(align, "%4.0f");
		dc->SetFont(plotFont);
		sprintf(marker_str, align, marker_y);
//		dc->DrawText(marker_str, fixed_x, y_location - shift_y);
		marker_y	+= marker_increment;
		y_location	-= increment;
		for(i = 1; i < ticknum_; i++)
		{
			sprintf(marker_str, align, marker_y);
//			dc->DrawText(marker_str, fixed_x, y_location);
			marker_y	+= marker_increment;
			y_location	-= increment;
		}
		sprintf(marker_str, align, marker_y);
		//dc->DrawText(marker_str, fixed_x, end_y - shift_y);

		//add label
		if(label_)
		{
			dc->SetFont(*(label_->font_));
			dc->DrawRotatedText(label_->text_, label_x_, label_y_, 90+rotation_);
		}
	}
}

// ----------------------------------------------------------------------------
// wxLogTextCtrl implementation
// ----------------------------------------------------------------------------

bgLogTextCtrl::bgLogTextCtrl(wxTextCtrl *pTextCtrl)
{
	m_pTextCtrl = pTextCtrl;
}

void bgLogTextCtrl::DoLogString(const wxChar *szString, time_t WXUNUSED(t))
{
	wxString msg;
	TimeStamp(&msg);
	msg << szString;

	m_pTextCtrl->AppendText(msg);
}


BEGIN_EVENT_TABLE(BgImCanvas, wxScrolledWindow)
EVT_RIGHT_DOWN(BgImCanvas::OnMouseRightDown)
EVT_MOUSE_EVENTS(BgImCanvas::OnEvent)

EVT_MENU(BG_IMC_ADDNODE, BgImCanvas::OnCustomAddNode)
EVT_MENU(BG_IMC_DELETENODE, BgImCanvas::OnCustomDeleteNode)
EVT_MENU(BG_IMC_SELTYPE_ELLIPSE, BgImCanvas::OnCTypeEllipse)
EVT_MENU(BG_IMC_SELTYPE_VLINE, BgImCanvas::OnCTypeVLine)
EVT_MENU(BG_IMC_SELTYPE_HLINE, BgImCanvas::OnCTypeHLine)
EVT_MENU(BG_IMC_SELTYPE_LINE, BgImCanvas::OnCTypeLine)
EVT_MENU(BG_IMC_SELTYPE_BOX, BgImCanvas::OnCTypeBox)
EVT_MENU(BG_IMC_SELTYPE_CUSTOM, BgImCanvas::OnCTypeCustom)

//EVT_SCROLLWIN(BgImCanvas::OnScroll)

END_EVENT_TABLE()


// ---------------------------------------------------------------------------
// BgImCanvas
// ---------------------------------------------------------------------------

// Define a constructor for my canvas
BgImCanvas::BgImCanvas(wxWindow *child_frame, wxWindow *parent, const wxPoint& pos, const wxSize& size)
: wxScrolledWindow(parent, -1, pos, size,
                   wxSIMPLE_BORDER|wxVSCROLL|wxHSCROLL)
{
   SetBackgroundColour(wxColour("WHITE"));
   pbitmap=(wxBitmap*) NULL;
   pimage=(wxImage*) NULL;
   hasbitmap=false;
   showbitmap_ = true;
   m_dirty = false;
   nLineSets_ = nPointSets_ = 0;

   //set pointer to child frame (e.g. used to update window title)
   child_frame_	= child_frame;
   bLeftdown = false;

   // clickable curve stuff
   nCurveSets_ = 0;
   ccx_ = RANK_CONF_IMSIZEX;
   ccy_ = RANK_CONF_IMSIZEY;
   curveClick_ = new unsigned char[ccx_*ccy_];
   isDragging_ = 0;
   FillCurveClick();
   mouseModif_ = 0;
   crossCursor_ = 0;
   showtrack_ = 0;

   //initialize window events
   has_focus		= false;
   leaving			= false;

   //initialize plotting canvas
   x_offset_		= 0;
   y_offset_		= 0;
   textObjectCount_	= 0;
   xAxis			= (BgAxis *) NULL;
   yAxis			= (BgAxis *) NULL;
   clear_display_	= false;

   //initializing zooming parameters
   zoom_in			= false;
   zoom_out			= false;
   zoom_window		= false;
   zoom_level		= 1;

   //initialize empty zoom box and refresh box
   zoombox			= (wxImage  *) NULL;
   refresh_box		= (wxImage  *) NULL;

   point_colour		= (wxColour *) NULL;

   //initialize zoomed image buffer
   zImg				= NULL;

   //initialize zoom window corner
   cx				= 0;
   cy				= 0;

   //initialize mouse pointer location
   m_x_	= 0;
   m_y_	= 0;

   //initialize zoom buffers
   buf	= (unsigned char *) NULL;

   //initialize hover window such that
   //it does not popup
   popup	= 0;

   //initialize hover window
   menuWindow	= (wxWindow *) NULL;

   //pay attention to updates
   noUpdate_	= false;

   //construct zoom cursors
   //??????????????????????????????
   wxString str;
   str.Printf(wxT("icon10"));
   bgCURSOR_MAGNIFIER_PLUS	= new wxCursor(str, wxBITMAP_TYPE_CUR_RESOURCE);
   //bgCURSOR_MAGNIFIER_PLUS	= new wxCursor("icon10", wxBITMAP_TYPE_RESOURCE, 0, 0);
   str.Printf(wxT("icon11"));
   bgCURSOR_MAGNIFIER_MINUS	= new wxCursor(str, wxBITMAP_TYPE_CUR_RESOURCE);
   //bgCURSOR_MAGNIFIER_MINUS	= new wxCursor("icon11", wxBITMAP_TYPE_RESOURCE, 0, 0);

   //build local menu
   localMenu_ = new wxMenu();
   localMenu_->Append(BG_IMC_ADDNODE,"Add node");
   localMenu_->Append(BG_IMC_DELETENODE,"Delete node");
   localMenu_->AppendSeparator();
   localMenu_->Append(BG_IMC_SELTYPE_ELLIPSE,"Arc");
   localMenu_->Append(BG_IMC_SELTYPE_VLINE,"Vertical line");
   localMenu_->Append(BG_IMC_SELTYPE_HLINE,"Horizontal line");
   localMenu_->Append(BG_IMC_SELTYPE_LINE,"Line");
   localMenu_->Append(BG_IMC_SELTYPE_BOX,"Box");
   localMenu_->Append(BG_IMC_SELTYPE_CUSTOM,"Custom");
   mdata = NULL;

}

BgImCanvas::~BgImCanvas()
{
   ClearData();
   if(xAxis)	delete xAxis;
   if(yAxis)	delete yAxis;
   delete [] curveClick_;
   delete localMenu_;
   delete bgCURSOR_MAGNIFIER_PLUS;
   delete bgCURSOR_MAGNIFIER_MINUS;
}

void BgImCanvas::OnCustomAddNode(wxCommandEvent& WXUNUSED(event))
{
   if ((lmEventCurve_ < 0) || (lmEventCurve_ >= nCurveSets_) ||
      (curveSet_[lmEventCurve_]->type_!=FC_CUSTOM))
   {
      return;
   }
   int n, type;
   n = curveSet_[lmEventCurve_]->n_;
   double *tx, *ty;
   tx = new double[n+1];
   ty = new double[n+1];
   curveSet_[lmEventCurve_]->GetParamCurve(tx, ty, type, n);
   double x, y;
   x = ((double) lmEventX_)/ccx_;
   y = (ccy_ - ((double) lmEventY_))/ccy_;

   // determine closest line
   double cx, cy, cr, ax, ay, dx, dy;
   double mny = 10;
   int ci = -1;
   int i;
   for (i=0; i<(n-1); i++)
   {
      cx = tx[i+1]-tx[i];
      cy = ty[i+1]-ty[i];
      cr = sqrt(cx*cx+cy*cy);
      if (cr <= 0)
         continue;
      ax = x-tx[i];
      ay = y-ty[i];
      dx = (cx*ax+cy*ay)/cr;
      dy = fabs((-cy*ax+cx*ay)/cr);
      if ((dx>=0) && (dx<=cr))
      {
         if (dy<mny)
         {
            mny = dy;
            ci = i;
         }
      }
   }
   if (ci >= 0)
   {
      // modify curve
      for (i=n; i>ci; i--)
      {
         tx[i] = tx[i-1];
         ty[i] = ty[i-1];
      }
      tx[ci+1] = x;
      ty[ci+1] = y;
      curveSet_[lmEventCurve_]->SetParamCurve(type, tx, ty, n+1, ccx_, ccy_);
   }
      
   delete [] ty;
   delete [] tx;
   mouseModif_ = 1;
   AddPendingEvent(wxCommandEvent(BG_EVENT_UPDATE, BG_EVENT_UPDATE_ID));

   FillCurveClick();
   return;
}
void BgImCanvas::OnCustomDeleteNode(wxCommandEvent& WXUNUSED(event))
{
   if ((lmEventCurve_ < 0) || (lmEventCurve_ >= nCurveSets_) || 
      (lmEventNode_ < 0) || (lmEventNode_ >= (curveSet_[lmEventCurve_]->n_-1)))
   {
      return;
   }
   if (lmEventNode_ == 0)
   {
      bgLog("Cannot delete first node.\n");
      return;
   }
   if (lmEventNode_ == (curveSet_[lmEventCurve_]->n_-1))
   {
      bgLog("Cannot delete last node.\n");
      return;
   }
   // delete the node
   int i;
   int n = curveSet_[lmEventCurve_]->n_;
   int *tx, *ty;
   tx = curveSet_[lmEventCurve_]->x_;
   ty = curveSet_[lmEventCurve_]->y_;
   for (i=lmEventNode_; i<(n-1); i++)
   {
      tx[i] = tx[i+1];
      ty[i] = ty[i+1];
   }
   curveSet_[lmEventCurve_]->n_ = n-1;
   mouseModif_ = 1;
   AddPendingEvent(wxCommandEvent(BG_EVENT_UPDATE, BG_EVENT_UPDATE_ID));
   FillCurveClick();
   return;
}
void BgImCanvas::OnCTypeEllipse(wxCommandEvent& WXUNUSED(event))
{
   if (lmEventCurve_ < nCurveSets_)
   {
      if (curveSet_[lmEventCurve_]->type_ == FC_CUSTOM)
      {
         curveSet_[lmEventCurve_]->x_[0] = curveSet_[lmEventCurve_]->x_[curveSet_[lmEventCurve_]->n_-1];
         curveSet_[lmEventCurve_]->n_ = 1;
      }
      curveSet_[lmEventCurve_]->type_ = FC_ELLIPSE;
      FillCurveClick();
      mouseModif_ = 1;
      AddPendingEvent(wxCommandEvent(BG_EVENT_UPDATE, BG_EVENT_UPDATE_ID));
   }
}
void BgImCanvas::OnCTypeVLine(wxCommandEvent& WXUNUSED(event))
{
   if (lmEventCurve_ < nCurveSets_)
   {
      if (curveSet_[lmEventCurve_]->type_ == FC_CUSTOM)
      {
         curveSet_[lmEventCurve_]->x_[0] = curveSet_[lmEventCurve_]->x_[curveSet_[lmEventCurve_]->n_-1];
         curveSet_[lmEventCurve_]->n_ = 1;
      }
      curveSet_[lmEventCurve_]->type_ = FC_VERT_LINE;
      FillCurveClick();
      mouseModif_ = 1;
      AddPendingEvent(wxCommandEvent(BG_EVENT_UPDATE, BG_EVENT_UPDATE_ID));
   }
}
void BgImCanvas::OnCTypeHLine(wxCommandEvent& WXUNUSED(event))
{
   if (lmEventCurve_ < nCurveSets_)
   {
      if (curveSet_[lmEventCurve_]->type_ == FC_CUSTOM)
      {
         curveSet_[lmEventCurve_]->x_[0] = curveSet_[lmEventCurve_]->x_[curveSet_[lmEventCurve_]->n_-1];
         curveSet_[lmEventCurve_]->n_ = 1;
      }
      curveSet_[lmEventCurve_]->type_ = FC_HORIZ_LINE;
      mouseModif_ = 1;
      AddPendingEvent(wxCommandEvent(BG_EVENT_UPDATE, BG_EVENT_UPDATE_ID));
      FillCurveClick();
   }
}
void BgImCanvas::OnCTypeLine(wxCommandEvent& WXUNUSED(event))
{
   if (lmEventCurve_ < nCurveSets_)
   {
      if (curveSet_[lmEventCurve_]->type_ == FC_CUSTOM)
      {
         curveSet_[lmEventCurve_]->x_[0] = curveSet_[lmEventCurve_]->x_[curveSet_[lmEventCurve_]->n_-1];
         curveSet_[lmEventCurve_]->n_ = 1;
      }
      curveSet_[lmEventCurve_]->type_ = FC_LINE;
      mouseModif_ = 1;
      AddPendingEvent(wxCommandEvent(BG_EVENT_UPDATE, BG_EVENT_UPDATE_ID));
      FillCurveClick();
   }
}
void BgImCanvas::OnCTypeBox(wxCommandEvent& WXUNUSED(event))
{
   if (lmEventCurve_ < nCurveSets_)
   {
      if (curveSet_[lmEventCurve_]->type_ == FC_CUSTOM)
      {
         curveSet_[lmEventCurve_]->x_[0] = curveSet_[lmEventCurve_]->x_[curveSet_[lmEventCurve_]->n_-1];
         curveSet_[lmEventCurve_]->n_ = 1;
      }
      curveSet_[lmEventCurve_]->type_ = FC_SQUARE_BOX;
      mouseModif_ = 1;
      AddPendingEvent(wxCommandEvent(BG_EVENT_UPDATE, BG_EVENT_UPDATE_ID));
      FillCurveClick();
   }
}
void BgImCanvas::OnCTypeCustom(wxCommandEvent& WXUNUSED(event))
{
   if (lmEventCurve_ < nCurveSets_)
   {
      if (curveSet_[lmEventCurve_]->type_ != FC_CUSTOM)
      {
         double x[3];
         double y[3];
         int n,type;
         curveSet_[lmEventCurve_]->GetParamCurve(x,y,type,n);
         n = 3;
         type = FC_CUSTOM;
         x[2] = x[0];
         x[0] = 0;
         y[2] = 0;
         x[2] = (x[2]>1) ? 1:x[2];
         x[2] = (x[2]<0) ? 0:x[2];
         y[0] = (y[0]>1) ? 1:y[0];
         y[0] = (y[0]<0) ? 0:y[0];
         x[1] = (x[0]+x[2])*2.0/3.0;
         y[1] = (y[0]+y[2])*2.0/3.0;
         curveSet_[lmEventCurve_]->SetParamCurve(type, x, y, n, ccx_, ccy_);
      }
      curveSet_[lmEventCurve_]->type_ = FC_CUSTOM;
      mouseModif_ = 1;
      AddPendingEvent(wxCommandEvent(BG_EVENT_UPDATE, BG_EVENT_UPDATE_ID));
      FillCurveClick();
   }
}






void BgImCanvas::AddLineSet(BgLineSet* ls)
{
   lineSet_[nLineSets_++] = ls;
   Refresh();
}

void BgImCanvas::AddTrackSet(int x, int y, int hx, int hy)
{
   trackval_[0] = x;
   trackval_[1] = y;
   hx_ = hx;
   hy_ = hy;
   showtrack_ = 1;
   Refresh();

}

void BgImCanvas::RemoveTrackSet()
{
   showtrack_ = 0;
   Refresh();
}
   

void BgImCanvas::RemoveLineSet(BgLineSet* ls)
{
   int i = 0;
   while (i<nLineSets_ && lineSet_[i]!=ls)
      i++;
   if (i<nLineSets_)
   {
      i++;
      while(i<nLineSets_)
      {
         lineSet_[i-1] = lineSet_[i];
         i++;
      }
      nLineSets_--;
   }
   Refresh();
}

void BgImCanvas::AddCurveSet(BgCurveSet* cs)
{
   curveSet_[nCurveSets_++] = cs;
   Refresh();
}

void BgImCanvas::RemoveCurveSet(BgCurveSet* cs)
{
   int i = 0;
   while (i<nCurveSets_ && curveSet_[i]!=cs)
      i++;
   if (i<nCurveSets_)
   {
      i++;
      while(i<nCurveSets_)
      {
         curveSet_[i-1] = curveSet_[i];
         i++;
      }
      nCurveSets_--;
   }
   Refresh();
}

//adds text object to be dran to the image
//pre : bgText is the text object to be plotted
//post: bgText has been added to the image
void BgImCanvas::AddText(BgText *bgText)
{
	//add text to text list
	if(tlist_.AddText(bgText))
	{
		bgLog("BgImCanvas::AddText Error: Out of memory.\n");
		return;
	}

	//obtain new text object count
	textObjectCount_	= tlist_.GetTextCount();
}

//clears all text object from text list
void BgImCanvas::RemoveText(int text_id)
{
	tlist_.RemoveText(text_id);
	return;
}

//adds horizontal axis
void BgImCanvas::AddHorizontalAxis(int start_x, int start_y, int length, int ticknum, float start_val, float stop_val)
{
	if(xAxis)	delete xAxis;
	xAxis	= new BgAxis(start_x, start_y, length, ticknum, 0, start_val, stop_val);
}

//adds horizontal axis
void BgImCanvas::AddVerticalAxis(int start_x, int start_y, int length, int ticknum, float start_val, float stop_val)
{
	if(yAxis)	delete yAxis;
	yAxis	= new BgAxis(start_x, start_y, length, ticknum, 1, start_val, stop_val);
}

//clears axis
void BgImCanvas::ClearAxis( void )
{
	if(xAxis)	delete xAxis;
	if(yAxis)	delete yAxis;
	xAxis	= yAxis	= (BgAxis *) NULL;
}

//labels horizontal axis
void BgImCanvas::LabelHorizontalAxis(BgText *bgText)
{
	if(xAxis)	xAxis->Label(bgText);
}

//labels vertical axis
void BgImCanvas::LabelVerticalAxis(BgText *bgText)
{
	if(yAxis)	yAxis->Label(bgText);
}

//removes label on horizontal axis
void BgImCanvas::RemoveHorizontalAxisLabel(void)
{
	if(xAxis)	xAxis->RemoveLabel();
}

//removes lable on vertical axis
void BgImCanvas::RemoveVerticalAxisLabel(void)
{
	if(yAxis)	yAxis->RemoveLabel();
}

//rotates horizontal axis label clockwise from default position
void BgImCanvas::RotateHorizontalAxisLabel(int rotation)
{
	if(xAxis)	xAxis->SetLabelRotation(rotation);
}

//rotates vertical axis label clockwise from default position
void BgImCanvas::RotateVerticalAxisLabel(int rotation)
{
	if(yAxis)	yAxis->SetLabelRotation(rotation);
}

//plot bitmap at specified location
void BgImCanvas::AddBitmap(BgBitmap *bitmap)
{
	blist_.AddBitmap(bitmap);
}

//remove bitmap from plot
void BgImCanvas::RemoveBitmap(BgBitmap *bitmap)
{
	blist_.RemoveBitmap(bitmap);
}

//clears display
void BgImCanvas::ClearDisplay(void)
{
	clear_display_	= true;
	Refresh();
}

void BgImCanvas::ClearData(int refresh)
{
   if(hasbitmap==true) {
      delete pbitmap;
      delete pimage;
   }
   if(zoombox)			delete zoombox;
   if(refresh_box)		delete refresh_box;
   if(zImg)				delete zImg;
   if(buf)				delete [] buf;
   hasbitmap=false;
   pbitmap=(wxBitmap*) NULL;
   pimage=(wxImage*) NULL;
   zoombox=(wxImage*) NULL;
   refresh_box=(wxImage*) NULL;
   zImg=NULL;
   showtrack_ = 0;
   if (refresh > 0)
      Refresh();
}

int BgImCanvas::SetImage(wxString imname)
{
   ClearData();
   pimage=new wxImage();
   if (!pimage->LoadFile(imname))
   {
      delete pimage;
      wxLogError("Can't load image "+imname);
      return 0;
   }
   else
   {
      SetScrollbars(1, 1, (pimage->GetWidth())/1, (pimage->GetHeight())/1);
#if wxCHECK_VERSION(2, 3, 0)
      pbitmap = new wxBitmap(*pimage);
#else
      pbitmap = new wxBitmap(pimage->ConvertToBitmap());
#endif
      hasbitmap=true;
      m_dirty=true;

	  //create point map
	  CreatePointMap(pimage->GetWidth(), pimage->GetHeight());

	  //take account for zoom (takes care of refresh)
	  Zoom(zoom_level);
   }
   return 1;
}

void BgImCanvas::SetImage(wxImage& image)
{
   ClearData();
   pimage=new wxImage();
   *pimage = image;
   SetScrollbars(1, 1, (pimage->GetWidth())/1, (pimage->GetHeight())/1);
   
#if wxCHECK_VERSION(2, 3, 0)
      pbitmap = new wxBitmap(*pimage);
#else
      pbitmap = new wxBitmap(pimage->ConvertToBitmap());
#endif
   hasbitmap=true;
   m_dirty=true;

   //create point map
   CreatePointMap(image.GetWidth(), image.GetHeight());

   //take account for zoom (takes care of refresh)
   Zoom(zoom_level);
   
}

void BgImCanvas::SetSameImage(wxImage& image)
{
   *pimage = image;
#if wxCHECK_VERSION(2, 3, 0)
   *pbitmap = wxBitmap(image);
#else
   *pbitmap = image.ConvertToBitmap();
#endif

   //create point map
   CreatePointMap(image.GetWidth(), image.GetHeight());

   //take account for zoom (takes care of refresh)
   Zoom(zoom_level);
}

void BgImCanvas::SetImageFromGray(unsigned char* data, int w, int h)
{
   ClearData();
   
   pimage = new wxImage(w, h);

   int i;
   unsigned char* itTData;
   itTData = pimage->GetData();

   for (i=0; i<w*h; i++)
   {
      *(itTData++)=data[i];
      *(itTData++)=data[i];
      *(itTData++)=data[i];
   }
   SetScrollbars(1, 1, (pimage->GetWidth())/1, (pimage->GetHeight())/1);

#if wxCHECK_VERSION(2, 3, 0)
   pbitmap = new wxBitmap(*pimage);
#else
   pbitmap = new wxBitmap(pimage->ConvertToBitmap());
#endif
   hasbitmap=true;
   m_dirty=true;

   //create point map
   CreatePointMap(w, h);

   //take account for zoom (takes care of refresh)
   Zoom(zoom_level);
}



void BgImCanvas::SetImage(unsigned char* data, int w, int h)
{
   ClearData();
   
   pimage = new wxImage(w, h);

   int i;
   unsigned char* itTData;
   itTData = pimage->GetData();

   if (mdata != NULL)
   {
		delete[] mdata;
   }
   mdata = new unsigned char[w*h*3];
   memcpy(mdata,data,w*h*3);

   nw = w;
   nh = h;

  
    for (i=0; i<(3*w*h); i++)
    {
        *(itTData++)=data[i];
    }

    hasbitmap=true;
	m_dirty=true;
   SetScrollbars(1, 1, (pimage->GetWidth())/1, (pimage->GetHeight())/1);
    pbitmap = new wxBitmap(*pimage);

  
   Refresh();

   
   
}

/*
Still needs work!!!!!!
*/

void BgImCanvas::ShowBitmap(bool showbitmap)
{
	showbitmap_	= showbitmap;
	if(hasbitmap)
	{
		//compute height and width of original image
		int width	= pimage->GetWidth();
		int height	= pimage->GetHeight();

		//paint zoom image
		if(!showbitmap_)
			memset(zImg, 255, 3*zoom_level*zoom_level*width*height*sizeof(unsigned char));
		else
			bgZoomIn(&zImg, pimage->GetData(), width, height, zoom_level, false);

		//plot points from point set onto zoom image
		AddPoints(zImg, width*zoom_level);

		//re-draw image onto canvas
		Refresh();
	}
	return;
}


// Define the repainting behaviour
void BgImCanvas::OnDraw(wxDC& dc)
{


	//re-plot image bitmap
	if(hasbitmap==true && showbitmap_==true)
	{
		if((!zoom_window)||(!has_focus))
			dc.DrawBitmap(*pbitmap,0+x_offset_,0+y_offset_);
	}
	


}

//adds an image margin to the image
//pre : (x_margin, y_margin) define the margins in the
//      x and y direction respectively
//post: an image margin has been added
void BgImCanvas::AddMargin(int x_margin, int y_margin)
{
	//shift the image
	x_offset_	= x_margin;
	y_offset_	= y_margin;

	//redraw the image
	Refresh();

}

//overloaded zoom function that does not use current mouse position
int BgImCanvas::Zoom(int zconst)
{
	return Zoom(zconst, 0, 0);
}

//allows one to zoom into/out of the image dispalyed by the image canvas
//pre : zconst is the zoom constant
//      (m_x, m_y) is the current position of the mouse
//post: the image has been zoomed in by a factor of zconst
//      returns 1 when zoom not possible due to image constraints,
//		zoom at maximum or minimum image dimensions, or possible error
int BgImCanvas::Zoom(int zconst, int m_x, int m_y)
{
	//must have bitmap to zoom
	if(hasbitmap)
	{
		//determine zooming action
		int	action;
		if(zconst < zoom_level)
			action	= ZOOM_OUT;
		else if(zconst > zoom_level)
			action	= ZOOM_IN;
		
		//check bounds
		int	width	= pimage->GetWidth(), height	= pimage->GetHeight();
		if(zconst < 0)
		{
			//take absolute value of zoom constant
			int	pos_zc	= -zconst;

			//compute new width
			if(width%pos_zc)
				width	= width/pos_zc+1;
			else
				width	/= pos_zc;

			//compute new height
			if(height%pos_zc)
				height	= height/pos_zc+1;
			else
				height	/= -zconst;

			//make sure width and height are above minimum
			//before continuing
			if((width < MIN_WIDTH)||(height < MIN_HEIGHT))
				return 1;
		}
		else if (zconst > 0)
		{
			width	*= zconst;
			height	*= zconst;
			if((width > MAX_WIDTH)||(height > MAX_HEIGHT))
				return 1;
		}
		else
		{
			//zconst equals zero (ambiguous so exit)
			return 1;
		}
		
		//set zoom_level
		zoom_level	= zconst;

		if(zoom_level == 1)
		{
			delete	pbitmap;
#if wxCHECK_VERSION(2, 3, 0)
         pbitmap = new wxBitmap(*pimage);
#else
			pbitmap	= new wxBitmap(pimage->ConvertToBitmap());
#endif
			if(zImg)	delete zImg;
			zImg	= new unsigned char [3*height*width];
			memcpy(zImg, pimage->GetData(), 3*height*width);
		}
		else if(zoom_level > 1)
		{
			//zoom into image using zoom level
			wxImage	tempIm(width, height);
			if(zImg)	delete [] zImg;
			zImg	= new unsigned char [3*width*height];
			bgZoomIn(&zImg, pimage->GetData(), pimage->GetWidth(), pimage->GetHeight(), zoom_level, false);
			memcpy(tempIm.GetData(), zImg, 3*width*height*sizeof(unsigned char));
			
			//reset the bitmap using zoomed image
			delete pbitmap;
#if wxCHECK_VERSION(2, 3, 0)
         pbitmap = new wxBitmap(tempIm);
#else
			pbitmap = new wxBitmap(tempIm.ConvertToBitmap());
#endif
		}
		else if(zoom_level < -1)
		{
			//zoom out of image using zoom level
			wxImage	tempIm(width, height);
			if(zImg)	delete [] zImg;
			zImg	= new unsigned char [3*width*height];
			bgZoomOut(&zImg, pimage->GetData(), pimage->GetWidth(), pimage->GetHeight(), (-zoom_level), false);
			memcpy(tempIm.GetData(), zImg, 3*width*height*sizeof(unsigned char));
			
			//reset the bitmap using zoomed image
			delete pbitmap;
#if wxCHECK_VERSION(2, 3, 0)
         pbitmap = new wxBitmap(tempIm);
#else
			pbitmap = new wxBitmap(tempIm.ConvertToBitmap());
#endif
		}

		//if a bitmap is not to be shown, clear (make white) the
		//zoomed image
		if(!showbitmap_)
			memset(zImg, 255, 3*width*height*sizeof(unsigned char));

		//add point data to zoomed image
		AddPoints(zImg, width);

		//re-display image
		Refresh();

		//set scroll bars according to current mouse position and zooming action
		AdjustScroll(m_x, m_y, action);

		//return 1 when maximum or minimum image dimension has occured
		if((width == MAX_WIDTH)||(width == MIN_WIDTH)||(height == MAX_HEIGHT)||(height == MIN_HEIGHT))
			return 1;

		//return 1 when close to maximum or minimum image dimension...
		/*********************************************************************/

		if(zconst > 0)
		{
			width	+= pimage->GetWidth();
			height	+= pimage->GetHeight();
			if((width > MAX_WIDTH)||(height > MAX_HEIGHT))
				return 1;
		}
		else if(zconst < 0)
		{
			
			//obtain width and height of original image
			width	= pimage->GetWidth();
			height	= pimage->GetHeight();
			
			//take absolute value of zoom constant
			int	pos_zc	= -zconst;
			
			//compute new width
			if(width%pos_zc)
				width	= width/pos_zc+1;
			else
				width	/= pos_zc;
			
			//compute new height
			if(height%pos_zc)
				height	= height/pos_zc+1;
			else
				height	/= -zconst;
			width	= (pimage->GetWidth());

			//check image bounds...
			if((width < MIN_WIDTH)||(height < MIN_HEIGHT))
				return 1;
		}

		/*********************************************************************/
	}

	//done.
	return 0;

}




//sets max zoom level
void BgImCanvas::SetMaxZoomLevel(int mzl)
{
	max_zoom_level	= mzl;
}

//sets min zoom level
void BgImCanvas::SetMinZoomLevel(int mzl)
{
	min_zoom_level	= mzl;
}


#define WIN_PERC 16

void BgImCanvas::DefineZoomBox(int l_x, int h_x, int l_y, int h_y)
{

	//obtain image height and width
	int	iWidth = pimage->GetWidth(), iHeight = pimage->GetHeight();

	//calculate box height and width
	static int bWidth = h_x-l_x+1, bHeight = h_y-l_y+1;

	//allocate/deallocate memory
	if((bWidth != h_x-l_x+1)||(!buf))
	{
		bWidth	= h_x-l_x+1;
		bHeight	= h_y-l_y+1;
		if(buf)	delete buf;
		buf	= new unsigned char [3*bWidth*bHeight];
	}

	//get point pen colour
	unsigned char r, g, b;
	if(point_colour)
	{
		r	= point_colour->Red();
		g	= point_colour->Green();
		b	= point_colour->Blue();
	}

	//crop image data and store it into buf (if the bitmap is being displayed...)
	unsigned char	*imData		= pimage->GetData();
	int bx, by, ix, iy, idp, bdp;
	if(showbitmap_)
	{
		for(by=0; by<bHeight; by++)
		{
			for(bx=0; bx<bWidth; bx++)
			{
				ix	= bx + l_x;
				iy	= by + l_y;
				idp	= 3*(iy*iWidth + ix);
				bdp	= 3*(by*bWidth + bx);
				buf[bdp  ]	= imData[idp  ];
				buf[bdp+1]	= imData[idp+1];
				buf[bdp+2]	= imData[idp+2];
				
			
			}
		}
	}
	//create blank (white) image and plot point set onto it
	//prior to zoom
	else
	{
		memset(buf, 255, 3*bWidth*bHeight*sizeof(unsigned char));
		for(by=0; by<bHeight; by++)
		{
			for(bx=0; bx<bWidth; bx++)
			{
				ix	= bx + l_x;
				iy	= by + l_y;
				idp	= 3*(iy*iWidth + ix);
				bdp	= 3*(by*bWidth + bx);

				
			}
		}
	}

	//zoom the data in buf...

	//set zoom window size and allocate memory
	static int	zWidth	= bWidth*zoom_level*2;
	static int	zHeight	= bHeight*zoom_level*2;
	if((zWidth != bWidth*zoom_level*2)||(!zoombox))
	{
		zWidth	= bWidth*zoom_level*2;
		zHeight	= bHeight*zoom_level*2;
		if(zoombox)	delete zoombox;
		zoombox	= new wxImage(zWidth, zHeight);

	}

	//create a zoom box image using buf
	unsigned char	*zbData	= zoombox->GetData();
	bgZoomIn(&zbData, buf, bWidth, bHeight, zoom_level*2, false);

	//done.
	return;
}

void BgImCanvas::DefineRefreshBox(void)
{

	//obtain image height and width
	int	iWidth = pimage->GetWidth()*zoom_level, iHeight = pimage->GetHeight()*zoom_level;

	//calculate box height and width
	static int bWidth = zoombox->GetWidth(), bHeight = zoombox->GetHeight();

	//allocate/de-allocate memory for refresh box
	if((bWidth != zoombox->GetWidth())||(!refresh_box))
	{
		bWidth	= zoombox->GetWidth();
		bHeight	= zoombox->GetHeight();
		if(refresh_box)	delete [] refresh_box;
		refresh_box	= new wxImage(bWidth, bHeight);
	}
	unsigned char *rBuf	= refresh_box->GetData();

	//get point pen colour
	unsigned char r, g, b;
	if(point_colour)
	{
		r	= point_colour->Red();
		g	= point_colour->Green();
		b	= point_colour->Blue();
	}

	//define refresh box...

	//crop image data and store it into rBuf...
	unsigned char *imData	= pimage->GetData();
	int bx, by, ix, iy, bdp, idp;
	for(by=0; by<bHeight; by++)
	{
		for(bx=0; bx<bWidth; bx++)
		{
			ix	= bx + cx;
			iy	= by + cy;
			idp	= 3*(iy*iWidth + ix);
			bdp	= 3*(by*bWidth + bx);
			rBuf[bdp  ]	= zImg[idp  ];
			rBuf[bdp+1]	= zImg[idp+1];
			rBuf[bdp+2]	= zImg[idp+2];
		}
	}

	//done.
	return;
}

//creates point map used by zoom and refresh windows
void BgImCanvas::CreatePointMap(int w, int h)
{

	//if point sets already exist then add the,
	if (nPointSets_ > 0)
	{
		//adjust point pen colour to be that of the last
		//point set added
		if(point_colour)	delete point_colour;
		point_colour	= new wxColour(*wxBLUE);
	}
}

//adds points from point sets onto specified image
void BgImCanvas::AddPoints(unsigned char *im, int width)
{
	//if point sets have been defined add point data to image
	if(nPointSets_	> 0)
	{
		unsigned char r, g, b;
		wxColour	pen_colour;
		int	nt, *tx, *ty, i, j, x, y, dp, offset;
		for(i=0; i < nPointSets_; i++)
		{
			if(pointSet_[i]->type_ == 1) //point
			{
				//get pen colour
				pen_colour	= *wxWHITE;
				r	= pen_colour.Red();
				g	= pen_colour.Green();
				b	= pen_colour.Blue();

				//place points
				nt	= pointSet_[i]->n_;
				tx	= pointSet_[i]->x_;
				ty	= pointSet_[i]->y_;
				for(j=0; j<nt; j++)
				{
					dp = 3*(ty[j]*width+tx[j])*zoom_level;
					for(y=0; y<zoom_level; y++)
					{
						for(x=0; x<zoom_level; x++)
						{
							offset	= 3*(y*width+x);
							im[dp+offset  ]	= r;
							im[dp+offset+1]	= g;
							im[dp+offset+2]	= b;
						}
					}
				}
			}
		}
	}
}

//displays zoom window at cursor position
void BgImCanvas::DisplayZoomWindow(int m_x, int m_y)
{

	//set mouse position...
	m_x_	= m_x;
	m_y_	= m_y;

	//compute width and height of window....

	/***********************************************************/

	//obtain image height and width
	int w = pimage->GetWidth(), h = pimage->GetHeight();

	//take percentage of height and width to compute
	//box half-width and half-height
	int	hw, hh;
	int	wp	= WIN_PERC;
	if(w%wp)
		hw	= w/wp + 1;
	else
		hw	= w/wp;

	if(h%wp)
		hh	= h/wp + 1;
	else
		hh	= h/wp;

	/***********************************************************/

	//normalize mouse coordinates to image coordinate frame

	/***********************************************************/

	if(zoom_level > 0)
	{
		m_x	= (m_x + GetScrollPos(wxHORIZONTAL))/zoom_level;
		m_y	= (m_y + GetScrollPos(wxVERTICAL))/zoom_level;
	}
	else if(zoom_level < 0)
	{
		m_x	= (m_x + GetScrollPos(wxHORIZONTAL))*(-zoom_level);
		m_y	= (m_y + GetScrollPos(wxVERTICAL))*(-zoom_level);
	}

	/***********************************************************/

	//make sure x_m and y_m are with bounds before proceeding...

	/***********************************************************/

	if((m_x < 0)||(m_x >= w)||(m_y < 0)||(m_y >= h))
		return;

	/***********************************************************/

	//compute zoom window bounds...

	/***********************************************************/

	//define window bounds based on current mouse position
	int low_x, hi_x, low_y, hi_y;
	if((low_x	= m_x - hw) <  0) low_x	= 0;
	if((hi_x	= m_x + hw) >= w) hi_x	= w-1;
	if((low_y	= m_y - hh) <  0) low_y	= 0;
	if((hi_y	= m_y + hh) >= h) hi_y	= h-1;

	//make window larger according to current mouse position	
	if(m_x			<= hw) hi_x		+= hw-m_x;
	if((w-m_x-1)	<= hw) low_x	-= hw-(w-m_x-1);
	if(m_y			<= hh) hi_y		+= hh-m_y;
	if((h-m_y-1)	<= hh) low_y	-= hh-(h-m_y-1);

	/***********************************************************/

	//define zoom box...

	/***********************************************************/

	DefineZoomBox(low_x, hi_x, low_y, hi_y);

	/***********************************************************/

	//display zoomed image over current mouse position...

	/***********************************************************/

	Refresh(false);

	/***********************************************************/

	//done.
	return;

}

/*
void BgImCanvas::OnEraseBackground(wxEraseEvent& WXUNUSED(event))
{
}
*/
void BgImCanvas::FillCurveClick()
{
   int i;
   for (i=0; i<ccx_*ccy_; i++)
      curveClick_[i] = 0;
   
   for (i=0; i<nCurveSets_; i++)
      curveSet_[i]->DrawYourself(curveClick_, i+1);

   Refresh();
//   write_pgm_image("curveclick.pgm", curveClick_, 256, 256, "", 4);
}

/*
void BgImCanvas::OnPaint(wxPaintEvent& WXUNUSED(event))
{
   wxClientDC dc(this);
   PrepareDC(dc);
   if(hasbitmap==true)
   {
      dc.DrawBitmap(*pbitmap,0,0);
   }
   else 
   {
      dc.Clear();
   }
}
*/

void BgImCanvas::MyDrawEllipticArc(wxDC& dc, int x, int y, int w, int h, int sa, int ea)
{
   double xc, yc, rx, ry;
   rx = w/2;
   ry = h/2;
   xc = x+rx;
   yc = y+ry;
   int r, c;
   int low_r = y_offset_;
   int hig_r = ccy_+y_offset_;
   int low_c = x_offset_;
   int hig_c = ccx_+x_offset_;

//   if (rx > ry)
//   {
      // x scan
      for (c = (int) xc; c<=(int) (xc+rx); c++)
      {
         if (c>=low_c && c<hig_c)
         {
            r = bgRound(yc-ry*sqrt(1-(c-xc)*(c-xc)/(rx*rx)));
            if (r>=low_r && r<hig_r)
            {
               dc.DrawPoint(c,r);
               // +/- 1
               if ((r+1)<hig_r) dc.DrawPoint(c,r+1);
               if ((r-1)>=low_r) dc.DrawPoint(c,r-1);;
            }
         }
      }
//   }
//   else
//   {
      // y scan
      for (r = (int)(yc-ry); r<=(int) yc; r++)
      {
         if (r>=low_r && r<hig_r)
         {
            c = bgRound(xc+rx*sqrt(1-(r-yc)*(r-yc)/(ry*ry)));
            if (c>=low_c && c<hig_c)
            {
               dc.DrawPoint(c,r);
               // +/- 1
               if ((c+1)<hig_c) dc.DrawPoint(c+1,r);
               if ((c-1)>=low_c) dc.DrawPoint(c-1,r);;
            }
         }
      }
//   }
}

void BgImCanvas::OnMouseRightDown(wxMouseEvent& event)
{
   wxClientDC dc(this);
   PrepareDC(dc);
   wxPoint pt(event.GetLogicalPosition(dc));
   static int x;
   static int y;
   x = pt.x-x_offset_;
   y = pt.y-y_offset_;
   if (x>=0 && x<ccx_ && y>=0 && y<ccy_)
   {
      if (curveClick_[x+y*ccx_]>0)
      {
         lmEventCurve_ = curveClick_[x+y*ccx_] - 1;
         if (curveSet_[lmEventCurve_]->type_ == FC_CUSTOM)
         {
            // determine if close to a node
            int *tempx, *tempy, tempn;
            double mindist, crtdist;
            int i, minnode;
            tempx = curveSet_[lmEventCurve_]->x_;
            tempy = curveSet_[lmEventCurve_]->y_;
            tempn = curveSet_[lmEventCurve_]->n_;
            mindist = sqrt(1.0*(x-tempx[0])*(x-tempx[0])+(y-tempy[0])*(y-tempy[0]));
            minnode = 0;
            for (i=1; i<tempn; i++)
            {
               crtdist = sqrt(1.0*(x-tempx[i])*(x-tempx[i])+(y-tempy[i])*(y-tempy[i]));
               if (crtdist < mindist)
               {
                  mindist = crtdist;
                  minnode = i;
               }
            }
            if (mindist <= 3)
            {
               // delete node option
               lmEventNode_ = minnode;
               localMenu_->Enable(BG_IMC_ADDNODE,false);
               localMenu_->Enable(BG_IMC_DELETENODE,true);
            } else
            {
               // add node option
               localMenu_->Enable(BG_IMC_ADDNODE,true);
               localMenu_->Enable(BG_IMC_DELETENODE,false);
            }
         }
         else
         {
            localMenu_->Enable(BG_IMC_ADDNODE,false);
            localMenu_->Enable(BG_IMC_DELETENODE,false);
         }
         lmEventX_ = x;//+x_offset_;
         lmEventY_ = y;//+y_offset_;
         PopupMenu(localMenu_, x+x_offset_, y+y_offset_);
      }
   }
}

/*
//updates hover menu during scroll event
void BgImCanvas::OnScroll(wxScrollWinEvent& event)
{

}
*/

//attemtps to adjust scroll position of window according
//to current mouse position
void BgImCanvas::AdjustScroll(int x, int y, int action)
{
	if(zoom_level > 1)
	{

		//get window width and height
		int	winWidth, winHeight;
		GetSize(&winWidth, &winHeight);

		//get window vertical and horzontal scroll position
		//and offset current mouse position to obtain mouse
		//position relative to the image
		x	= x + GetScrollPos(wxHORIZONTAL);
		y	= y + GetScrollPos(wxVERTICAL);

		//re-location mouse position relative to new image width
		//and height
		if(action == ZOOM_IN)
		{
			x	= zoom_level*(x/(zoom_level-1));
			y	= zoom_level*(y/(zoom_level-1));
		}
		else if(action == ZOOM_OUT)
		{
			x	= zoom_level*(x/(zoom_level+1));
			y	= zoom_level*(y/(zoom_level+1));
		}

		//resize scroll
		int	width	= (pimage->GetHeight())*zoom_level;
		int	height	= (pimage->GetWidth())*zoom_level;
		SetScrollbars(1, 1, width, height);

		//set scroll position according to x and y
		int offset_x	= x/2;
		int offset_y	= y/2;
		SetScrollPos(wxHORIZONTAL, offset_x, true);
		SetScrollPos(wxVERTICAL, offset_y, true);

		//refresh window contents
		Scroll(offset_x, offset_y);
	}
}
static int x=0;
static int y=0;


void BgImCanvas::OnEvent(wxMouseEvent& event)
{

   //store mouse pointer location...
   m_x_	= event.m_x;
   m_y_	= event.m_y;

   wxClientDC dc(this);
   PrepareDC(dc);
   wxPoint pt(event.GetLogicalPosition(dc));

   static int curvedrag;


 
   x = pt.x-x_offset_;
   y = pt.y-y_offset_;
  



 
   //if zoom is enabled, set the cursor to the zoom icon
   //otherwise leave it as default
   if(event.Entering())
   {
	   //when parent is not the active child frame, set the cursor
	   //to wxCURSOR_ARROW
	   bool	current_child	= false;
	   wxMDIParentFrame *parent	= (wxMDIParentFrame *)(child_frame_->GetParent());
	   wxMDIChildFrame	*activeChild	= parent->GetActiveChild();
	   if(activeChild == (wxMDIChildFrame *) child_frame_)
		   current_child	= true;

	   if((zoom_out || zoom_in)&&(current_child))
		   SetCursor(wxCURSOR_MAGNIFIER);
	   else if((zoom_window)&&(current_child))
		   SetCursor(wxCURSOR_CROSS);
	   else
		   SetCursor(wxCURSOR_ARROW);

	   //indiciate that the window has acquired focus
	   has_focus	= true;

	   //show the menu window
	   if((menuWindow)&&(popup))
		   menuWindow->Show(true);
   }

   //indicate that the window has lost focus
   if(event.Leaving())
   {
	   //indicate that the window has lost focus
	   has_focus	= false;

	   //indicate that the mouse pointer is leaving
	   //this window
	   leaving		= true;

	   //refresh canvas upon using a zoom window
	   if(zoom_window)
		Refresh(false);
   }

}

void BgImCanvas::AddHoverWindow(wxWindow* hoverWindow, int pp)
{
	popup		= pp;
	menuWindow	= hoverWindow;
	if(popup)	menuWindow->Show(false);
	else		menuWindow->Show(true);
	int width, height;
	menuWindow->GetSize(&width, &height);
	menuXl_	= HOVER_MENU_X - HOVER_MENU_BOUND;
	menuYl_	= HOVER_MENU_Y - HOVER_MENU_BOUND;
	menuXu_	= menuXl_ + width + HOVER_MENU_BOUND;
	menuYu_	= menuXu_ + width + HOVER_MENU_BOUND;
	menuWindow->SetSize(HOVER_MENU_X, HOVER_MENU_Y, width, height);
}

void BgImCanvas::SetHoverWindowLocation(int x, int y)
{
	int width, height;
	menuWindow->GetSize(&width, &height);
	if((x < 0)||(x >= width)||(y < 0)||(y >= height))	return;
	menuWindow->SetSize(x, y, width, height);
}
